# ZYLO Billing Software

Complete cloud-based billing software built with React, Node.js, Express, and MongoDB.

## Features

### Authentication & Users
- JWT-based authentication with bcrypt password hashing
- Two login types: Admin and User
- Default admin: `zylo@2026` / `181629`
- Role-based access control
- Session management

### Subscription System
- 3-day free demo trial for new users
- Automatic expiry checking (runs every hour)
- Subscription lock when expired
- WhatsApp contact button for renewal
- Plans: Monthly, Yearly, Lifetime
- Admin can manually activate/extend subscriptions

### User Features
- Dashboard with analytics and charts
- Invoice creation with auto-numbering
- Quotation management (convert to invoice)
- Purchase Orders with supplier management
- Delivery Orders with tracking status
- Delivery Requests with approval workflow
- Customer Management
- Product Management with stock tracking
- Company Profile Settings
- GST/Tax Settings
- Print and PDF download
- WhatsApp sharing
- Dark/Light mode

### Admin Features
- Admin dashboard with platform analytics
- User management (CRUD + permissions)
- Subscription control (activate/extend/remove)
- View all invoices, quotations, POs, DOs
- Revenue tracking
- Activity logs
- Export reports (CSV)
- Expired users list

## Tech Stack

- **Frontend**: React 18 + TypeScript + Tailwind CSS + Vite
- **Backend**: Node.js + Express + TypeScript
- **Database**: MongoDB + Mongoose
- **Auth**: JWT + bcryptjs
- **Charts**: Recharts
- **PDF**: html2canvas + jsPDF
- **State**: Zustand

## Installation

### Prerequisites
- Node.js 18+
- MongoDB (local or Atlas)

### Setup

1. **Clone and install dependencies:**
```bash
cd zylo-billing
npm install
cd frontend && npm install
cd ../backend && npm install
```

2. **Environment Variables:**
```bash
cd backend
cp .env.example .env
# Edit .env with your MongoDB URI and JWT secret
```

3. **Seed Database:**
```bash
cd backend
npm run seed
```

4. **Run Development:**
```bash
# Terminal 1 - Backend
cd backend
npm run dev

# Terminal 2 - Frontend
cd frontend
npm run dev
```

5. **Access:**
- Frontend: http://localhost:5173
- Backend API: http://localhost:5000

## Default Login Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | zylo@2026 | 181629 |
| Demo User | demo@zylo.com | demo123 |

## Deployment

### Frontend (Vercel)
```bash
cd frontend
vercel --prod
```

### Backend (Render/Railway)
```bash
cd backend
# Set environment variables in dashboard
# Deploy
```

### MongoDB Atlas
1. Create cluster at mongodb.com
2. Add IP whitelist
3. Get connection string
4. Set `MONGODB_URI` in backend .env

## API Documentation

### Auth Routes
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login
- `GET /api/auth/me` - Get current user

### User Routes (Admin only)
- `GET /api/users` - List all users
- `POST /api/users` - Create user
- `PUT /api/users/:id` - Update user
- `DELETE /api/users/:id` - Delete user
- `PUT /api/users/:id/subscription` - Update subscription

### Invoice Routes
- `GET /api/invoices` - List invoices
- `POST /api/invoices` - Create invoice
- `GET /api/invoices/:id` - Get invoice
- `PUT /api/invoices/:id` - Update invoice
- `DELETE /api/invoices/:id` - Delete invoice

### Other Routes
- `/api/quotations` - Quotations
- `/api/purchase-orders` - Purchase Orders
- `/api/delivery-orders` - Delivery Orders
- `/api/delivery-requests` - Delivery Requests
- `/api/customers` - Customers
- `/api/products` - Products
- `/api/subscriptions` - Subscriptions
- `/api/company` - Company Settings
- `/api/dashboard` - Dashboard stats
- `/api/reports` - Reports
- `/api/activity` - Activity logs

## Database Collections

- `users` - User accounts
- `subscriptions` - Subscription data
- `invoices` - Invoices
- `quotations` - Quotations
- `purchaseorders` - Purchase Orders
- `deliveryorders` - Delivery Orders
- `deliveryrequests` - Delivery Requests
- `customers` - Customers
- `products` - Products
- `companies` - Company settings
- `activities` - Activity logs

## Security Features

- Password encryption with bcrypt (12 rounds)
- JWT authentication with 7-day expiry
- Role-based access control
- Rate limiting (100 requests/15 min)
- Helmet security headers
- CORS configuration
- Input validation
- Subscription expiry middleware

## License

MIT License - ZYLO Technologies

## Support

For subscription inquiries, contact via WhatsApp:
**+91 70190 71669**

---
Built with ❤️ by ZYLO Technologies
