@echo off
chcp 65001 >nul
echo 🚀 ZYLO Billing Software - Local Startup
echo =========================================
echo.

REM Check for Node.js
node -v >nul 2>&1
if errorlevel 1 (
    echo ❌ Node.js not found. Please install from https://nodejs.org
    pause
    exit /b 1
)

echo ✅ Node.js found
echo.

REM Install dependencies
echo 📦 Installing dependencies...
cd backend
call npm install
cd ..rontend
call npm install
cd ..

REM Setup environment
echo.
echo ⚙️  Setting up backend...
cd backend
if not exist .env (
    copy .env.example .env
    echo ✅ Created .env from template
)
cd ..

REM Seed database
echo.
echo 🌱 Seeding database...
cd backend
npx tsx src/utils/seed.ts
cd ..

echo.
echo 🎉 Setup complete!
echo.
echo To start the application:
echo   1. Open Terminal 1: cd backend ^&^& npm run dev
echo   2. Open Terminal 2: cd frontend ^&^& npm run dev
echo.
echo Then open http://localhost:5173
echo.
echo Admin: zylo@2026 / 181629
echo Demo:  demo@zylo.com / demo123
echo.
pause
