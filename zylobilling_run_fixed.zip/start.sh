#!/bin/bash

echo "🚀 ZYLO Billing Software - Local Startup"
echo "========================================="

# Check if Docker is available
if command -v docker &> /dev/null && command -v docker-compose &> /dev/null; then
    echo "✅ Docker found! Starting with Docker Compose..."
    docker-compose up --build -d
    echo ""
    echo "🎉 ZYLO is running!"
    echo "   Frontend: http://localhost:5173"
    echo "   Backend API: http://localhost:5000"
    echo "   MongoDB: localhost:27017"
    echo ""
    echo "   Admin Login: zylo@2026 / 181629"
    echo "   Demo Login: demo@zylo.com / demo123"
    echo ""
    echo "To stop: docker-compose down"
    exit 0
fi

# Fallback to manual setup
echo "⚠️  Docker not found. Starting manual setup..."
echo ""

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found. Please install Node.js 18+ first."
    echo "   Visit: https://nodejs.org"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo "❌ Node.js version $NODE_VERSION found. Need 18+."
    exit 1
fi

echo "✅ Node.js $(node -v) found"

# Install dependencies
echo ""
echo "📦 Installing dependencies..."

cd backend
npm install
cd ../frontend
npm install
cd ..

# Setup backend env
echo ""
echo "⚙️  Setting up backend..."
cd backend
if [ ! -f .env ]; then
    cp .env.example .env
    echo "✅ Created .env from template"
    echo "⚠️  Please edit backend/.env and set your MONGODB_URI"
fi

# Seed database
echo ""
echo "🌱 Seeding database..."
npx tsx src/utils/seed.ts || echo "⚠️  Seed failed. Database may need to be running."

cd ..

# Start services
echo ""
echo "🚀 Starting services..."
echo ""
echo "Starting backend (Terminal 1)..."
cd backend
npm run dev &
BACKEND_PID=$!
cd ..

echo "Starting frontend (Terminal 2)..."
cd frontend
npm run dev &
FRONTEND_PID=$!
cd ..

echo ""
echo "🎉 ZYLO Billing Software is starting!"
echo ""
echo "   Frontend: http://localhost:5173"
echo "   Backend:  http://localhost:5000"
echo ""
echo "   Admin:    zylo@2026 / 181629"
echo "   Demo:     demo@zylo.com / demo123"
echo ""
echo "Press Ctrl+C to stop all services"

wait $BACKEND_PID $FRONTED_PID
