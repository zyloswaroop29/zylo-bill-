import { useLocation, useNavigate } from 'react-router-dom';
import { useStore } from '@/context/store';
import {
  LayoutDashboard, FileText, Quote, ShoppingCart, Truck, Package,
  Users, Settings, ChevronLeft, ChevronRight, LogOut, Building2,
  ClipboardList, Shield, BarChart3, Activity, FileSpreadsheet
} from 'lucide-react';
import toast from 'react-hot-toast';

const userNavItems = [
  { path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/invoices', label: 'Invoices', icon: FileText },
  { path: '/quotations', label: 'Quotations', icon: Quote },
  { path: '/purchase-orders', label: 'Purchase Orders', icon: ShoppingCart },
  { path: '/delivery-orders', label: 'Delivery Orders', icon: Truck },
  { path: '/delivery-requests', label: 'Delivery Requests', icon: ClipboardList },
  { path: '/customers', label: 'Customers', icon: Users },
  { path: '/products', label: 'Products', icon: Package },
  { path: '/company-settings', label: 'Company Settings', icon: Building2 },
];

const adminNavItems = [
  { path: '/admin/dashboard', label: 'Admin Dashboard', icon: Shield },
  { path: '/admin/users', label: 'Users', icon: Users },
  { path: '/admin/subscriptions', label: 'Subscriptions', icon: BarChart3 },
  { path: '/admin/invoices', label: 'All Invoices', icon: FileSpreadsheet },
  { path: '/admin/reports', label: 'Reports', icon: BarChart3 },
  { path: '/admin/activity', label: 'Activity Logs', icon: Activity },
];

export default function Sidebar() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, sidebarOpen, toggleSidebar, logout } = useStore();
  const isAdmin = user?.role === 'admin';

  const navItems = isAdmin ? adminNavItems : userNavItems;

  const handleLogout = () => {
    logout();
    toast.success('Logged out successfully');
    navigate('/login');
  };

  return (
    <>
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={toggleSidebar} />
      )}

      <aside className={`
        fixed top-0 left-0 z-50 h-full bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700
        transition-all duration-300 flex flex-col
        ${sidebarOpen ? 'w-64 translate-x-0' : 'w-20 -translate-x-full lg:translate-x-0'}
      `}>
        {/* Logo */}
        <div className="h-16 flex items-center px-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center flex-shrink-0">
              <span className="text-white font-bold text-sm">Z</span>
            </div>
            {sidebarOpen && (
              <div className="overflow-hidden">
                <h1 className="font-bold text-lg text-gray-900 dark:text-white whitespace-nowrap">ZYLO</h1>
                <p className="text-[10px] text-gray-500 dark:text-gray-400 -mt-1 whitespace-nowrap">Billing Software</p>
              </div>
            )}
          </div>
          <button onClick={toggleSidebar} className="ml-auto p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 lg:flex hidden">
            {sidebarOpen ? <ChevronLeft size={18} /> : <ChevronRight size={18} />}
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path || location.pathname.startsWith(`${item.path}/`);
            return (
              <button
                key={item.path}
                onClick={() => {
                  navigate(item.path);
                  if (window.innerWidth < 1024) toggleSidebar();
                }}
                className={`
                  w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all
                  ${isActive 
                    ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-700 dark:text-primary-400' 
                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-gray-200'
                  }
                  ${!sidebarOpen && 'justify-center'}
                `}
                title={!sidebarOpen ? item.label : undefined}
              >
                <Icon size={20} className="flex-shrink-0" />
                {sidebarOpen && <span className="truncate">{item.label}</span>}
              </button>
            );
          })}
        </nav>

        {/* Bottom section */}
        <div className="p-3 border-t border-gray-200 dark:border-gray-700 space-y-1">
          <button
            onClick={handleLogout}
            className={`
              w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium
              text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-all
              ${!sidebarOpen && 'justify-center'}
            `}
            title={!sidebarOpen ? 'Logout' : undefined}
          >
            <LogOut size={20} />
            {sidebarOpen && <span>Logout</span>}
          </button>

          {sidebarOpen && user && (
            <div className="px-3 py-2">
              <p className="text-xs text-gray-500 dark:text-gray-400 truncate">{user.name}</p>
              <p className="text-[10px] text-gray-400 dark:text-gray-500 truncate">{user.email}</p>
            </div>
          )}
        </div>
      </aside>
    </>
  );
}