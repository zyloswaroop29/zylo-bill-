import { Navigate, Outlet } from 'react-router-dom';
import { useStore } from '@/context/store';

export default function SubscriptionCheck() {
  const { user, subscription } = useStore();

  // Admin bypass
  if (user?.role === 'admin') {
    return <Outlet />;
  }

  // Check subscription expiry
  if (subscription) {
    const now = new Date();

    // Check demo expiry
    if (subscription.isDemo && subscription.demoExpiryDate) {
      const demoExpiry = new Date(subscription.demoExpiryDate);
      if (now > demoExpiry) {
        return <Navigate to="/subscription-expired" replace />;
      }
    }

    // Check subscription status
    if (subscription.status === 'expired') {
      return <Navigate to="/subscription-expired" replace />;
    }

    // Check end date for non-lifetime
    if (subscription.plan !== 'lifetime' && subscription.endDate) {
      const endDate = new Date(subscription.endDate);
      if (now > endDate) {
        return <Navigate to="/subscription-expired" replace />;
      }
    }
  }

  return <Outlet />;
}