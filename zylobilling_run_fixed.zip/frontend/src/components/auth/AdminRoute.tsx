import { Navigate, Outlet } from 'react-router-dom';
import { useStore } from '@/context/store';
import toast from 'react-hot-toast';

export default function AdminRoute() {
  const { isAuthenticated, user } = useStore();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (user?.role !== 'admin') {
    toast.error('Admin access required');
    return <Navigate to="/dashboard" replace />;
  }

  return <Outlet />;
}