import { useEffect, useState } from 'react';
import { reportAPI } from '@/utils/api';
import { Invoice, Quotation, PurchaseOrder, Customer, Product } from '@/types';
import { FileText, Quote, ShoppingCart, Users, Package, Download, Calendar } from 'lucide-react';
import toast from 'react-hot-toast';

export default function AdminReports() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [quotations, setQuotations] = useState<Quotation[]>([]);
  const [pos, setPos] = useState<PurchaseOrder[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'invoices' | 'quotations' | 'pos' | 'customers' | 'products'>('invoices');

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    try {
      const res = await reportAPI.getAdminAll();
      setInvoices(res.data.invoices);
      setQuotations(res.data.quotations);
      setPos(res.data.purchaseOrders);
      setCustomers(res.data.customers);
      setProducts(res.data.products);
    } catch (error) { toast.error('Failed to load'); } finally { setLoading(false); }
  };

  const exportToCSV = (data: any[], filename: string) => {
    if (data.length === 0) { toast.error('No data to export'); return; }
    const headers = Object.keys(data[0]).join(',');
    const rows = data.map(row => Object.values(row).map(v => `"${String(v).replace(/"/g, '""')}"`).join(','));
    const csv = [headers, ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `${filename}.csv`; a.click();
    URL.revokeObjectURL(url);
    toast.success('Exported to CSV');
  };

  const tabs = [
    { key: 'invoices' as const, label: 'Invoices', icon: FileText, count: invoices.length },
    { key: 'quotations' as const, label: 'Quotations', icon: Quote, count: quotations.length },
    { key: 'pos' as const, label: 'Purchase Orders', icon: ShoppingCart, count: pos.length },
    { key: 'customers' as const, label: 'Customers', icon: Users, count: customers.length },
    { key: 'products' as const, label: 'Products', icon: Package, count: products.length },
  ];

  const getData = () => {
    switch (activeTab) {
      case 'invoices': return invoices;
      case 'quotations': return quotations;
      case 'pos': return pos;
      case 'customers': return customers;
      case 'products': return products;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-gray-900 dark:text-white">Reports</h1><p className="text-gray-500 dark:text-gray-400">Export and view all platform data</p></div>
        <button onClick={() => exportToCSV(getData(), activeTab)} className="btn-primary flex items-center gap-2"><Download size={18} /> Export CSV</button>
      </div>

      <div className="flex gap-2 flex-wrap">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button key={tab.key} onClick={() => setActiveTab(tab.key)} className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium ${activeTab === tab.key ? 'bg-primary-600 text-white' : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400'}`}>
              <Icon size={16} />{tab.label} <span className="ml-1 px-1.5 py-0.5 bg-white/20 rounded text-xs">{tab.count}</span>
            </button>
          );
        })}
      </div>

      <div className="card">
        <div className="overflow-x-auto">
          {activeTab === 'invoices' && (
            <table className="w-full"><thead><tr className="border-b border-gray-200 dark:border-gray-700"><th className="table-header">Invoice #</th><th className="table-header">User</th><th className="table-header">Customer</th><th className="table-header">Amount</th><th className="table-header">Status</th><th className="table-header">Date</th></tr></thead>
            <tbody>{invoices.map(i => (<tr key={i._id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50"><td className="table-cell font-medium">{i.invoiceNumber}</td><td className="table-cell">{(i as any).user?.name}</td><td className="table-cell">{i.customerName}</td><td className="table-cell">₹{i.grandTotal.toLocaleString()}</td><td className="table-cell"><span className={`badge ${i.status === 'paid' ? 'badge-success' : 'badge-warning'}`}>{i.status}</span></td><td className="table-cell text-sm">{new Date(i.createdAt).toLocaleDateString()}</td></tr>))}</tbody></table>
          )}
          {activeTab === 'quotations' && (
            <table className="w-full"><thead><tr className="border-b border-gray-200 dark:border-gray-700"><th className="table-header">Quote #</th><th className="table-header">User</th><th className="table-header">Customer</th><th className="table-header">Amount</th><th className="table-header">Status</th></tr></thead>
            <tbody>{quotations.map(q => (<tr key={q._id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50"><td className="table-cell font-medium">{q.quotationNumber}</td><td className="table-cell">{(q as any).user?.name}</td><td className="table-cell">{q.customerName}</td><td className="table-cell">₹{q.grandTotal.toLocaleString()}</td><td className="table-cell"><span className={`badge ${q.status === 'converted' ? 'badge-success' : 'badge-info'}`}>{q.status}</span></td></tr>))}</tbody></table>
          )}
          {activeTab === 'pos' && (
            <table className="w-full"><thead><tr className="border-b border-gray-200 dark:border-gray-700"><th className="table-header">PO #</th><th className="table-header">User</th><th className="table-header">Supplier</th><th className="table-header">Amount</th><th className="table-header">Status</th></tr></thead>
            <tbody>{pos.map(p => (<tr key={p._id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50"><td className="table-cell font-medium">{p.poNumber}</td><td className="table-cell">{(p as any).user?.name}</td><td className="table-cell">{p.supplier}</td><td className="table-cell">₹{p.grandTotal.toLocaleString()}</td><td className="table-cell"><span className={`badge ${p.status === 'received' ? 'badge-success' : 'badge-info'}`}>{p.status}</span></td></tr>))}</tbody></table>
          )}
          {activeTab === 'customers' && (
            <table className="w-full"><thead><tr className="border-b border-gray-200 dark:border-gray-700"><th className="table-header">Name</th><th className="table-header">User</th><th className="table-header">Email</th><th className="table-header">Phone</th><th className="table-header">GST</th></tr></thead>
            <tbody>{customers.map(c => (<tr key={c._id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50"><td className="table-cell font-medium">{c.name}</td><td className="table-cell">{(c as any).user?.name}</td><td className="table-cell">{c.email || '-'}</td><td className="table-cell">{c.phone || '-'}</td><td className="table-cell">{c.gstNumber || '-'}</td></tr>))}</tbody></table>
          )}
          {activeTab === 'products' && (
            <table className="w-full"><thead><tr className="border-b border-gray-200 dark:border-gray-700"><th className="table-header">Product</th><th className="table-header">User</th><th className="table-header">SKU</th><th className="table-header">Price</th><th className="table-header">Stock</th></tr></thead>
            <tbody>{products.map(p => (<tr key={p._id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50"><td className="table-cell font-medium">{p.name}</td><td className="table-cell">{(p as any).user?.name}</td><td className="table-cell">{p.sku || '-'}</td><td className="table-cell">₹{p.price.toLocaleString()}</td><td className="table-cell">{p.stock || 0} {p.unit}</td></tr>))}</tbody></table>
          )}
        </div>
      </div>
    </div>
  );
}