import { useEffect, useState } from 'react';
import { activityAPI } from '@/utils/api';
import { Activity } from '@/types';
import { Activity as ActivityIcon, Clock, User, FileText, ShoppingCart, Truck, Users, Package } from 'lucide-react';
import toast from 'react-hot-toast';

export default function AdminActivity() {
  const [activities, setActivities] = useState<Activity[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);

  useEffect(() => { loadActivities(); }, [page]);

  const loadActivities = async () => {
    try { const res = await activityAPI.getAll({ page, limit: 50 }); setActivities(res.data.activities); }
    catch (error) { toast.error('Failed to load'); } finally { setLoading(false); }
  };

  const getIcon = (entityType: string) => {
    switch (entityType) {
      case 'invoice': return <FileText size={16} className="text-blue-500" />;
      case 'quotation': return <FileText size={16} className="text-purple-500" />;
      case 'purchaseOrder': return <ShoppingCart size={16} className="text-orange-500" />;
      case 'deliveryOrder': return <Truck size={16} className="text-green-500" />;
      case 'customer': return <Users size={16} className="text-indigo-500" />;
      case 'product': return <Package size={16} className="text-pink-500" />;
      default: return <ActivityIcon size={16} className="text-gray-500" />;
    }
  };

  return (
    <div className="space-y-6">
      <div><h1 className="text-2xl font-bold text-gray-900 dark:text-white">Activity Logs</h1><p className="text-gray-500 dark:text-gray-400">Track all user activities across the platform</p></div>

      <div className="card">
        <div className="overflow-x-auto">
          <table className="w-full"><thead><tr className="border-b border-gray-200 dark:border-gray-700"><th className="table-header">Time</th><th className="table-header">User</th><th className="table-header">Action</th><th className="table-header">Entity</th><th className="table-header">Details</th></tr></thead>
          <tbody>
            {loading ? <tr><td colSpan={5} className="text-center py-8"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600 mx-auto"></div></td></tr> :
            activities.length === 0 ? <tr><td colSpan={5} className="text-center py-8 text-gray-500">No activity logs</td></tr> :
            activities.map((a) => (
              <tr key={a._id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                <td className="table-cell text-sm whitespace-nowrap"><div className="flex items-center gap-1"><Clock size={12} />{new Date(a.createdAt).toLocaleString()}</div></td>
                <td className="table-cell"><div className="flex items-center gap-2"><div className="w-6 h-6 bg-primary-100 rounded-full flex items-center justify-center text-xs font-medium text-primary-700">{a.userName.charAt(0)}</div><span className="text-sm">{a.userName}</span></div></td>
                <td className="table-cell"><span className="badge badge-info text-xs">{a.action}</span></td>
                <td className="table-cell"><div className="flex items-center gap-2">{getIcon(a.entityType)}<span className="text-sm capitalize">{a.entityType}</span></div></td>
                <td className="table-cell text-sm">{a.details}{a.entityName && <span className="text-gray-500"> - {a.entityName}</span>}</td>
              </tr>
            ))}
          </tbody></table>
        </div>
        <div className="flex items-center justify-between px-4 py-3 border-t border-gray-200 dark:border-gray-700">
          <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="btn-secondary text-sm disabled:opacity-50">Previous</button>
          <span className="text-sm text-gray-500">Page {page}</span>
          <button onClick={() => setPage(p => p + 1)} disabled={activities.length < 50} className="btn-secondary text-sm disabled:opacity-50">Next</button>
        </div>
      </div>
    </div>
  );
}