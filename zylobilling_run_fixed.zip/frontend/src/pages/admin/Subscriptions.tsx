import { useEffect, useState } from 'react';
import { subscriptionAPI } from '@/utils/api';
import { Subscription } from '@/types';
import { Search, AlertTriangle, CheckCircle, Clock, Calendar, Infinity, CreditCard } from 'lucide-react';
import toast from 'react-hot-toast';

export default function AdminSubscriptions() {
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [expiredSubs, setExpiredSubs] = useState<Subscription[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'all' | 'expired'>('all');

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    try {
      const [allRes, expiredRes] = await Promise.all([
        subscriptionAPI.getAll(),
        subscriptionAPI.getExpired()
      ]);
      setSubscriptions(allRes.data.subscriptions);
      setExpiredSubs(expiredRes.data.subscriptions);
    } catch (error) { toast.error('Failed to load'); } finally { setLoading(false); }
  };

  const handleActivate = async (subId: string, userId: string, plan: string, days: number) => {
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + days);
    try {
      await subscriptionAPI.activate(userId, { plan, endDate, amount: plan === 'monthly' ? 999 : plan === 'yearly' ? 9999 : 24999 });
      toast.success(`Subscription activated: ${plan}`);
      loadData();
    } catch (e) { toast.error('Failed to activate'); }
  };

  const getPlanIcon = (plan: string) => {
    switch (plan) {
      case 'trial': return <Clock size={16} className="text-yellow-500" />;
      case 'monthly': return <Calendar size={16} className="text-blue-500" />;
      case 'yearly': return <Calendar size={16} className="text-green-500" />;
      case 'lifetime': return <Infinity size={16} className="text-purple-500" />;
      default: return <CreditCard size={16} />;
    }
  };

  const displayData = activeTab === 'all' ? subscriptions : expiredSubs;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-gray-900 dark:text-white">Subscriptions</h1><p className="text-gray-500 dark:text-gray-400">Manage user subscriptions</p></div>
        <div className="flex gap-2">
          <button onClick={() => setActiveTab('all')} className={`px-4 py-2 rounded-lg text-sm font-medium ${activeTab === 'all' ? 'bg-primary-600 text-white' : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400'}`}>All</button>
          <button onClick={() => setActiveTab('expired')} className={`px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 ${activeTab === 'expired' ? 'bg-red-600 text-white' : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400'}`}><AlertTriangle size={14} /> Expired</button>
        </div>
      </div>

      <div className="card">
        <div className="overflow-x-auto">
          <table className="w-full"><thead><tr className="border-b border-gray-200 dark:border-gray-700"><th className="table-header">User</th><th className="table-header">Plan</th><th className="table-header">Status</th><th className="table-header">Start Date</th><th className="table-header">End/Demo Date</th><th className="table-header">Payment</th><th className="table-header text-right">Actions</th></tr></thead>
          <tbody>
            {loading ? <tr><td colSpan={7} className="text-center py-8"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600 mx-auto"></div></td></tr> :
            displayData.length === 0 ? <tr><td colSpan={7} className="text-center py-8 text-gray-500">No subscriptions</td></tr> :
            displayData.map((sub) => (
              <tr key={sub._id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                <td className="table-cell"><div><p className="font-medium">{(sub as any).user?.name || 'Unknown'}</p><p className="text-xs text-gray-500">{(sub as any).user?.email || ''}</p></div></td>
                <td className="table-cell"><div className="flex items-center gap-2">{getPlanIcon(sub.plan)}<span className="capitalize">{sub.plan}</span></div></td>
                <td className="table-cell"><span className={`badge ${sub.status === 'active' ? 'badge-success' : sub.status === 'expired' ? 'badge-danger' : 'badge-warning'}`}>{sub.status}</span></td>
                <td className="table-cell text-sm">{new Date(sub.startDate).toLocaleDateString()}</td>
                <td className="table-cell text-sm">{sub.isDemo && sub.demoExpiryDate ? new Date(sub.demoExpiryDate).toLocaleDateString() : sub.endDate ? new Date(sub.endDate).toLocaleDateString() : 'N/A'}</td>
                <td className="table-cell"><span className={`badge ${sub.paymentStatus === 'paid' ? 'badge-success' : 'badge-warning'}`}>{sub.paymentStatus}</span></td>
                <td className="table-cell text-right">
                  <div className="flex items-center justify-end gap-1">
                    {sub.status === 'expired' && (
                      <><button onClick={() => handleActivate(sub._id, sub.user, 'monthly', 30)} className="px-2 py-1 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 rounded text-xs font-medium">+30d</button>
                      <button onClick={() => handleActivate(sub._id, sub.user, 'yearly', 365)} className="px-2 py-1 bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 rounded text-xs font-medium">+1y</button>
                      <button onClick={() => handleActivate(sub._id, sub.user, 'lifetime', 36500)} className="px-2 py-1 bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-400 rounded text-xs font-medium">Lifetime</button></>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody></table>
        </div>
      </div>
    </div>
  );
}