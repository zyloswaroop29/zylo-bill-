import { useEffect, useState } from 'react';
import { reportAPI } from '@/utils/api';
import { Invoice } from '@/types';
import { FileText, Download, Search, Calendar } from 'lucide-react';
import toast from 'react-hot-toast';

export default function AdminInvoices() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  useEffect(() => { loadInvoices(); }, []);

  const loadInvoices = async () => {
    try {
      const params: any = {};
      if (startDate && endDate) { params.startDate = startDate; params.endDate = endDate; }
      const res = await reportAPI.getAdminAll(params);
      setInvoices(res.data.invoices);
    } catch (error) { toast.error('Failed to load'); } finally { setLoading(false); }
  };

  const totalRevenue = invoices.filter(i => i.status === 'paid').reduce((sum, i) => sum + i.grandTotal, 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-gray-900 dark:text-white">All Invoices</h1><p className="text-gray-500 dark:text-gray-400">View all invoices across users</p></div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="card"><p className="text-sm text-gray-500">Total Invoices</p><p className="text-2xl font-bold">{invoices.length}</p></div>
        <div className="card"><p className="text-sm text-gray-500">Total Revenue</p><p className="text-2xl font-bold text-green-600">₹{totalRevenue.toLocaleString()}</p></div>
        <div className="card"><p className="text-sm text-gray-500">Paid</p><p className="text-2xl font-bold">{invoices.filter(i => i.status === 'paid').length}</p></div>
        <div className="card"><p className="text-sm text-gray-500">Pending</p><p className="text-2xl font-bold text-yellow-600">{invoices.filter(i => i.status !== 'paid').length}</p></div>
      </div>

      <div className="card">
        <div className="flex gap-2 mb-4 flex-wrap">
          <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="input-field w-auto" />
          <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} className="input-field w-auto" />
          <button onClick={loadInvoices} className="btn-secondary"><Search size={18} /></button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full"><thead><tr className="border-b border-gray-200 dark:border-gray-700"><th className="table-header">Invoice #</th><th className="table-header">User</th><th className="table-header">Customer</th><th className="table-header">Date</th><th className="table-header">Amount</th><th className="table-header">Status</th></tr></thead>
          <tbody>
            {loading ? <tr><td colSpan={6} className="text-center py-8"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600 mx-auto"></div></td></tr> :
            invoices.length === 0 ? <tr><td colSpan={6} className="text-center py-8 text-gray-500">No invoices</td></tr> :
            invoices.map((inv) => (
              <tr key={inv._id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                <td className="table-cell font-medium">{inv.invoiceNumber}</td>
                <td className="table-cell">{(inv as any).user?.name || 'Unknown'}</td>
                <td className="table-cell">{inv.customerName}</td>
                <td className="table-cell text-sm">{new Date(inv.createdAt).toLocaleDateString()}</td>
                <td className="table-cell font-semibold">₹{inv.grandTotal.toLocaleString()}</td>
                <td className="table-cell"><span className={`badge ${inv.status === 'paid' ? 'badge-success' : inv.status === 'overdue' ? 'badge-danger' : 'badge-warning'}`}>{inv.status}</span></td>
              </tr>
            ))}
          </tbody></table>
        </div>
      </div>
    </div>
  );
}