import { useEffect, useState } from 'react';
import { dashboardAPI } from '@/utils/api';
import { AdminDashboardStats } from '@/types';
import { Users, UserCheck, CreditCard, AlertTriangle, TrendingUp, DollarSign, FileText, ShoppingBag, Truck, ClipboardList } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';

export default function AdminDashboard() {
  const [data, setData] = useState<{ stats: AdminDashboardStats; recentUsers: any[]; planDistribution: any[] } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadDashboard(); }, []);

  const loadDashboard = async () => {
    try { const res = await dashboardAPI.getAdmin(); setData(res.data); }
    catch (error) { console.error('Dashboard error:', error); }
    finally { setLoading(false); }
  };

  if (loading) {
    return (<div className="flex items-center justify-center h-96"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div></div>);
  }

  const stats = data?.stats;
  const planColors = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444'];

  const statCards = [
    { label: 'Total Users', value: stats?.totalUsers || 0, icon: Users, color: 'bg-blue-500' },
    { label: 'Active Users', value: stats?.activeUsers || 0, icon: UserCheck, color: 'bg-green-500' },
    { label: 'Subscriptions', value: stats?.totalSubscriptions || 0, icon: CreditCard, color: 'bg-purple-500' },
    { label: 'Expired', value: stats?.expiredSubscriptions || 0, icon: AlertTriangle, color: 'bg-red-500' },
    { label: 'Total Revenue', value: `₹${(stats?.totalRevenue || 0).toLocaleString()}`, icon: DollarSign, color: 'bg-emerald-500' },
    { label: 'Monthly Revenue', value: `₹${(stats?.monthlyRevenue || 0).toLocaleString()}`, icon: TrendingUp, color: 'bg-orange-500' },
  ];

  return (
    <div className="space-y-6">
      <div><h1 className="text-2xl font-bold text-gray-900 dark:text-white">Admin Dashboard</h1><p className="text-gray-500 dark:text-gray-400">Platform overview and analytics</p></div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {statCards.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="card hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <div className={`p-3 ${stat.color} rounded-lg`}><Icon className="w-5 h-5 text-white" /></div>
              </div>
              <div className="mt-4"><p className="text-2xl font-bold text-gray-900 dark:text-white">{stat.value}</p><p className="text-sm text-gray-500 dark:text-gray-400">{stat.label}</p></div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card">
          <h3 className="text-lg font-semibold mb-4">Subscription Plans</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={data?.planDistribution || []} cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={5} dataKey="count" nameKey="_id">
                  {(data?.planDistribution || []).map((_, index) => (<Cell key={`cell-${index}`} fill={planColors[index % planColors.length]} />))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap gap-4 justify-center mt-2">
            {(data?.planDistribution || []).map((plan, idx) => (
              <div key={plan._id} className="flex items-center gap-2"><div className="w-3 h-3 rounded-full" style={{ backgroundColor: planColors[idx % planColors.length] }} /><span className="text-sm text-gray-600 dark:text-gray-400 capitalize">{plan._id}: {plan.count}</span></div>
            ))}
          </div>
        </div>

        <div className="card">
          <h3 className="text-lg font-semibold mb-4">Document Statistics</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={[{ name: 'Invoices', count: stats?.invoicesCount || 0 }, { name: 'Quotations', count: stats?.quotationsCount || 0 }, { name: 'POs', count: stats?.posCount || 0 }, { name: 'DOs', count: stats?.dosCount || 0 }]}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200 dark:stroke-gray-700" />
                <XAxis dataKey="name" className="text-xs" /><YAxis className="text-xs" /><Tooltip contentStyle={{ backgroundColor: '#1f2937', border: 'none', borderRadius: '8px', color: '#fff' }} />
                <Bar dataKey="count" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="card">
        <h3 className="text-lg font-semibold mb-4">Recent Users</h3>
        <div className="overflow-x-auto">
          <table className="w-full"><thead><tr className="border-b border-gray-200 dark:border-gray-700"><th className="table-header">Name</th><th className="table-header">Email</th><th className="table-header">Role</th><th className="table-header">Status</th><th className="table-header">Joined</th></tr></thead>
          <tbody>
            {data?.recentUsers?.map((user) => (
              <tr key={user._id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                <td className="table-cell font-medium">{user.name}</td>
                <td className="table-cell">{user.email}</td>
                <td className="table-cell"><span className={`badge ${user.role === 'admin' ? 'badge-danger' : 'badge-info'}`}>{user.role}</span></td>
                <td className="table-cell"><span className={`badge ${user.isActive ? 'badge-success' : 'badge-danger'}`}>{user.isActive ? 'Active' : 'Inactive'}</span></td>
                <td className="table-cell text-sm">{new Date(user.createdAt).toLocaleDateString()}</td>
              </tr>
            )) || <tr><td colSpan={5} className="text-center py-4 text-gray-500">No users</td></tr>}
          </tbody></table>
        </div>
      </div>
    </div>
  );
}