import { useEffect, useState } from 'react';
import { userAPI } from '@/utils/api';
import { User, Subscription } from '@/types';
import { Plus, Search, Edit2, Trash2, UserCheck, UserX, CreditCard, Mail, Phone } from 'lucide-react';
import toast from 'react-hot-toast';

interface UserWithSub extends User {
  subscription?: Subscription;
}

export default function Users() {
  const [users, setUsers] = useState<UserWithSub[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({ name: '', email: '', password: '', role: 'user', phone: '', companyName: '', isActive: true });

  useEffect(() => { loadUsers(); }, []);

  const loadUsers = async () => {
    try { const res = await userAPI.getAll({ search: search || undefined }); setUsers(res.data.users); }
    catch (error) { toast.error('Failed to load users'); } finally { setLoading(false); }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email) { toast.error('Name and email required'); return; }
    try {
      if (editingId) {
        const updates: any = { name: formData.name, email: formData.email, role: formData.role, phone: formData.phone, companyName: formData.companyName, isActive: formData.isActive };
        await userAPI.update(editingId, updates);
        toast.success('User updated');
      } else {
        if (!formData.password) { toast.error('Password required for new user'); return; }
        await userAPI.create(formData);
        toast.success('User created');
      }
      setShowForm(false); setEditingId(null); setFormData({ name: '', email: '', password: '', role: 'user', phone: '', companyName: '', isActive: true });
      loadUsers();
    } catch (e: any) { toast.error(e.response?.data?.message || 'Failed'); }
  };

  const handleEdit = (user: UserWithSub) => {
    setFormData({ name: user.name, email: user.email, password: '', role: user.role, phone: user.phone || '', companyName: user.companyName || '', isActive: user.isActive });
    setEditingId(user.id); setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this user? All data will be lost.')) return;
    try { await userAPI.delete(id); toast.success('Deleted'); loadUsers(); } catch (e) { toast.error('Failed'); }
  };

  const handleToggleActive = async (user: UserWithSub) => {
    try { await userAPI.update(user.id, { isActive: !user.isActive }); toast.success(`User ${user.isActive ? 'deactivated' : 'activated'}`); loadUsers(); }
    catch (e) { toast.error('Failed'); }
  };

  const handleExtendSubscription = async (userId: string, days: number) => {
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + days);
    try {
      await userAPI.updateSubscription(userId, { plan: 'monthly', status: 'active', isDemo: false, endDate });
      toast.success(`Subscription extended by ${days} days`);
      loadUsers();
    } catch (e) { toast.error('Failed to extend'); }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-gray-900 dark:text-white">Users</h1><p className="text-gray-500 dark:text-gray-400">Manage all users and subscriptions</p></div>
        <button onClick={() => { setShowForm(true); setEditingId(null); setFormData({ name: '', email: '', password: '', role: 'user', phone: '', companyName: '', isActive: true }); }} className="btn-primary flex items-center gap-2"><Plus size={18} /> Add User</button>
      </div>

      <div className="card">
        <div className="flex gap-2 mb-4"><input type="text" value={search} onChange={(e) => setSearch(e.target.value)} onKeyPress={(e) => e.key === 'Enter' && loadUsers()} placeholder="Search users..." className="input-field" /><button onClick={loadUsers} className="btn-secondary"><Search size={18} /></button></div>
        {showForm && (
          <form onSubmit={handleSubmit} className="mb-6 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg space-y-4">
            <h3 className="font-semibold">{editingId ? 'Edit' : 'Add'} User</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <input type="text" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} className="input-field" placeholder="Name *" required />
              <input type="email" value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} className="input-field" placeholder="Email *" required />
              {!editingId && <input type="password" value={formData.password} onChange={(e) => setFormData({...formData, password: e.target.value})} className="input-field" placeholder="Password *" required={!editingId} />}
              <select value={formData.role} onChange={(e) => setFormData({...formData, role: e.target.value})} className="input-field"><option value="user">User</option><option value="admin">Admin</option></select>
              <input type="tel" value={formData.phone} onChange={(e) => setFormData({...formData, phone: e.target.value})} className="input-field" placeholder="Phone" />
              <input type="text" value={formData.companyName} onChange={(e) => setFormData({...formData, companyName: e.target.value})} className="input-field" placeholder="Company" />
              <label className="flex items-center gap-2"><input type="checkbox" checked={formData.isActive} onChange={(e) => setFormData({...formData, isActive: e.target.checked})} className="rounded" /><span className="text-sm">Active</span></label>
            </div>
            <div className="flex gap-2"><button type="submit" className="btn-primary">{editingId ? 'Update' : 'Create'}</button><button type="button" onClick={() => setShowForm(false)} className="btn-secondary">Cancel</button></div>
          </form>
        )}
        <div className="overflow-x-auto">
          <table className="w-full"><thead><tr className="border-b border-gray-200 dark:border-gray-700"><th className="table-header">User</th><th className="table-header">Contact</th><th className="table-header">Role</th><th className="table-header">Subscription</th><th className="table-header">Status</th><th className="table-header text-right">Actions</th></tr></thead>
          <tbody>
            {loading ? <tr><td colSpan={6} className="text-center py-8"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600 mx-auto"></div></td></tr> :
            users.length === 0 ? <tr><td colSpan={6} className="text-center py-8 text-gray-500">No users</td></tr> :
            users.map((u) => (
              <tr key={u.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                <td className="table-cell"><div><p className="font-medium">{u.name}</p><p className="text-xs text-gray-500">{u.companyName || 'No company'}</p></div></td>
                <td className="table-cell"><div className="space-y-1">{u.phone && <p className="text-sm flex items-center gap-1"><Phone size={12} />{u.phone}</p>}<p className="text-sm flex items-center gap-1"><Mail size={12} />{u.email}</p></div></td>
                <td className="table-cell"><span className={`badge ${u.role === 'admin' ? 'badge-danger' : 'badge-info'}`}>{u.role}</span></td>
                <td className="table-cell">
                  {u.subscription ? (
                    <div className="space-y-1">
                      <span className={`badge ${u.subscription.status === 'active' ? 'badge-success' : 'badge-danger'}`}>{u.subscription.plan} - {u.subscription.status}</span>
                      {u.subscription.isDemo && <p className="text-xs text-yellow-600">Demo expires: {new Date(u.subscription.demoExpiryDate!).toLocaleDateString()}</p>}
                      {u.subscription.endDate && !u.subscription.isDemo && <p className="text-xs text-gray-500">Expires: {new Date(u.subscription.endDate).toLocaleDateString()}</p>}
                    </div>
                  ) : <span className="badge badge-neutral">No subscription</span>}
                </td>
                <td className="table-cell"><span className={`badge ${u.isActive ? 'badge-success' : 'badge-danger'}`}>{u.isActive ? 'Active' : 'Inactive'}</span></td>
                <td className="table-cell text-right">
                  <div className="flex items-center justify-end gap-1 flex-wrap">
                    <button onClick={() => handleEdit(u)} className="p-1.5 hover:bg-gray-100 rounded-lg" title="Edit"><Edit2 size={16} /></button>
                    <button onClick={() => handleToggleActive(u)} className={`p-1.5 rounded-lg ${u.isActive ? 'hover:bg-red-50 text-red-600' : 'hover:bg-green-50 text-green-600'}`} title={u.isActive ? 'Deactivate' : 'Activate'}>{u.isActive ? <UserX size={16} /> : <UserCheck size={16} />}</button>
                    {u.subscription?.status === 'expired' && (
                      <><button onClick={() => handleExtendSubscription(u.id, 30)} className="p-1.5 hover:bg-blue-50 rounded-lg text-blue-600 text-xs" title="+30 days">+30d</button>
                      <button onClick={() => handleExtendSubscription(u.id, 365)} className="p-1.5 hover:bg-blue-50 rounded-lg text-blue-600 text-xs" title="+1 year">+1y</button></>
                    )}
                    <button onClick={() => handleDelete(u.id)} className="p-1.5 hover:bg-red-50 rounded-lg text-red-600" title="Delete"><Trash2 size={16} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody></table>
        </div>
      </div>
    </div>
  );
}