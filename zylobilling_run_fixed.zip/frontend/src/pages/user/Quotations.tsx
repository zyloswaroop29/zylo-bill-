import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { quotationAPI } from '@/utils/api';
import { Quotation } from '@/types';
import { Plus, Search, Eye, Edit2, Trash2, FileText, ArrowRightLeft } from 'lucide-react';
import toast from 'react-hot-toast';

export default function Quotations() {
  const [quotations, setQuotations] = useState<Quotation[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const navigate = useNavigate();

  useEffect(() => { loadQuotations(); }, []);

  const loadQuotations = async () => {
    try {
      const res = await quotationAPI.getAll({ search: search || undefined });
      setQuotations(res.data.quotations);
    } catch (error) { toast.error('Failed to load quotations'); }
    finally { setLoading(false); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this quotation?')) return;
    try { await quotationAPI.delete(id); toast.success('Deleted'); loadQuotations(); }
    catch (error) { toast.error('Failed to delete'); }
  };

  const handleConvert = async (id: string) => {
    try {
      const res = await quotationAPI.convert(id);
      toast.success('Converted to invoice!');
      navigate(`/invoices/${res.data.invoice._id}`);
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Conversion failed');
    }
  };

  const getStatusBadge = (status: string) => {
    const map: Record<string, string> = { draft: 'badge-neutral', sent: 'badge-info', accepted: 'badge-success', rejected: 'badge-danger', converted: 'badge-warning' };
    return map[status] || 'badge-neutral';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Quotations</h1>
          <p className="text-gray-500 dark:text-gray-400">Manage quotations and convert to invoices</p>
        </div>
        <button onClick={() => navigate('/quotations/create')} className="btn-primary flex items-center gap-2">
          <Plus size={18} /> Create Quotation
        </button>
      </div>

      <div className="card">
        <div className="flex gap-2 mb-4">
          <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} onKeyPress={(e) => e.key === 'Enter' && loadQuotations()} placeholder="Search..." className="input-field" />
          <button onClick={loadQuotations} className="btn-secondary"><Search size={18} /></button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead><tr className="border-b border-gray-200 dark:border-gray-700">
              <th className="table-header">Quote #</th><th className="table-header">Customer</th><th className="table-header">Valid Until</th>
              <th className="table-header">Amount</th><th className="table-header">Status</th><th className="table-header text-right">Actions</th>
            </tr></thead>
            <tbody>
              {loading ? <tr><td colSpan={6} className="text-center py-8"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600 mx-auto"></div></td></tr> :
              quotations.length === 0 ? <tr><td colSpan={6} className="text-center py-8 text-gray-500">No quotations</td></tr> :
              quotations.map((q) => (
                <tr key={q._id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                  <td className="table-cell font-medium">{q.quotationNumber}</td>
                  <td className="table-cell">{q.customerName}</td>
                  <td className="table-cell">{new Date(q.validUntil).toLocaleDateString()}</td>
                  <td className="table-cell font-semibold">₹{q.grandTotal.toLocaleString()}</td>
                  <td className="table-cell"><span className={`badge ${getStatusBadge(q.status)}`}>{q.status}</span></td>
                  <td className="table-cell text-right">
                    <div className="flex items-center justify-end gap-1">
                      <button onClick={() => navigate(`/quotations/${q._id}`)} className="p-1.5 hover:bg-gray-100 rounded-lg" title="View"><Eye size={16} /></button>
                      {q.status !== 'converted' && (
                        <button onClick={() => handleConvert(q._id)} className="p-1.5 hover:bg-green-50 rounded-lg text-green-600" title="Convert to Invoice"><ArrowRightLeft size={16} /></button>
                      )}
                      <button onClick={() => handleDelete(q._id)} className="p-1.5 hover:bg-red-50 rounded-lg text-red-600" title="Delete"><Trash2 size={16} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}