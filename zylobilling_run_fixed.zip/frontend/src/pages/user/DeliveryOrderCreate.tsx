import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { doAPI, customerAPI, productAPI } from '@/utils/api';
import { Customer, Product } from '@/types';
import { Plus, Trash2, Save, X, Truck } from 'lucide-react';
import toast from 'react-hot-toast';

interface FormItem { product?: string; name: string; quantity: number; unit: string; }

export default function DeliveryOrderCreate() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEdit = !!id;
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState('');
  const [items, setItems] = useState<FormItem[]>([{ name: '', quantity: 1, unit: 'pcs' }]);
  const [deliveryDate, setDeliveryDate] = useState('');
  const [trackingNumber, setTrackingNumber] = useState('');
  const [carrier, setCarrier] = useState('');
  const [notes, setNotes] = useState('');
  const [status, setStatus] = useState('preparing');
  const [saving, setSaving] = useState(false);

  useEffect(() => { loadCustomers(); loadProducts(); if (isEdit) loadDO(); }, [id]);

  const loadCustomers = async () => { try { const res = await customerAPI.getAll({ limit: 1000 }); setCustomers(res.data.customers); } catch (e) {} };
  const loadProducts = async () => { try { const res = await productAPI.getAll({ limit: 1000 }); setProducts(res.data.products); } catch (e) {} };
  const loadDO = async () => {
    try { const res = await doAPI.getById(id!); const d = res.data.deliveryOrder; setSelectedCustomer(d.customer._id || d.customer); setItems(d.items.map((i: any) => ({ product: i.product?._id, name: i.name, quantity: i.quantity, unit: i.unit }))); setDeliveryDate(new Date(d.deliveryDate).toISOString().split('T')[0]); setTrackingNumber(d.trackingNumber || ''); setCarrier(d.carrier || ''); setNotes(d.notes || ''); setStatus(d.status); } catch (e) { navigate('/delivery-orders'); }
  };

  const addItem = () => setItems([...items, { name: '', quantity: 1, unit: 'pcs' }]);
  const removeItem = (index: number) => { if (items.length === 1) return; setItems(items.filter((_, i) => i !== index)); };
  const updateItem = (index: number, field: keyof FormItem, value: any) => {
    const newItems = [...items]; newItems[index] = { ...newItems[index], [field]: value };
    if (field === 'product' && value) { const p = products.find(pr => pr._id === value); if (p) { newItems[index].name = p.name; newItems[index].unit = p.unit; } }
    setItems(newItems);
  };

  const handleSubmit = async () => {
    if (!selectedCustomer) { toast.error('Select customer'); return; }
    if (!deliveryDate) { toast.error('Set delivery date'); return; }
    if (items.some(i => !i.name || i.quantity <= 0)) { toast.error('Fill all items'); return; }
    const customer = customers.find(c => c._id === selectedCustomer);
    setSaving(true);
    try {
      const payload = { customer: selectedCustomer, customerName: customer?.name || '', customerAddress: customer?.address || '', items, deliveryDate, trackingNumber, carrier, notes, status };
      if (isEdit) { await doAPI.update(id!, payload); toast.success('Updated'); } else { await doAPI.create(payload); toast.success('Created'); }
      navigate('/delivery-orders');
    } catch (e: any) { toast.error(e.response?.data?.message || 'Failed'); } finally { setSaving(false); }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{isEdit ? 'Edit' : 'Create'} Delivery Order</h1>
        <div className="flex gap-2"><button onClick={() => navigate('/delivery-orders')} className="btn-secondary flex items-center gap-2"><X size={18} /> Cancel</button><button onClick={handleSubmit} disabled={saving} className="btn-primary flex items-center gap-2"><Save size={18} /> {saving ? 'Saving...' : isEdit ? 'Update' : 'Create'}</button></div>
      </div>
      <div className="card">
        <h3 className="text-lg font-semibold mb-4">Customer</h3>
        <select value={selectedCustomer} onChange={(e) => setSelectedCustomer(e.target.value)} className="input-field"><option value="">Select Customer</option>{customers.map(c => <option key={c._id} value={c._id}>{c.name}</option>)}</select>
      </div>
      <div className="card">
        <div className="flex justify-between mb-4"><h3 className="text-lg font-semibold">Items</h3><button onClick={addItem} className="btn-secondary text-sm flex items-center gap-1"><Plus size={16} /> Add</button></div>
        <div className="space-y-4">
          {items.map((item, idx) => (
            <div key={idx} className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg space-y-3">
              <div className="flex justify-between"><span className="text-sm font-medium text-gray-500">Item #{idx + 1}</span><button onClick={() => removeItem(idx)} className="text-red-500"><Trash2 size={16} /></button></div>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                <div className="md:col-span-2"><select value={item.product || ''} onChange={(e) => updateItem(idx, 'product', e.target.value)} className="input-field text-sm"><option value="">Select Product</option>{products.map(p => <option key={p._id} value={p._id}>{p.name}</option>)}</select></div>
                <div><input type="text" value={item.name} onChange={(e) => updateItem(idx, 'name', e.target.value)} className="input-field text-sm" placeholder="Name" /></div>
                <div><input type="number" value={item.quantity} onChange={(e) => updateItem(idx, 'quantity', Number(e.target.value))} className="input-field text-sm" min="1" /></div>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="card space-y-4">
          <h3 className="text-lg font-semibold">Delivery Details</h3>
          <div><label className="text-sm text-gray-500">Delivery Date *</label><input type="date" value={deliveryDate} onChange={(e) => setDeliveryDate(e.target.value)} className="input-field" /></div>
          <div><label className="text-sm text-gray-500">Tracking Number</label><input type="text" value={trackingNumber} onChange={(e) => setTrackingNumber(e.target.value)} className="input-field" placeholder="Tracking #" /></div>
          <div><label className="text-sm text-gray-500">Carrier</label><input type="text" value={carrier} onChange={(e) => setCarrier(e.target.value)} className="input-field" placeholder="Carrier name" /></div>
          <div><label className="text-sm text-gray-500">Status</label><select value={status} onChange={(e) => setStatus(e.target.value)} className="input-field"><option value="preparing">Preparing</option><option value="shipped">Shipped</option><option value="in_transit">In Transit</option><option value="delivered">Delivered</option><option value="returned">Returned</option></select></div>
        </div>
        <div className="card space-y-4">
          <h3 className="text-lg font-semibold">Notes</h3>
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={6} className="input-field" placeholder="Delivery notes..." />
        </div>
      </div>
    </div>
  );
}