import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { invoiceAPI } from '@/utils/api';
import { Invoice } from '@/types';
import { Plus, Search, Filter, Download, Eye, Edit2, Trash2, FileText, Printer, Share2 } from 'lucide-react';
import toast from 'react-hot-toast';

export default function Invoices() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const navigate = useNavigate();

  useEffect(() => {
    loadInvoices();
  }, [page, statusFilter]);

  const loadInvoices = async () => {
    try {
      setLoading(true);
      const res = await invoiceAPI.getAll({ 
        search: search || undefined, 
        status: statusFilter || undefined,
        page, 
        limit: 20 
      });
      setInvoices(res.data.invoices);
      setTotalPages(res.data.pagination.pages);
    } catch (error) {
      toast.error('Failed to load invoices');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    setPage(1);
    loadInvoices();
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this invoice?')) return;
    try {
      await invoiceAPI.delete(id);
      toast.success('Invoice deleted');
      loadInvoices();
    } catch (error) {
      toast.error('Failed to delete invoice');
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'paid': return 'badge-success';
      case 'overdue': return 'badge-danger';
      case 'sent': return 'badge-info';
      case 'draft': return 'badge-neutral';
      case 'cancelled': return 'badge-danger';
      default: return 'badge-neutral';
    }
  };

  const shareOnWhatsApp = (invoice: Invoice) => {
    const message = `Invoice: ${invoice.invoiceNumber}\nAmount: ₹${invoice.grandTotal.toLocaleString()}\nStatus: ${invoice.status}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Invoices</h1>
          <p className="text-gray-500 dark:text-gray-400">Manage your invoices</p>
        </div>
        <button onClick={() => navigate('/invoices/create')} className="btn-primary flex items-center gap-2">
          <Plus size={18} />
          Create Invoice
        </button>
      </div>

      {/* Filters */}
      <div className="card">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                placeholder="Search invoices..."
                className="input-field pl-10"
              />
            </div>
            <button onClick={handleSearch} className="btn-secondary">
              <Search size={18} />
            </button>
          </div>
          <select
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value); setPage(1); }}
            className="input-field w-full sm:w-40"
          >
            <option value="">All Status</option>
            <option value="draft">Draft</option>
            <option value="sent">Sent</option>
            <option value="paid">Paid</option>
            <option value="overdue">Overdue</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="card overflow-hidden p-0">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200 dark:border-gray-700">
                <th className="table-header">Invoice #</th>
                <th className="table-header">Customer</th>
                <th className="table-header">Date</th>
                <th className="table-header">Amount</th>
                <th className="table-header">Status</th>
                <th className="table-header text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={6} className="text-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600 mx-auto"></div>
                  </td>
                </tr>
              ) : invoices.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-8 text-gray-500 dark:text-gray-400">
                    No invoices found
                  </td>
                </tr>
              ) : (
                invoices.map((invoice) => (
                  <tr key={invoice._id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                    <td className="table-cell font-medium">{invoice.invoiceNumber}</td>
                    <td className="table-cell">{invoice.customerName}</td>
                    <td className="table-cell">{new Date(invoice.createdAt).toLocaleDateString()}</td>
                    <td className="table-cell font-semibold">₹{invoice.grandTotal.toLocaleString()}</td>
                    <td className="table-cell">
                      <span className={`badge ${getStatusBadge(invoice.status)}`}>
                        {invoice.status}
                      </span>
                    </td>
                    <td className="table-cell text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button onClick={() => navigate(`/invoices/${invoice._id}`)} className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg" title="View">
                          <Eye size={16} />
                        </button>
                        <button onClick={() => navigate(`/invoices/${invoice._id}/edit`)} className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg" title="Edit">
                          <Edit2 size={16} />
                        </button>
                        <button onClick={() => shareOnWhatsApp(invoice)} className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg text-green-600" title="Share WhatsApp">
                          <Share2 size={16} />
                        </button>
                        <button onClick={() => handleDelete(invoice._id)} className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg text-red-600" title="Delete">
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-gray-200 dark:border-gray-700">
            <button
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page === 1}
              className="btn-secondary text-sm disabled:opacity-50"
            >
              Previous
            </button>
            <span className="text-sm text-gray-500 dark:text-gray-400">
              Page {page} of {totalPages}
            </span>
            <button
              onClick={() => setPage(p => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="btn-secondary text-sm disabled:opacity-50"
            >
              Next
            </button>
          </div>
        )}
      </div>
    </div>
  );
}