import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { poAPI } from '@/utils/api';
import { PurchaseOrder } from '@/types';
import { Plus, Search, Eye, Edit2, Trash2, Download } from 'lucide-react';
import toast from 'react-hot-toast';

export default function PurchaseOrders() {
  const [pos, setPos] = useState<PurchaseOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const navigate = useNavigate();

  useEffect(() => { loadPOs(); }, []);

  const loadPOs = async () => {
    try { const res = await poAPI.getAll({ search: search || undefined }); setPos(res.data.purchaseOrders); }
    catch (error) { toast.error('Failed to load'); } finally { setLoading(false); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete?')) return;
    try { await poAPI.delete(id); toast.success('Deleted'); loadPOs(); } catch (e) { toast.error('Failed'); }
  };

  const getStatusBadge = (status: string) => {
    const map: Record<string, string> = { draft: 'badge-neutral', sent: 'badge-info', received: 'badge-success', cancelled: 'badge-danger' };
    return map[status] || 'badge-neutral';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-gray-900 dark:text-white">Purchase Orders</h1><p className="text-gray-500 dark:text-gray-400">Manage purchase orders</p></div>
        <button onClick={() => navigate('/purchase-orders/create')} className="btn-primary flex items-center gap-2"><Plus size={18} /> Create PO</button>
      </div>
      <div className="card">
        <div className="flex gap-2 mb-4"><input type="text" value={search} onChange={(e) => setSearch(e.target.value)} onKeyPress={(e) => e.key === 'Enter' && loadPOs()} placeholder="Search..." className="input-field" /><button onClick={loadPOs} className="btn-secondary"><Search size={18} /></button></div>
        <div className="overflow-x-auto">
          <table className="w-full"><thead><tr className="border-b border-gray-200 dark:border-gray-700"><th className="table-header">PO #</th><th className="table-header">Supplier</th><th className="table-header">Order Date</th><th className="table-header">Amount</th><th className="table-header">Status</th><th className="table-header text-right">Actions</th></tr></thead>
          <tbody>
            {loading ? <tr><td colSpan={6} className="text-center py-8"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600 mx-auto"></div></td></tr> :
            pos.length === 0 ? <tr><td colSpan={6} className="text-center py-8 text-gray-500">No purchase orders</td></tr> :
            pos.map((po) => (
              <tr key={po._id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                <td className="table-cell font-medium">{po.poNumber}</td><td className="table-cell">{po.supplier}</td>
                <td className="table-cell">{new Date(po.orderDate).toLocaleDateString()}</td>
                <td className="table-cell font-semibold">₹{po.grandTotal.toLocaleString()}</td>
                <td className="table-cell"><span className={`badge ${getStatusBadge(po.status)}`}>{po.status}</span></td>
                <td className="table-cell text-right"><div className="flex items-center justify-end gap-1"><button onClick={() => navigate(`/purchase-orders/${po._id}`)} className="p-1.5 hover:bg-gray-100 rounded-lg"><Eye size={16} /></button><button onClick={() => handleDelete(po._id)} className="p-1.5 hover:bg-red-50 rounded-lg text-red-600"><Trash2 size={16} /></button></div></td>
              </tr>
            ))}
          </tbody></table>
        </div>
      </div>
    </div>
  );
}