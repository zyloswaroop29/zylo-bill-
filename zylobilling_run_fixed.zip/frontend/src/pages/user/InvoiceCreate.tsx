import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { invoiceAPI, customerAPI, productAPI } from '@/utils/api';
import { Customer, Product, InvoiceItem } from '@/types';
import { Plus, Trash2, Save, X, Calculator } from 'lucide-react';
import toast from 'react-hot-toast';

interface FormItem {
  product?: string;
  name: string;
  description?: string;
  quantity: number;
  unitPrice: number;
  taxRate: number;
  discount: number;
}

export default function InvoiceCreate() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEdit = !!id;

  const [customers, setCustomers] = useState<Customer[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState('');
  const [items, setItems] = useState<FormItem[]>([{ name: '', quantity: 1, unitPrice: 0, taxRate: 18, discount: 0 }]);
  const [dueDate, setDueDate] = useState('');
  const [notes, setNotes] = useState('');
  const [terms, setTerms] = useState('');
  const [status, setStatus] = useState('draft');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadCustomers();
    loadProducts();
    if (isEdit) loadInvoice();
  }, [id]);

  const loadCustomers = async () => {
    try {
      const res = await customerAPI.getAll({ limit: 1000 });
      setCustomers(res.data.customers);
    } catch (error) { console.error('Failed to load customers'); }
  };

  const loadProducts = async () => {
    try {
      const res = await productAPI.getAll({ limit: 1000 });
      setProducts(res.data.products);
    } catch (error) { console.error('Failed to load products'); }
  };

  const loadInvoice = async () => {
    try {
      setLoading(true);
      const res = await invoiceAPI.getById(id!);
      const invoice = res.data.invoice;
      setSelectedCustomer(invoice.customer._id || invoice.customer);
      setItems(invoice.items.map((item: any) => ({
        product: item.product?._id || item.product,
        name: item.name,
        description: item.description,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        taxRate: item.taxRate,
        discount: item.discount
      })));
      setDueDate(invoice.dueDate ? new Date(invoice.dueDate).toISOString().split('T')[0] : '');
      setNotes(invoice.notes || '');
      setTerms(invoice.terms || '');
      setStatus(invoice.status);
    } catch (error) {
      toast.error('Failed to load invoice');
      navigate('/invoices');
    } finally {
      setLoading(false);
    }
  };

  const addItem = () => {
    setItems([...items, { name: '', quantity: 1, unitPrice: 0, taxRate: 18, discount: 0 }]);
  };

  const removeItem = (index: number) => {
    if (items.length === 1) {
      toast.error('At least one item required');
      return;
    }
    setItems(items.filter((_, i) => i !== index));
  };

  const updateItem = (index: number, field: keyof FormItem, value: any) => {
    const newItems = [...items];
    newItems[index] = { ...newItems[index], [field]: value };

    // Auto-fill product details
    if (field === 'product' && value) {
      const product = products.find(p => p._id === value);
      if (product) {
        newItems[index].name = product.name;
        newItems[index].unitPrice = product.price;
        newItems[index].taxRate = product.taxRate;
      }
    }

    setItems(newItems);
  };

  const calculateTotals = () => {
    let subTotal = 0;
    let totalTax = 0;
    let totalDiscount = 0;

    items.forEach(item => {
      const itemTotal = item.quantity * item.unitPrice;
      const itemDiscount = (itemTotal * item.discount) / 100;
      const taxableAmount = itemTotal - itemDiscount;
      const itemTax = (taxableAmount * item.taxRate) / 100;

      subTotal += itemTotal;
      totalDiscount += itemDiscount;
      totalTax += itemTax;
    });

    return { subTotal, totalTax, totalDiscount, grandTotal: subTotal - totalDiscount + totalTax };
  };

  const handleSubmit = async () => {
    if (!selectedCustomer) {
      toast.error('Please select a customer');
      return;
    }
    if (items.some(item => !item.name || item.quantity <= 0)) {
      toast.error('Please fill all item details');
      return;
    }

    const customer = customers.find(c => c._id === selectedCustomer);
    const totals = calculateTotals();

    const payload = {
      customer: selectedCustomer,
      customerName: customer?.name || '',
      customerAddress: customer?.address || '',
      customerGst: customer?.gstNumber || '',
      items: items.map(item => ({
        product: item.product,
        name: item.name,
        description: item.description,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        taxRate: item.taxRate,
        discount: item.discount
      })),
      dueDate: dueDate || undefined,
      notes,
      terms,
      status
    };

    setSaving(true);
    try {
      if (isEdit) {
        await invoiceAPI.update(id!, payload);
        toast.success('Invoice updated');
      } else {
        await invoiceAPI.create(payload);
        toast.success('Invoice created');
      }
      navigate('/invoices');
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to save invoice');
    } finally {
      setSaving(false);
    }
  };

  const totals = calculateTotals();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            {isEdit ? 'Edit Invoice' : 'Create Invoice'}
          </h1>
          <p className="text-gray-500 dark:text-gray-400">
            {isEdit ? 'Update invoice details' : 'Create a new invoice'}
          </p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => navigate('/invoices')} className="btn-secondary flex items-center gap-2">
            <X size={18} />
            Cancel
          </button>
          <button onClick={handleSubmit} disabled={saving} className="btn-primary flex items-center gap-2">
            <Save size={18} />
            {saving ? 'Saving...' : isEdit ? 'Update' : 'Create'}
          </button>
        </div>
      </div>

      {/* Customer Selection */}
      <div className="card">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Customer</h3>
        <select
          value={selectedCustomer}
          onChange={(e) => setSelectedCustomer(e.target.value)}
          className="input-field"
        >
          <option value="">Select Customer</option>
          {customers.map(c => (
            <option key={c._id} value={c._id}>{c.name} {c.gstNumber ? `(GST: ${c.gstNumber})` : ''}</option>
          ))}
        </select>
        {selectedCustomer && (() => {
          const customer = customers.find(c => c._id === selectedCustomer);
          return customer ? (
            <div className="mt-3 p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg text-sm">
              <p><strong>{customer.name}</strong></p>
              {customer.address && <p className="text-gray-500">{customer.address}, {customer.city}, {customer.state}</p>}
              {customer.gstNumber && <p className="text-gray-500">GST: {customer.gstNumber}</p>}
              {customer.phone && <p className="text-gray-500">Phone: {customer.phone}</p>}
            </div>
          ) : null;
        })()}
      </div>

      {/* Items */}
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Items</h3>
          <button onClick={addItem} className="btn-secondary text-sm flex items-center gap-1">
            <Plus size={16} />
            Add Item
          </button>
        </div>

        <div className="space-y-4">
          {items.map((item, index) => (
            <div key={index} className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Item #{index + 1}</span>
                <button onClick={() => removeItem(index)} className="text-red-500 hover:text-red-700">
                  <Trash2 size={16} />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-3">
                <div className="lg:col-span-2">
                  <label className="text-xs text-gray-500 dark:text-gray-400">Product</label>
                  <select
                    value={item.product || ''}
                    onChange={(e) => updateItem(index, 'product', e.target.value)}
                    className="input-field text-sm"
                  >
                    <option value="">Select or type manually</option>
                    {products.map(p => (
                      <option key={p._id} value={p._id}>{p.name} (₹{p.price})</option>
                    ))}
                  </select>
                </div>
                <div className="lg:col-span-2">
                  <label className="text-xs text-gray-500 dark:text-gray-400">Name *</label>
                  <input
                    type="text"
                    value={item.name}
                    onChange={(e) => updateItem(index, 'name', e.target.value)}
                    className="input-field text-sm"
                    placeholder="Item name"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-500 dark:text-gray-400">Qty</label>
                  <input
                    type="number"
                    value={item.quantity}
                    onChange={(e) => updateItem(index, 'quantity', Number(e.target.value))}
                    className="input-field text-sm"
                    min="1"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-500 dark:text-gray-400">Price</label>
                  <input
                    type="number"
                    value={item.unitPrice}
                    onChange={(e) => updateItem(index, 'unitPrice', Number(e.target.value))}
                    className="input-field text-sm"
                    min="0"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-500 dark:text-gray-400">Tax %</label>
                  <input
                    type="number"
                    value={item.taxRate}
                    onChange={(e) => updateItem(index, 'taxRate', Number(e.target.value))}
                    className="input-field text-sm"
                    min="0"
                    max="100"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-500 dark:text-gray-400">Disc %</label>
                  <input
                    type="number"
                    value={item.discount}
                    onChange={(e) => updateItem(index, 'discount', Number(e.target.value))}
                    className="input-field text-sm"
                    min="0"
                    max="100"
                  />
                </div>
              </div>

              <div className="text-right text-sm font-medium text-primary-600 dark:text-primary-400">
                Line Total: ₹{((item.quantity * item.unitPrice * (1 - item.discount/100)) * (1 + item.taxRate/100)).toFixed(2)}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Totals */}
      <div className="card">
        <div className="flex justify-end">
          <div className="w-full max-w-md space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-500 dark:text-gray-400">Sub Total:</span>
              <span className="font-medium">₹{totals.subTotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-500 dark:text-gray-400">Discount:</span>
              <span className="font-medium text-green-600">-₹{totals.totalDiscount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-500 dark:text-gray-400">Tax:</span>
              <span className="font-medium">₹{totals.totalTax.toFixed(2)}</span>
            </div>
            <div className="border-t border-gray-200 dark:border-gray-700 pt-2 flex justify-between">
              <span className="font-semibold text-gray-900 dark:text-white">Grand Total:</span>
              <span className="font-bold text-xl text-primary-600 dark:text-primary-400">₹{totals.grandTotal.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Additional Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="card space-y-4">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Details</h3>
          <div>
            <label className="text-sm text-gray-500 dark:text-gray-400">Due Date</label>
            <input
              type="date"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
              className="input-field"
            />
          </div>
          <div>
            <label className="text-sm text-gray-500 dark:text-gray-400">Status</label>
            <select value={status} onChange={(e) => setStatus(e.target.value)} className="input-field">
              <option value="draft">Draft</option>
              <option value="sent">Sent</option>
              <option value="paid">Paid</option>
              <option value="overdue">Overdue</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>
        </div>
        <div className="card space-y-4">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Notes & Terms</h3>
          <div>
            <label className="text-sm text-gray-500 dark:text-gray-400">Notes</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
              className="input-field"
              placeholder="Additional notes..."
            />
          </div>
          <div>
            <label className="text-sm text-gray-500 dark:text-gray-400">Terms & Conditions</label>
            <textarea
              value={terms}
              onChange={(e) => setTerms(e.target.value)}
              rows={2}
              className="input-field"
              placeholder="Payment terms..."
            />
          </div>
        </div>
      </div>
    </div>
  );
}