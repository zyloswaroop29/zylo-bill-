import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { drAPI } from '@/utils/api';
import { DeliveryRequest } from '@/types';
import { Plus, Search, Eye, Edit2, Trash2, CheckCircle, XCircle, Clock } from 'lucide-react';
import toast from 'react-hot-toast';

export default function DeliveryRequests() {
  const [requests, setRequests] = useState<DeliveryRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const navigate = useNavigate();

  useEffect(() => { loadRequests(); }, []);

  const loadRequests = async () => {
    try { const res = await drAPI.getAll({ search: search || undefined }); setRequests(res.data.deliveryRequests); }
    catch (error) { toast.error('Failed to load'); } finally { setLoading(false); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete?')) return;
    try { await drAPI.delete(id); toast.success('Deleted'); loadRequests(); } catch (e) { toast.error('Failed'); }
  };

  const handleApprove = async (id: string) => {
    try { await drAPI.approve(id, 'approved'); toast.success('Approved'); loadRequests(); } catch (e) { toast.error('Failed'); }
  };

  const handleReject = async (id: string) => {
    const reason = prompt('Rejection reason:');
    if (reason === null) return;
    try { await drAPI.approve(id, 'rejected', reason); toast.success('Rejected'); loadRequests(); } catch (e) { toast.error('Failed'); }
  };

  const getStatusBadge = (status: string) => {
    const map: Record<string, string> = { pending: 'badge-warning', approved: 'badge-success', rejected: 'badge-danger', processing: 'badge-info', completed: 'badge-success' };
    return map[status] || 'badge-neutral';
  };

  const getPriorityBadge = (priority: string) => {
    const map: Record<string, string> = { low: 'badge-neutral', medium: 'badge-info', high: 'badge-warning', urgent: 'badge-danger' };
    return map[priority] || 'badge-neutral';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-gray-900 dark:text-white">Delivery Requests</h1><p className="text-gray-500 dark:text-gray-400">Manage delivery requests with approval workflow</p></div>
        <button onClick={() => navigate('/delivery-requests/create')} className="btn-primary flex items-center gap-2"><Plus size={18} /> Create Request</button>
      </div>
      <div className="card">
        <div className="flex gap-2 mb-4"><input type="text" value={search} onChange={(e) => setSearch(e.target.value)} onKeyPress={(e) => e.key === 'Enter' && loadRequests()} placeholder="Search..." className="input-field" /><button onClick={loadRequests} className="btn-secondary"><Search size={18} /></button></div>
        <div className="overflow-x-auto">
          <table className="w-full"><thead><tr className="border-b border-gray-200 dark:border-gray-700"><th className="table-header">Request #</th><th className="table-header">Customer</th><th className="table-header">Required Date</th><th className="table-header">Priority</th><th className="table-header">Status</th><th className="table-header text-right">Actions</th></tr></thead>
          <tbody>
            {loading ? <tr><td colSpan={6} className="text-center py-8"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600 mx-auto"></div></td></tr> :
            requests.length === 0 ? <tr><td colSpan={6} className="text-center py-8 text-gray-500">No delivery requests</td></tr> :
            requests.map((r) => (
              <tr key={r._id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                <td className="table-cell font-medium">{r.requestNumber}</td><td className="table-cell">{r.customerName}</td>
                <td className="table-cell">{new Date(r.requiredDate).toLocaleDateString()}</td>
                <td className="table-cell"><span className={`badge ${getPriorityBadge(r.priority)}`}>{r.priority}</span></td>
                <td className="table-cell"><span className={`badge ${getStatusBadge(r.status)}`}>{r.status}</span></td>
                <td className="table-cell text-right">
                  <div className="flex items-center justify-end gap-1">
                    <button onClick={() => navigate(`/delivery-requests/${r._id}`)} className="p-1.5 hover:bg-gray-100 rounded-lg"><Eye size={16} /></button>
                    {r.status === 'pending' && (
                      <><button onClick={() => handleApprove(r._id)} className="p-1.5 hover:bg-green-50 rounded-lg text-green-600"><CheckCircle size={16} /></button>
                      <button onClick={() => handleReject(r._id)} className="p-1.5 hover:bg-red-50 rounded-lg text-red-600"><XCircle size={16} /></button></>
                    )}
                    <button onClick={() => handleDelete(r._id)} className="p-1.5 hover:bg-red-50 rounded-lg text-red-600"><Trash2 size={16} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody></table>
        </div>
      </div>
    </div>
  );
}