import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { doAPI } from '@/utils/api';
import { DeliveryOrder } from '@/types';
import { Plus, Search, Eye, Edit2, Trash2, Truck } from 'lucide-react';
import toast from 'react-hot-toast';

export default function DeliveryOrders() {
  const [dos, setDos] = useState<DeliveryOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const navigate = useNavigate();

  useEffect(() => { loadDOs(); }, []);

  const loadDOs = async () => {
    try { const res = await doAPI.getAll({ search: search || undefined }); setDos(res.data.deliveryOrders); }
    catch (error) { toast.error('Failed to load'); } finally { setLoading(false); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete?')) return;
    try { await doAPI.delete(id); toast.success('Deleted'); loadDOs(); } catch (e) { toast.error('Failed'); }
  };

  const getStatusBadge = (status: string) => {
    const map: Record<string, string> = { preparing: 'badge-neutral', shipped: 'badge-info', in_transit: 'badge-warning', delivered: 'badge-success', returned: 'badge-danger' };
    return map[status] || 'badge-neutral';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-gray-900 dark:text-white">Delivery Orders</h1><p className="text-gray-500 dark:text-gray-400">Track deliveries</p></div>
        <button onClick={() => navigate('/delivery-orders/create')} className="btn-primary flex items-center gap-2"><Plus size={18} /> Create DO</button>
      </div>
      <div className="card">
        <div className="flex gap-2 mb-4"><input type="text" value={search} onChange={(e) => setSearch(e.target.value)} onKeyPress={(e) => e.key === 'Enter' && loadDOs()} placeholder="Search..." className="input-field" /><button onClick={loadDOs} className="btn-secondary"><Search size={18} /></button></div>
        <div className="overflow-x-auto">
          <table className="w-full"><thead><tr className="border-b border-gray-200 dark:border-gray-700"><th className="table-header">DO #</th><th className="table-header">Customer</th><th className="table-header">Delivery Date</th><th className="table-header">Status</th><th className="table-header">Tracking</th><th className="table-header text-right">Actions</th></tr></thead>
          <tbody>
            {loading ? <tr><td colSpan={6} className="text-center py-8"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600 mx-auto"></div></td></tr> :
            dos.length === 0 ? <tr><td colSpan={6} className="text-center py-8 text-gray-500">No delivery orders</td></tr> :
            dos.map((d) => (
              <tr key={d._id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                <td className="table-cell font-medium">{d.doNumber}</td><td className="table-cell">{d.customerName}</td>
                <td className="table-cell">{new Date(d.deliveryDate).toLocaleDateString()}</td>
                <td className="table-cell"><span className={`badge ${getStatusBadge(d.status)}`}>{d.status.replace('_', ' ')}</span></td>
                <td className="table-cell text-sm">{d.trackingNumber || '-'}</td>
                <td className="table-cell text-right"><div className="flex items-center justify-end gap-1"><button onClick={() => navigate(`/delivery-orders/${d._id}`)} className="p-1.5 hover:bg-gray-100 rounded-lg"><Eye size={16} /></button><button onClick={() => handleDelete(d._id)} className="p-1.5 hover:bg-red-50 rounded-lg text-red-600"><Trash2 size={16} /></button></div></td>
              </tr>
            ))}
          </tbody></table>
        </div>
      </div>
    </div>
  );
}