import { useEffect, useState } from 'react';
import { companyAPI } from '@/utils/api';
import { Company } from '@/types';
import { Building2, Save, Globe, Banknote, FileText } from 'lucide-react';
import toast from 'react-hot-toast';

export default function CompanySettings() {
  const [company, setCompany] = useState<Company | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState<Partial<Company>>({});

  useEffect(() => { loadCompany(); }, []);

  const loadCompany = async () => {
    try {
      const res = await companyAPI.get();
      setCompany(res.data.company);
      setFormData(res.data.company);
    } catch (error) { toast.error('Failed to load company settings'); }
    finally { setLoading(false); }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await companyAPI.update(formData);
      setCompany(res.data.company);
      toast.success('Company settings saved');
    } catch (e: any) { toast.error(e.response?.data?.message || 'Failed to save'); }
    finally { setSaving(false); }
  };

  if (loading) {
    return (<div className="flex items-center justify-center h-96"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div></div>);
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-gray-900 dark:text-white">Company Settings</h1><p className="text-gray-500 dark:text-gray-400">Manage your business profile and preferences</p></div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Company Info */}
        <div className="card space-y-4">
          <div className="flex items-center gap-2 mb-2"><Building2 size={20} className="text-primary-600" /><h3 className="text-lg font-semibold">Company Information</h3></div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div><label className="text-sm text-gray-500 dark:text-gray-400">Company Name *</label><input type="text" value={formData.name || ''} onChange={(e) => setFormData({...formData, name: e.target.value})} className="input-field" required /></div>
            <div><label className="text-sm text-gray-500 dark:text-gray-400">Email</label><input type="email" value={formData.email || ''} onChange={(e) => setFormData({...formData, email: e.target.value})} className="input-field" /></div>
            <div><label className="text-sm text-gray-500 dark:text-gray-400">Phone</label><input type="tel" value={formData.phone || ''} onChange={(e) => setFormData({...formData, phone: e.target.value})} className="input-field" /></div>
            <div><label className="text-sm text-gray-500 dark:text-gray-400">GST Number</label><input type="text" value={formData.gstNumber || ''} onChange={(e) => setFormData({...formData, gstNumber: e.target.value})} className="input-field" placeholder="27AADCB2230M1ZT" /></div>
            <div><label className="text-sm text-gray-500 dark:text-gray-400">PAN Number</label><input type="text" value={formData.panNumber || ''} onChange={(e) => setFormData({...formData, panNumber: e.target.value})} className="input-field" /></div>
            <div className="md:col-span-2"><label className="text-sm text-gray-500 dark:text-gray-400">Address</label><input type="text" value={formData.address || ''} onChange={(e) => setFormData({...formData, address: e.target.value})} className="input-field" /></div>
            <div><label className="text-sm text-gray-500 dark:text-gray-400">City</label><input type="text" value={formData.city || ''} onChange={(e) => setFormData({...formData, city: e.target.value})} className="input-field" /></div>
            <div><label className="text-sm text-gray-500 dark:text-gray-400">State</label><input type="text" value={formData.state || ''} onChange={(e) => setFormData({...formData, state: e.target.value})} className="input-field" /></div>
            <div><label className="text-sm text-gray-500 dark:text-gray-400">Pincode</label><input type="text" value={formData.pincode || ''} onChange={(e) => setFormData({...formData, pincode: e.target.value})} className="input-field" /></div>
          </div>
        </div>

        {/* Bank Details */}
        <div className="card space-y-4">
          <div className="flex items-center gap-2 mb-2"><Banknote size={20} className="text-primary-600" /><h3 className="text-lg font-semibold">Bank Details</h3></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div><label className="text-sm text-gray-500 dark:text-gray-400">Bank Name</label><input type="text" value={formData.bankName || ''} onChange={(e) => setFormData({...formData, bankName: e.target.value})} className="input-field" /></div>
            <div><label className="text-sm text-gray-500 dark:text-gray-400">Account Number</label><input type="text" value={formData.bankAccount || ''} onChange={(e) => setFormData({...formData, bankAccount: e.target.value})} className="input-field" /></div>
            <div><label className="text-sm text-gray-500 dark:text-gray-400">IFSC Code</label><input type="text" value={formData.bankIfsc || ''} onChange={(e) => setFormData({...formData, bankIfsc: e.target.value})} className="input-field" /></div>
          </div>
        </div>

        {/* Invoice Settings */}
        <div className="card space-y-4">
          <div className="flex items-center gap-2 mb-2"><FileText size={20} className="text-primary-600" /><h3 className="text-lg font-semibold">Document Settings</h3></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div><label className="text-sm text-gray-500 dark:text-gray-400">Invoice Prefix</label><input type="text" value={formData.invoicePrefix || 'INV-'} onChange={(e) => setFormData({...formData, invoicePrefix: e.target.value})} className="input-field" /></div>
            <div><label className="text-sm text-gray-500 dark:text-gray-400">Quotation Prefix</label><input type="text" value={formData.quotationPrefix || 'QTN-'} onChange={(e) => setFormData({...formData, quotationPrefix: e.target.value})} className="input-field" /></div>
            <div><label className="text-sm text-gray-500 dark:text-gray-400">PO Prefix</label><input type="text" value={formData.poPrefix || 'PO-'} onChange={(e) => setFormData({...formData, poPrefix: e.target.value})} className="input-field" /></div>
            <div><label className="text-sm text-gray-500 dark:text-gray-400">DO Prefix</label><input type="text" value={formData.doPrefix || 'DO-'} onChange={(e) => setFormData({...formData, doPrefix: e.target.value})} className="input-field" /></div>
            <div><label className="text-sm text-gray-500 dark:text-gray-400">Currency</label><select value={formData.currency || 'INR'} onChange={(e) => setFormData({...formData, currency: e.target.value})} className="input-field"><option value="INR">INR (₹)</option><option value="USD">USD ($)</option><option value="EUR">EUR (€)</option><option value="GBP">GBP (£)</option></select></div>
            <div><label className="text-sm text-gray-500 dark:text-gray-400">Default Tax Rate (%)</label><input type="number" value={formData.taxRate || 18} onChange={(e) => setFormData({...formData, taxRate: Number(e.target.value)})} className="input-field" min="0" max="100" /></div>
          </div>
        </div>

        {/* Terms */}
        <div className="card space-y-4">
          <h3 className="text-lg font-semibold">Terms & Conditions</h3>
          <textarea value={formData.termsAndConditions || ''} onChange={(e) => setFormData({...formData, termsAndConditions: e.target.value})} rows={4} className="input-field" placeholder="Default terms and conditions for invoices..." />
        </div>

        <div className="flex justify-end">
          <button type="submit" disabled={saving} className="btn-primary flex items-center gap-2 px-8 py-3">
            <Save size={18} /> {saving ? 'Saving...' : 'Save Settings'}
          </button>
        </div>
      </form>
    </div>
  );
}