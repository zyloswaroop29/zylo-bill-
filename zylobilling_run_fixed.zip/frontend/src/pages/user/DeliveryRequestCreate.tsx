import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { drAPI, customerAPI, productAPI } from '@/utils/api';
import { Customer, Product } from '@/types';
import { Plus, Trash2, Save, X } from 'lucide-react';
import toast from 'react-hot-toast';

interface FormItem { product?: string; name: string; quantity: number; unit: string; }

export default function DeliveryRequestCreate() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEdit = !!id;
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState('');
  const [items, setItems] = useState<FormItem[]>([{ name: '', quantity: 1, unit: 'pcs' }]);
  const [requiredDate, setRequiredDate] = useState('');
  const [priority, setPriority] = useState('medium');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => { loadCustomers(); loadProducts(); if (isEdit) loadDR(); }, [id]);

  const loadCustomers = async () => { try { const res = await customerAPI.getAll({ limit: 1000 }); setCustomers(res.data.customers); } catch (e) {} };
  const loadProducts = async () => { try { const res = await productAPI.getAll({ limit: 1000 }); setProducts(res.data.products); } catch (e) {} };
  const loadDR = async () => {
    try { const res = await drAPI.getById(id!); const r = res.data.deliveryRequest; setSelectedCustomer(r.customer._id || r.customer); setItems(r.items.map((i: any) => ({ product: i.product?._id, name: i.name, quantity: i.quantity, unit: i.unit }))); setRequiredDate(new Date(r.requiredDate).toISOString().split('T')[0]); setPriority(r.priority); setNotes(r.notes || ''); } catch (e) { navigate('/delivery-requests'); }
  };

  const addItem = () => setItems([...items, { name: '', quantity: 1, unit: 'pcs' }]);
  const removeItem = (index: number) => { if (items.length === 1) return; setItems(items.filter((_, i) => i !== index)); };
  const updateItem = (index: number, field: keyof FormItem, value: any) => {
    const newItems = [...items]; newItems[index] = { ...newItems[index], [field]: value };
    if (field === 'product' && value) { const p = products.find(pr => pr._id === value); if (p) { newItems[index].name = p.name; newItems[index].unit = p.unit; } }
    setItems(newItems);
  };

  const handleSubmit = async () => {
    if (!selectedCustomer) { toast.error('Select customer'); return; }
    if (!requiredDate) { toast.error('Set required date'); return; }
    if (items.some(i => !i.name || i.quantity <= 0)) { toast.error('Fill all items'); return; }
    const customer = customers.find(c => c._id === selectedCustomer);
    setSaving(true);
    try {
      const payload = { customer: selectedCustomer, customerName: customer?.name || '', items, requiredDate, priority, notes };
      if (isEdit) { await drAPI.update(id!, payload); toast.success('Updated'); } else { await drAPI.create(payload); toast.success('Created'); }
      navigate('/delivery-requests');
    } catch (e: any) { toast.error(e.response?.data?.message || 'Failed'); } finally { setSaving(false); }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{isEdit ? 'Edit' : 'Create'} Delivery Request</h1>
        <div className="flex gap-2"><button onClick={() => navigate('/delivery-requests')} className="btn-secondary flex items-center gap-2"><X size={18} /> Cancel</button><button onClick={handleSubmit} disabled={saving} className="btn-primary flex items-center gap-2"><Save size={18} /> {saving ? 'Saving...' : isEdit ? 'Update' : 'Create'}</button></div>
      </div>
      <div className="card">
        <h3 className="text-lg font-semibold mb-4">Customer</h3>
        <select value={selectedCustomer} onChange={(e) => setSelectedCustomer(e.target.value)} className="input-field"><option value="">Select Customer</option>{customers.map(c => <option key={c._id} value={c._id}>{c.name}</option>)}</select>
      </div>
      <div className="card">
        <div className="flex justify-between mb-4"><h3 className="text-lg font-semibold">Items</h3><button onClick={addItem} className="btn-secondary text-sm flex items-center gap-1"><Plus size={16} /> Add</button></div>
        <div className="space-y-4">
          {items.map((item, idx) => (
            <div key={idx} className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg space-y-3">
              <div className="flex justify-between"><span className="text-sm font-medium text-gray-500">Item #{idx + 1}</span><button onClick={() => removeItem(idx)} className="text-red-500"><Trash2 size={16} /></button></div>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                <div className="md:col-span-2"><select value={item.product || ''} onChange={(e) => updateItem(idx, 'product', e.target.value)} className="input-field text-sm"><option value="">Select Product</option>{products.map(p => <option key={p._id} value={p._id}>{p.name}</option>)}</select></div>
                <div><input type="text" value={item.name} onChange={(e) => updateItem(idx, 'name', e.target.value)} className="input-field text-sm" placeholder="Name" /></div>
                <div><input type="number" value={item.quantity} onChange={(e) => updateItem(idx, 'quantity', Number(e.target.value))} className="input-field text-sm" min="1" /></div>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="card space-y-4">
          <h3 className="text-lg font-semibold">Request Details</h3>
          <div><label className="text-sm text-gray-500">Required Date *</label><input type="date" value={requiredDate} onChange={(e) => setRequiredDate(e.target.value)} className="input-field" /></div>
          <div><label className="text-sm text-gray-500">Priority</label><select value={priority} onChange={(e) => setPriority(e.target.value)} className="input-field"><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option><option value="urgent">Urgent</option></select></div>
        </div>
        <div className="card space-y-4">
          <h3 className="text-lg font-semibold">Notes</h3>
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={4} className="input-field" placeholder="Request notes..." />
        </div>
      </div>
    </div>
  );
}