import { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { invoiceAPI } from '@/utils/api';
import { Invoice, Company } from '@/types';
import { ArrowLeft, Download, Printer, Share2, Edit2, CheckCircle } from 'lucide-react';
import toast from 'react-hot-toast';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

export default function InvoiceView() {
  const { id } = useParams();
  const navigate = useNavigate();
  const invoiceRef = useRef<HTMLDivElement>(null);

  const [invoice, setInvoice] = useState<Invoice | null>(null);
  const [company, setCompany] = useState<Company | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) loadInvoice();
  }, [id]);

  const loadInvoice = async () => {
    try {
      setLoading(true);
      const res = await invoiceAPI.getById(id!);
      setInvoice(res.data.invoice);
      setCompany(res.data.company);
    } catch (error) {
      toast.error('Failed to load invoice');
      navigate('/invoices');
    } finally {
      setLoading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPDF = async () => {
    if (!invoiceRef.current) return;
    try {
      toast.loading('Generating PDF...');
      const canvas = await html2canvas(invoiceRef.current, {
        scale: 2,
        useCORS: true,
        logging: false
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgWidth = 210;
      const pageHeight = 297;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      pdf.save(`${invoice?.invoiceNumber || 'invoice'}.pdf`);
      toast.dismiss();
      toast.success('PDF downloaded');
    } catch (error) {
      toast.dismiss();
      toast.error('Failed to generate PDF');
    }
  };

  const shareWhatsApp = () => {
    if (!invoice) return;
    const message = `Invoice ${invoice.invoiceNumber}\nCustomer: ${invoice.customerName}\nAmount: ₹${invoice.grandTotal.toLocaleString()}\nStatus: ${invoice.status}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
  };

  const markAsPaid = async () => {
    try {
      await invoiceAPI.updateStatus(id!, 'paid');
      toast.success('Invoice marked as paid');
      loadInvoice();
    } catch (error) {
      toast.error('Failed to update status');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (!invoice) return null;

  const customer = invoice.customer as any;

  return (
    <div className="space-y-6">
      {/* Actions Bar */}
      <div className="no-print flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <button onClick={() => navigate('/invoices')} className="btn-secondary flex items-center gap-2">
          <ArrowLeft size={18} />
          Back
        </button>
        <div className="flex flex-wrap gap-2">
          {invoice.status !== 'paid' && (
            <button onClick={markAsPaid} className="btn-primary flex items-center gap-2 bg-green-600 hover:bg-green-700">
              <CheckCircle size={18} />
              Mark Paid
            </button>
          )}
          <button onClick={() => navigate(`/invoices/${id}/edit`)} className="btn-secondary flex items-center gap-2">
            <Edit2 size={18} />
            Edit
          </button>
          <button onClick={shareWhatsApp} className="btn-secondary flex items-center gap-2 text-green-600">
            <Share2 size={18} />
            WhatsApp
          </button>
          <button onClick={handleDownloadPDF} className="btn-secondary flex items-center gap-2">
            <Download size={18} />
            PDF
          </button>
          <button onClick={handlePrint} className="btn-primary flex items-center gap-2">
            <Printer size={18} />
            Print
          </button>
        </div>
      </div>

      {/* Invoice Document */}
      <div ref={invoiceRef} className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 max-w-4xl mx-auto invoice-print">
        {/* Header */}
        <div className="flex justify-between items-start border-b-2 border-gray-200 dark:border-gray-700 pb-6 mb-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{company?.name || 'Your Company'}</h2>
            {company?.address && <p className="text-sm text-gray-600 dark:text-gray-400">{company.address}</p>}
            {company?.city && <p className="text-sm text-gray-600 dark:text-gray-400">{company.city}, {company.state} {company.pincode}</p>}
            {company?.phone && <p className="text-sm text-gray-600 dark:text-gray-400">Phone: {company.phone}</p>}
            {company?.gstNumber && <p className="text-sm text-gray-600 dark:text-gray-400">GST: {company.gstNumber}</p>}
          </div>
          <div className="text-right">
            <h1 className="text-3xl font-bold text-primary-600 dark:text-primary-400">INVOICE</h1>
            <p className="text-lg font-semibold text-gray-900 dark:text-white mt-1">{invoice.invoiceNumber}</p>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Date: {new Date(invoice.createdAt).toLocaleDateString()}
            </p>
            {invoice.dueDate && (
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Due: {new Date(invoice.dueDate).toLocaleDateString()}
              </p>
            )}
          </div>
        </div>

        {/* Bill To */}
        <div className="grid grid-cols-2 gap-8 mb-6">
          <div>
            <h3 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase mb-2">Bill To:</h3>
            <p className="font-semibold text-gray-900 dark:text-white">{invoice.customerName}</p>
            {invoice.customerAddress && <p className="text-sm text-gray-600 dark:text-gray-400">{invoice.customerAddress}</p>}
            {customer?.city && <p className="text-sm text-gray-600 dark:text-gray-400">{customer.city}, {customer.state}</p>}
            {invoice.customerGst && <p className="text-sm text-gray-600 dark:text-gray-400">GST: {invoice.customerGst}</p>}
            {customer?.phone && <p className="text-sm text-gray-600 dark:text-gray-400">Phone: {customer.phone}</p>}
          </div>
          <div className="text-right">
            <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${
              invoice.status === 'paid' ? 'bg-green-100 text-green-800' :
              invoice.status === 'overdue' ? 'bg-red-100 text-red-800' :
              invoice.status === 'sent' ? 'bg-blue-100 text-blue-800' :
              'bg-gray-100 text-gray-800'
            }`}>
              {invoice.status.toUpperCase()}
            </span>
          </div>
        </div>

        {/* Items Table */}
        <table className="w-full mb-6">
          <thead>
            <tr className="bg-gray-100 dark:bg-gray-700">
              <th className="text-left p-3 text-sm font-semibold">#</th>
              <th className="text-left p-3 text-sm font-semibold">Item</th>
              <th className="text-right p-3 text-sm font-semibold">Qty</th>
              <th className="text-right p-3 text-sm font-semibold">Price</th>
              <th className="text-right p-3 text-sm font-semibold">Tax %</th>
              <th className="text-right p-3 text-sm font-semibold">Disc %</th>
              <th className="text-right p-3 text-sm font-semibold">Total</th>
            </tr>
          </thead>
          <tbody>
            {invoice.items.map((item, index) => (
              <tr key={index} className="border-b border-gray-200 dark:border-gray-700">
                <td className="p-3 text-sm">{index + 1}</td>
                <td className="p-3 text-sm">
                  <p className="font-medium">{item.name}</p>
                  {item.description && <p className="text-gray-500 text-xs">{item.description}</p>}
                </td>
                <td className="p-3 text-sm text-right">{item.quantity}</td>
                <td className="p-3 text-sm text-right">₹{item.unitPrice.toFixed(2)}</td>
                <td className="p-3 text-sm text-right">{item.taxRate}%</td>
                <td className="p-3 text-sm text-right">{item.discount}%</td>
                <td className="p-3 text-sm text-right font-medium">₹{item.total.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Totals */}
        <div className="flex justify-end mb-6">
          <div className="w-full max-w-xs space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600 dark:text-gray-400">Sub Total:</span>
              <span>₹{invoice.subTotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600 dark:text-gray-400">Discount:</span>
              <span className="text-green-600">-₹{invoice.totalDiscount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600 dark:text-gray-400">Tax:</span>
              <span>₹{invoice.totalTax.toFixed(2)}</span>
            </div>
            <div className="border-t-2 border-gray-200 dark:border-gray-700 pt-2 flex justify-between">
              <span className="font-bold text-lg">Grand Total:</span>
              <span className="font-bold text-lg text-primary-600 dark:text-primary-400">₹{invoice.grandTotal.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Notes & Terms */}
        {(invoice.notes || invoice.terms) && (
          <div className="border-t border-gray-200 dark:border-gray-700 pt-4 space-y-3">
            {invoice.notes && (
              <div>
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300">Notes:</h4>
                <p className="text-sm text-gray-600 dark:text-gray-400">{invoice.notes}</p>
              </div>
            )}
            {invoice.terms && (
              <div>
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300">Terms & Conditions:</h4>
                <p className="text-sm text-gray-600 dark:text-gray-400">{invoice.terms}</p>
              </div>
            )}
          </div>
        )}

        {/* Bank Details */}
        {company?.bankName && (
          <div className="border-t border-gray-200 dark:border-gray-700 pt-4 mt-4">
            <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">Bank Details:</h4>
            <div className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
              <p>Bank: {company.bankName}</p>
              <p>Account: {company.bankAccount}</p>
              <p>IFSC: {company.bankIfsc}</p>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="text-center mt-8 pt-4 border-t border-gray-200 dark:border-gray-700">
          <p className="text-sm text-gray-500 dark:text-gray-400">Thank you for your business!</p>
        </div>
      </div>
    </div>
  );
}