import { useStore } from '@/context/store';
import { AlertTriangle, Clock, MessageCircle, Calendar, Infinity } from 'lucide-react';

export default function SubscriptionExpired() {
  const { subscription, user } = useStore();

  const whatsappNumber = '917019071669';
  const whatsappMessage = `Hi, I want to subscribe to ZYLO Billing.\n\nName: ${user?.name || ''}\nEmail: ${user?.email || ''}\nCompany: ${user?.companyName || ''}\nCurrent Plan: ${subscription?.plan || 'trial'}`;
  const whatsappLink = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(whatsappMessage)}`;

  const plans = [
    { name: 'Monthly', price: '₹999', period: '/month', icon: Calendar, features: ['Unlimited Invoices', 'Unlimited Customers', 'GST Reports', 'Email Support'] },
    { name: 'Yearly', price: '₹9,999', period: '/year', icon: Calendar, features: ['All Monthly Features', '2 Months Free', 'Priority Support', 'Custom Branding'], popular: true },
    { name: 'Lifetime', price: '₹24,999', period: 'one-time', icon: Infinity, features: ['All Features Forever', 'Free Updates', 'Priority Support', 'Dedicated Account Manager'] },
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full">
        {/* Alert Banner */}
        <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-2xl p-8 mb-8 text-center">
          <div className="w-16 h-16 bg-red-100 dark:bg-red-800/30 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertTriangle className="w-8 h-8 text-red-600 dark:text-red-400" />
          </div>
          <h1 className="text-2xl font-bold text-red-800 dark:text-red-400 mb-2">
            Subscription Expired
          </h1>
          <p className="text-red-600 dark:text-red-400 mb-4">
            Your {subscription?.isDemo ? '3-day demo trial' : 'subscription'} has expired. 
            Please subscribe to continue using ZYLO Billing Software.
          </p>

          {subscription?.demoExpiryDate && (
            <div className="flex items-center justify-center gap-2 text-sm text-red-600 dark:text-red-400 mb-4">
              <Clock className="w-4 h-4" />
              <span>Expired on: {new Date(subscription.demoExpiryDate).toLocaleDateString()}</span>
            </div>
          )}

          <a
            href={whatsappLink}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 bg-green-600 hover:bg-green-700 text-white rounded-xl font-medium transition-colors"
          >
            <MessageCircle className="w-5 h-5" />
            Contact on WhatsApp for Subscription
          </a>
        </div>

        {/* Pricing Plans */}
        <h2 className="text-xl font-bold text-gray-900 dark:text-white text-center mb-6">Choose Your Plan</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {plans.map((plan) => {
            const Icon = plan.icon;
            return (
              <div key={plan.name} className={`card relative ${plan.popular ? 'ring-2 ring-primary-500' : ''}`}>
                {plan.popular && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-primary-600 text-white text-xs font-medium rounded-full">
                    Most Popular
                  </span>
                )}
                <div className="text-center mb-6">
                  <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900/30 rounded-xl flex items-center justify-center mx-auto mb-3">
                    <Icon className="w-6 h-6 text-primary-600 dark:text-primary-400" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{plan.name}</h3>
                  <div className="mt-2">
                    <span className="text-3xl font-bold text-gray-900 dark:text-white">{plan.price}</span>
                    <span className="text-gray-500 dark:text-gray-400">{plan.period}</span>
                  </div>
                </div>
                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                      <svg className="w-4 h-4 text-green-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                      {feature}
                    </li>
                  ))}
                </ul>
                <a
                  href={whatsappLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`w-full py-2.5 rounded-lg font-medium text-center block transition-colors ${
                    plan.popular 
                      ? 'btn-primary' 
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                  }`}
                >
                  Subscribe Now
                </a>
              </div>
            );
          })}
        </div>

        {/* Contact Info */}
        <div className="mt-8 text-center">
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Need help? Contact us at <span className="font-medium">+91 70190 71669</span>
          </p>
        </div>
      </div>
    </div>
  );
}