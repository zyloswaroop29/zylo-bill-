import { useEffect, useState } from 'react';
import { dashboardAPI } from '@/utils/api';
import { Invoice, Quotation, Product } from '@/types';
import { 
  FileText, Users, Package, TrendingUp, Clock, AlertTriangle,
  ArrowUpRight, ArrowDownRight, DollarSign, ShoppingBag
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface DashboardData {
  stats: {
    totalInvoices: number;
    totalQuotations: number;
    totalCustomers: number;
    totalProducts: number;
    monthlyRevenue: number;
    yearlyRevenue: number;
    pendingInvoices: number;
  };
  recentInvoices: Invoice[];
  recentQuotations: Quotation[];
  lowStockProducts: Product[];
  monthlyChart: Array<{ _id: { month: number }; revenue: number; count: number }>;
}

export default function UserDashboard() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    loadDashboard();
  }, []);

  const loadDashboard = async () => {
    try {
      const res = await dashboardAPI.getUser();
      setData(res.data);
    } catch (error) {
      console.error('Dashboard error:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  const stats = data?.stats;
  const chartData = data?.monthlyChart?.map(item => ({
    name: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][item._id.month - 1],
    revenue: item.revenue,
    count: item.count
  })) || [];

  const statCards = [
    { label: 'Total Invoices', value: stats?.totalInvoices || 0, icon: FileText, color: 'bg-blue-500', path: '/invoices' },
    { label: 'Quotations', value: stats?.totalQuotations || 0, icon: ShoppingBag, color: 'bg-purple-500', path: '/quotations' },
    { label: 'Customers', value: stats?.totalCustomers || 0, icon: Users, color: 'bg-green-500', path: '/customers' },
    { label: 'Products', value: stats?.totalProducts || 0, icon: Package, color: 'bg-orange-500', path: '/products' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Dashboard</h1>
          <p className="text-gray-500 dark:text-gray-400">Welcome back! Here's your business overview.</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat) => {
          const Icon = stat.icon;
          return (
            <button
              key={stat.label}
              onClick={() => navigate(stat.path)}
              className="card hover:shadow-md transition-shadow text-left"
            >
              <div className="flex items-center justify-between">
                <div className={`p-3 ${stat.color} rounded-lg`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <ArrowUpRight className="w-4 h-4 text-gray-400" />
              </div>
              <div className="mt-4">
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{stat.value}</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">{stat.label}</p>
              </div>
            </button>
          );
        })}
      </div>

      {/* Revenue Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="card">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-green-100 dark:bg-green-900/30 rounded-lg">
              <DollarSign className="w-5 h-5 text-green-600 dark:text-green-400" />
            </div>
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">Monthly Revenue</p>
              <p className="text-xl font-bold text-gray-900 dark:text-white">₹{(stats?.monthlyRevenue || 0).toLocaleString()}</p>
            </div>
          </div>
        </div>
        <div className="card">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-primary-100 dark:bg-primary-900/30 rounded-lg">
              <TrendingUp className="w-5 h-5 text-primary-600 dark:text-primary-400" />
            </div>
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">Yearly Revenue</p>
              <p className="text-xl font-bold text-gray-900 dark:text-white">₹{(stats?.yearlyRevenue || 0).toLocaleString()}</p>
            </div>
          </div>
        </div>
        <div className="card">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-yellow-100 dark:bg-yellow-900/30 rounded-lg">
              <Clock className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />
            </div>
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">Pending</p>
              <p className="text-xl font-bold text-gray-900 dark:text-white">{stats?.pendingInvoices || 0}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Chart + Recent */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue Chart */}
        <div className="lg:col-span-2 card">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Revenue Overview</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200 dark:stroke-gray-700" />
                <XAxis dataKey="name" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1f2937', border: 'none', borderRadius: '8px', color: '#fff' }}
                  formatter={(value: number) => [`₹${value.toLocaleString()}`, 'Revenue']}
                />
                <Area type="monotone" dataKey="revenue" stroke="#3b82f6" fillOpacity={1} fill="url(#colorRevenue)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Recent Invoices */}
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Recent Invoices</h3>
          <div className="space-y-3">
            {data?.recentInvoices?.length === 0 && (
              <p className="text-sm text-gray-500 dark:text-gray-400 text-center py-4">No invoices yet</p>
            )}
            {data?.recentInvoices?.map((invoice) => (
              <button
                key={invoice._id}
                onClick={() => navigate(`/invoices/${invoice._id}`)}
                className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors text-left"
              >
                <div>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">{invoice.invoiceNumber}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {(invoice.customer as any)?.name || invoice.customerName}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold text-gray-900 dark:text-white">₹{invoice.grandTotal.toLocaleString()}</p>
                  <span className={`badge ${invoice.status === 'paid' ? 'badge-success' : invoice.status === 'overdue' ? 'badge-danger' : 'badge-warning'}`}>
                    {invoice.status}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Low Stock Alert */}
      {data?.lowStockProducts && data.lowStockProducts.length > 0 && (
        <div className="card border-l-4 border-yellow-500">
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle className="w-5 h-5 text-yellow-500" />
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Low Stock Alert</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {data.lowStockProducts.map((product) => (
              <div key={product._id} className="p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                <p className="text-sm font-medium text-gray-900 dark:text-white">{product.name}</p>
                <p className="text-xs text-yellow-700 dark:text-yellow-400">Stock: {product.stock} units</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}