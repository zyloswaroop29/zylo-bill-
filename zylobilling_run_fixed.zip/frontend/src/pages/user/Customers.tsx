import { useEffect, useState } from 'react';
import { customerAPI } from '@/utils/api';
import { Customer } from '@/types';
import { Plus, Search, Edit2, Trash2, Phone, Mail, MapPin } from 'lucide-react';
import toast from 'react-hot-toast';

export default function Customers() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', address: '', city: '', state: '', gstNumber: '', companyName: '' });

  useEffect(() => { loadCustomers(); }, []);

  const loadCustomers = async () => {
    try { const res = await customerAPI.getAll({ search: search || undefined, limit: 1000 }); setCustomers(res.data.customers); }
    catch (error) { toast.error('Failed to load'); } finally { setLoading(false); }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) { toast.error('Name required'); return; }
    try {
      if (editingId) { await customerAPI.update(editingId, formData); toast.success('Updated'); }
      else { await customerAPI.create(formData); toast.success('Created'); }
      setShowForm(false); setEditingId(null); setFormData({ name: '', email: '', phone: '', address: '', city: '', state: '', gstNumber: '', companyName: '' });
      loadCustomers();
    } catch (e: any) { toast.error(e.response?.data?.message || 'Failed'); }
  };

  const handleEdit = (customer: Customer) => {
    setFormData({ name: customer.name, email: customer.email || '', phone: customer.phone || '', address: customer.address || '', city: customer.city || '', state: customer.state || '', gstNumber: customer.gstNumber || '', companyName: customer.companyName || '' });
    setEditingId(customer._id); setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this customer?')) return;
    try { await customerAPI.delete(id); toast.success('Deleted'); loadCustomers(); } catch (e) { toast.error('Failed'); }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-gray-900 dark:text-white">Customers</h1><p className="text-gray-500 dark:text-gray-400">Manage your customers</p></div>
        <button onClick={() => { setShowForm(true); setEditingId(null); setFormData({ name: '', email: '', phone: '', address: '', city: '', state: '', gstNumber: '', companyName: '' }); }} className="btn-primary flex items-center gap-2"><Plus size={18} /> Add Customer</button>
      </div>

      <div className="card">
        <div className="flex gap-2 mb-4"><input type="text" value={search} onChange={(e) => setSearch(e.target.value)} onKeyPress={(e) => e.key === 'Enter' && loadCustomers()} placeholder="Search customers..." className="input-field" /><button onClick={loadCustomers} className="btn-secondary"><Search size={18} /></button></div>
        {showForm && (
          <form onSubmit={handleSubmit} className="mb-6 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg space-y-4">
            <h3 className="font-semibold">{editingId ? 'Edit' : 'Add'} Customer</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <input type="text" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} className="input-field" placeholder="Name *" required />
              <input type="email" value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} className="input-field" placeholder="Email" />
              <input type="tel" value={formData.phone} onChange={(e) => setFormData({...formData, phone: e.target.value})} className="input-field" placeholder="Phone" />
              <input type="text" value={formData.companyName} onChange={(e) => setFormData({...formData, companyName: e.target.value})} className="input-field" placeholder="Company Name" />
              <input type="text" value={formData.gstNumber} onChange={(e) => setFormData({...formData, gstNumber: e.target.value})} className="input-field" placeholder="GST Number" />
              <input type="text" value={formData.address} onChange={(e) => setFormData({...formData, address: e.target.value})} className="input-field" placeholder="Address" />
              <input type="text" value={formData.city} onChange={(e) => setFormData({...formData, city: e.target.value})} className="input-field" placeholder="City" />
              <input type="text" value={formData.state} onChange={(e) => setFormData({...formData, state: e.target.value})} className="input-field" placeholder="State" />
            </div>
            <div className="flex gap-2">
              <button type="submit" className="btn-primary">{editingId ? 'Update' : 'Create'}</button>
              <button type="button" onClick={() => setShowForm(false)} className="btn-secondary">Cancel</button>
            </div>
          </form>
        )}
        <div className="overflow-x-auto">
          <table className="w-full"><thead><tr className="border-b border-gray-200 dark:border-gray-700"><th className="table-header">Name</th><th className="table-header">Contact</th><th className="table-header">GST</th><th className="table-header">Address</th><th className="table-header text-right">Actions</th></tr></thead>
          <tbody>
            {loading ? <tr><td colSpan={5} className="text-center py-8"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600 mx-auto"></div></td></tr> :
            customers.length === 0 ? <tr><td colSpan={5} className="text-center py-8 text-gray-500">No customers</td></tr> :
            customers.map((c) => (
              <tr key={c._id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                <td className="table-cell"><div><p className="font-medium">{c.name}</p>{c.companyName && <p className="text-xs text-gray-500">{c.companyName}</p>}</div></td>
                <td className="table-cell"><div className="space-y-1">{c.phone && <p className="text-sm flex items-center gap-1"><Phone size={12} />{c.phone}</p>}{c.email && <p className="text-sm flex items-center gap-1"><Mail size={12} />{c.email}</p>}</div></td>
                <td className="table-cell text-sm">{c.gstNumber || '-'}</td>
                <td className="table-cell text-sm">{c.address ? <span className="flex items-center gap-1"><MapPin size={12} />{c.address}, {c.city}</span> : '-'}</td>
                <td className="table-cell text-right"><div className="flex items-center justify-end gap-1"><button onClick={() => handleEdit(c)} className="p-1.5 hover:bg-gray-100 rounded-lg"><Edit2 size={16} /></button><button onClick={() => handleDelete(c._id)} className="p-1.5 hover:bg-red-50 rounded-lg text-red-600"><Trash2 size={16} /></button></div></td>
              </tr>
            ))}
          </tbody></table>
        </div>
      </div>
    </div>
  );
}