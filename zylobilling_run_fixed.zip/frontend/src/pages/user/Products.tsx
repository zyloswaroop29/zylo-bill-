import { useEffect, useState } from 'react';
import { productAPI } from '@/utils/api';
import { Product } from '@/types';
import { Plus, Search, Edit2, Trash2, Package, AlertTriangle } from 'lucide-react';
import toast from 'react-hot-toast';

export default function Products() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({ name: '', description: '', sku: '', price: 0, cost: 0, taxRate: 18, unit: 'pcs', category: '', stock: 0 });

  useEffect(() => { loadProducts(); }, []);

  const loadProducts = async () => {
    try { const res = await productAPI.getAll({ search: search || undefined, limit: 1000 }); setProducts(res.data.products); }
    catch (error) { toast.error('Failed to load'); } finally { setLoading(false); }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || formData.price <= 0) { toast.error('Name and valid price required'); return; }
    try {
      if (editingId) { await productAPI.update(editingId, formData); toast.success('Updated'); }
      else { await productAPI.create(formData); toast.success('Created'); }
      setShowForm(false); setEditingId(null); setFormData({ name: '', description: '', sku: '', price: 0, cost: 0, taxRate: 18, unit: 'pcs', category: '', stock: 0 });
      loadProducts();
    } catch (e: any) { toast.error(e.response?.data?.message || 'Failed'); }
  };

  const handleEdit = (product: Product) => {
    setFormData({ name: product.name, description: product.description || '', sku: product.sku || '', price: product.price, cost: product.cost || 0, taxRate: product.taxRate, unit: product.unit, category: product.category || '', stock: product.stock || 0 });
    setEditingId(product._id); setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this product?')) return;
    try { await productAPI.delete(id); toast.success('Deleted'); loadProducts(); } catch (e) { toast.error('Failed'); }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-gray-900 dark:text-white">Products</h1><p className="text-gray-500 dark:text-gray-400">Manage your products and services</p></div>
        <button onClick={() => { setShowForm(true); setEditingId(null); setFormData({ name: '', description: '', sku: '', price: 0, cost: 0, taxRate: 18, unit: 'pcs', category: '', stock: 0 }); }} className="btn-primary flex items-center gap-2"><Plus size={18} /> Add Product</button>
      </div>

      <div className="card">
        <div className="flex gap-2 mb-4"><input type="text" value={search} onChange={(e) => setSearch(e.target.value)} onKeyPress={(e) => e.key === 'Enter' && loadProducts()} placeholder="Search products..." className="input-field" /><button onClick={loadProducts} className="btn-secondary"><Search size={18} /></button></div>
        {showForm && (
          <form onSubmit={handleSubmit} className="mb-6 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg space-y-4">
            <h3 className="font-semibold">{editingId ? 'Edit' : 'Add'} Product</h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <input type="text" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} className="input-field" placeholder="Name *" required />
              <input type="text" value={formData.sku} onChange={(e) => setFormData({...formData, sku: e.target.value})} className="input-field" placeholder="SKU" />
              <input type="number" value={formData.price} onChange={(e) => setFormData({...formData, price: Number(e.target.value)})} className="input-field" placeholder="Price *" min="0" step="0.01" required />
              <input type="number" value={formData.cost} onChange={(e) => setFormData({...formData, cost: Number(e.target.value)})} className="input-field" placeholder="Cost" min="0" step="0.01" />
              <input type="number" value={formData.taxRate} onChange={(e) => setFormData({...formData, taxRate: Number(e.target.value)})} className="input-field" placeholder="Tax %" min="0" max="100" />
              <input type="text" value={formData.unit} onChange={(e) => setFormData({...formData, unit: e.target.value})} className="input-field" placeholder="Unit (pcs/kg/ltr)" />
              <input type="text" value={formData.category} onChange={(e) => setFormData({...formData, category: e.target.value})} className="input-field" placeholder="Category" />
              <input type="number" value={formData.stock} onChange={(e) => setFormData({...formData, stock: Number(e.target.value)})} className="input-field" placeholder="Stock" min="0" />
            </div>
            <textarea value={formData.description} onChange={(e) => setFormData({...formData, description: e.target.value})} className="input-field" placeholder="Description" rows={2} />
            <div className="flex gap-2"><button type="submit" className="btn-primary">{editingId ? 'Update' : 'Create'}</button><button type="button" onClick={() => setShowForm(false)} className="btn-secondary">Cancel</button></div>
          </form>
        )}
        <div className="overflow-x-auto">
          <table className="w-full"><thead><tr className="border-b border-gray-200 dark:border-gray-700"><th className="table-header">Product</th><th className="table-header">SKU</th><th className="table-header">Price</th><th className="table-header">Tax</th><th className="table-header">Stock</th><th className="table-header text-right">Actions</th></tr></thead>
          <tbody>
            {loading ? <tr><td colSpan={6} className="text-center py-8"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600 mx-auto"></div></td></tr> :
            products.length === 0 ? <tr><td colSpan={6} className="text-center py-8 text-gray-500">No products</td></tr> :
            products.map((p) => (
              <tr key={p._id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                <td className="table-cell"><div className="flex items-center gap-3"><div className="w-8 h-8 bg-primary-100 dark:bg-primary-900/30 rounded-lg flex items-center justify-center"><Package size={16} className="text-primary-600" /></div><div><p className="font-medium">{p.name}</p>{p.category && <p className="text-xs text-gray-500">{p.category}</p>}</div></div></td>
                <td className="table-cell text-sm">{p.sku || '-'}</td>
                <td className="table-cell font-semibold">₹{p.price.toLocaleString()}</td>
                <td className="table-cell text-sm">{p.taxRate}%</td>
                <td className="table-cell"><span className={`text-sm ${(p.stock || 0) < 10 ? 'text-red-600 font-medium' : 'text-gray-600'}`}>{p.stock || 0} {p.unit}</span>{(p.stock || 0) < 10 && <AlertTriangle size={12} className="inline ml-1 text-red-500" />}</td>
                <td className="table-cell text-right"><div className="flex items-center justify-end gap-1"><button onClick={() => handleEdit(p)} className="p-1.5 hover:bg-gray-100 rounded-lg"><Edit2 size={16} /></button><button onClick={() => handleDelete(p._id)} className="p-1.5 hover:bg-red-50 rounded-lg text-red-600"><Trash2 size={16} /></button></div></td>
              </tr>
            ))}
          </tbody></table>
        </div>
      </div>
    </div>
  );
}