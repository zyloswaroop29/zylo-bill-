import { create } from 'zustand';
import { User, Subscription, Company } from '@/types';

interface AuthState {
  user: User | null;
  token: string | null;
  subscription: Subscription | null;
  company: Company | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  darkMode: boolean;
  sidebarOpen: boolean;
  notifications: any[];

  setUser: (user: User | null) => void;
  setToken: (token: string | null) => void;
  setSubscription: (sub: Subscription | null) => void;
  setCompany: (company: Company | null) => void;
  setAuthenticated: (value: boolean) => void;
  setLoading: (value: boolean) => void;
  toggleDarkMode: () => void;
  toggleSidebar: () => void;
  setSidebarOpen: (value: boolean) => void;
  addNotification: (notification: any) => void;
  clearNotifications: () => void;
  logout: () => void;
}

export const useStore = create<AuthState>((set) => ({
  user: JSON.parse(localStorage.getItem('zylo_user') || 'null'),
  token: localStorage.getItem('zylo_token'),
  subscription: JSON.parse(localStorage.getItem('zylo_subscription') || 'null'),
  company: null,
  isAuthenticated: !!localStorage.getItem('zylo_token'),
  isLoading: false,
  darkMode: localStorage.getItem('zylo_dark_mode') === 'true',
  sidebarOpen: window.innerWidth >= 1024,
  notifications: [],

  setUser: (user) => {
    set({ user });
    if (user) localStorage.setItem('zylo_user', JSON.stringify(user));
    else localStorage.removeItem('zylo_user');
  },

  setToken: (token) => {
    set({ token });
    if (token) localStorage.setItem('zylo_token', token);
    else localStorage.removeItem('zylo_token');
  },

  setSubscription: (subscription) => {
    set({ subscription });
    if (subscription) localStorage.setItem('zylo_subscription', JSON.stringify(subscription));
    else localStorage.removeItem('zylo_subscription');
  },

  setCompany: (company) => set({ company }),

  setAuthenticated: (isAuthenticated) => set({ isAuthenticated }),

  setLoading: (isLoading) => set({ isLoading }),

  toggleDarkMode: () => {
    set((state) => {
      const newMode = !state.darkMode;
      localStorage.setItem('zylo_dark_mode', String(newMode));
      if (newMode) document.documentElement.classList.add('dark');
      else document.documentElement.classList.remove('dark');
      return { darkMode: newMode };
    });
  },

  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),

  setSidebarOpen: (sidebarOpen) => set({ sidebarOpen }),

  addNotification: (notification) => 
    set((state) => ({ notifications: [notification, ...state.notifications].slice(0, 50) })),

  clearNotifications: () => set({ notifications: [] }),

  logout: () => {
    localStorage.removeItem('zylo_token');
    localStorage.removeItem('zylo_user');
    localStorage.removeItem('zylo_subscription');
    set({ user: null, token: null, subscription: null, company: null, isAuthenticated: false, notifications: [] });
  }
}));

// Initialize dark mode
if (localStorage.getItem('zylo_dark_mode') === 'true' || 
    (!localStorage.getItem('zylo_dark_mode') && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
  document.documentElement.classList.add('dark');
}
