import axios from 'axios';
import { useStore } from '@/context/store';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

export const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Request interceptor
api.interceptors.request.use(
  (config) => {
    const token = useStore.getState().token;
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      useStore.getState().logout();
      window.location.href = '/login';
    }
    if (error.response?.data?.subscriptionExpired) {
      // Handle subscription expiry
      window.location.href = '/subscription-expired';
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  login: (email: string, password: string) => api.post('/auth/login', { email, password }),
  register: (data: any) => api.post('/auth/register', data),
  me: () => api.get('/auth/me'),
};

// User API
export const userAPI = {
  getAll: (params?: any) => api.get('/users', { params }),
  getExpired: () => api.get('/users/expired'),
  create: (data: any) => api.post('/users', data),
  update: (id: string, data: any) => api.put(`/users/${id}`, data),
  delete: (id: string) => api.delete(`/users/${id}`),
  updateSubscription: (id: string, data: any) => api.put(`/users/${id}/subscription`, data),
  updatePermissions: (id: string, permissions: string[]) => api.put(`/users/${id}/permissions`, { permissions }),
};

// Invoice API
export const invoiceAPI = {
  getAll: (params?: any) => api.get('/invoices', { params }),
  getById: (id: string) => api.get(`/invoices/${id}`),
  create: (data: any) => api.post('/invoices', data),
  update: (id: string, data: any) => api.put(`/invoices/${id}`, data),
  delete: (id: string) => api.delete(`/invoices/${id}`),
  updateStatus: (id: string, status: string) => api.put(`/invoices/${id}/status`, { status }),
};

// Quotation API
export const quotationAPI = {
  getAll: (params?: any) => api.get('/quotations', { params }),
  getById: (id: string) => api.get(`/quotations/${id}`),
  create: (data: any) => api.post('/quotations', data),
  update: (id: string, data: any) => api.put(`/quotations/${id}`, data),
  delete: (id: string) => api.delete(`/quotations/${id}`),
  convert: (id: string) => api.post(`/quotations/${id}/convert`),
};

// Purchase Order API
export const poAPI = {
  getAll: (params?: any) => api.get('/purchase-orders', { params }),
  getById: (id: string) => api.get(`/purchase-orders/${id}`),
  create: (data: any) => api.post('/purchase-orders', data),
  update: (id: string, data: any) => api.put(`/purchase-orders/${id}`, data),
  delete: (id: string) => api.delete(`/purchase-orders/${id}`),
};

// Delivery Order API
export const doAPI = {
  getAll: (params?: any) => api.get('/delivery-orders', { params }),
  getById: (id: string) => api.get(`/delivery-orders/${id}`),
  create: (data: any) => api.post('/delivery-orders', data),
  update: (id: string, data: any) => api.put(`/delivery-orders/${id}`, data),
  delete: (id: string) => api.delete(`/delivery-orders/${id}`),
};

// Delivery Request API
export const drAPI = {
  getAll: (params?: any) => api.get('/delivery-requests', { params }),
  getById: (id: string) => api.get(`/delivery-requests/${id}`),
  create: (data: any) => api.post('/delivery-requests', data),
  update: (id: string, data: any) => api.put(`/delivery-requests/${id}`, data),
  delete: (id: string) => api.delete(`/delivery-requests/${id}`),
  approve: (id: string, status: string, reason?: string) => api.put(`/delivery-requests/${id}/approve`, { status, rejectionReason: reason }),
};

// Customer API
export const customerAPI = {
  getAll: (params?: any) => api.get('/customers', { params }),
  getById: (id: string) => api.get(`/customers/${id}`),
  create: (data: any) => api.post('/customers', data),
  update: (id: string, data: any) => api.put(`/customers/${id}`, data),
  delete: (id: string) => api.delete(`/customers/${id}`),
};

// Product API
export const productAPI = {
  getAll: (params?: any) => api.get('/products', { params }),
  getCategories: () => api.get('/products/categories'),
  getById: (id: string) => api.get(`/products/${id}`),
  create: (data: any) => api.post('/products', data),
  update: (id: string, data: any) => api.put(`/products/${id}`, data),
  delete: (id: string) => api.delete(`/products/${id}`),
};

// Subscription API
export const subscriptionAPI = {
  getMy: () => api.get('/subscriptions/my'),
  getAll: (params?: any) => api.get('/subscriptions', { params }),
  getExpired: () => api.get('/subscriptions/expired'),
  update: (id: string, data: any) => api.put(`/subscriptions/${id}`, data),
  activate: (userId: string, data: any) => api.post(`/subscriptions/activate/${userId}`, data),
};

// Company API
export const companyAPI = {
  get: () => api.get('/company'),
  update: (data: any) => api.put('/company', data),
};

// Dashboard API
export const dashboardAPI = {
  getUser: () => api.get('/dashboard/user'),
  getAdmin: () => api.get('/dashboard/admin'),
};

// Reports API
export const reportAPI = {
  getInvoices: (params?: any) => api.get('/reports/invoices', { params }),
  getRevenue: (year?: number) => api.get('/reports/revenue', { params: { year } }),
  getAdminAll: (params?: any) => api.get('/reports/admin/all', { params }),
};

// Activity API
export const activityAPI = {
  getMy: (params?: any) => api.get('/activity/my', { params }),
  getAll: (params?: any) => api.get('/activity/all', { params }),
};
