import { Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { useEffect } from 'react';
import { useStore } from '@/context/store';
import { authAPI } from '@/utils/api';

// Layouts
import MainLayout from '@/components/layout/MainLayout';
import AuthLayout from '@/components/layout/AuthLayout';

// Auth Pages
import Login from '@/pages/auth/Login';
import Register from '@/pages/auth/Register';

// User Pages
import UserDashboard from '@/pages/user/Dashboard';
import Invoices from '@/pages/user/Invoices';
import InvoiceCreate from '@/pages/user/InvoiceCreate';
import InvoiceView from '@/pages/user/InvoiceView';
import Quotations from '@/pages/user/Quotations';
import QuotationCreate from '@/pages/user/QuotationCreate';
import PurchaseOrders from '@/pages/user/PurchaseOrders';
import PurchaseOrderCreate from '@/pages/user/PurchaseOrderCreate';
import DeliveryOrders from '@/pages/user/DeliveryOrders';
import DeliveryOrderCreate from '@/pages/user/DeliveryOrderCreate';
import DeliveryRequests from '@/pages/user/DeliveryRequests';
import DeliveryRequestCreate from '@/pages/user/DeliveryRequestCreate';
import Customers from '@/pages/user/Customers';
import Products from '@/pages/user/Products';
import CompanySettings from '@/pages/user/CompanySettings';
import SubscriptionExpired from '@/pages/user/SubscriptionExpired';

// Admin Pages
import AdminDashboard from '@/pages/admin/Dashboard';
import Users from '@/pages/admin/Users';
import AdminSubscriptions from '@/pages/admin/Subscriptions';
import AdminInvoices from '@/pages/admin/Invoices';
import AdminReports from '@/pages/admin/Reports';
import AdminActivity from '@/pages/admin/Activity';

// Components
import ProtectedRoute from '@/components/auth/ProtectedRoute';
import AdminRoute from '@/components/auth/AdminRoute';
import SubscriptionCheck from '@/components/auth/SubscriptionCheck';

function App() {
  const { token, setUser, setSubscription, setAuthenticated, setCompany, company } = useStore();

  useEffect(() => {
    if (token) {
      authAPI.me()
        .then((res: any) => {
          setUser(res.data.user);
          setSubscription(res.data.subscription);
          setAuthenticated(true);
        })
        .catch(() => {
          // Token invalid, will be handled by interceptor
        });
    }
  }, [token]);

  useEffect(() => {
    // Load company settings
    if (token && !company) {
      import('@/utils/api').then(({ companyAPI }) => {
        companyAPI.get().then((res: any) => {
          setCompany(res.data.company);
        }).catch(() => {});
      });
    }
  }, [token, company]);

  return (
    <>
      <Toaster 
        position="top-right" 
        toastOptions={{
          duration: 4000,
          style: {
            background: '#363636',
            color: '#fff',
          },
          success: {
            duration: 3000,
            iconTheme: {
              primary: '#10B981',
              secondary: '#fff',
            },
          },
          error: {
            duration: 5000,
            iconTheme: {
              primary: '#EF4444',
              secondary: '#fff',
            },
          },
        }}
      />
      <Routes>
        {/* Public Routes */}
        <Route element={<AuthLayout />}>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
        </Route>

        {/* Subscription Expired */}
        <Route path="/subscription-expired" element={<SubscriptionExpired />} />

        {/* Admin Routes */}
        <Route element={<AdminRoute />}>
          <Route element={<MainLayout />}>
            <Route path="/admin" element={<Navigate to="/admin/dashboard" replace />} />
            <Route path="/admin/dashboard" element={<AdminDashboard />} />
            <Route path="/admin/users" element={<Users />} />
            <Route path="/admin/subscriptions" element={<AdminSubscriptions />} />
            <Route path="/admin/invoices" element={<AdminInvoices />} />
            <Route path="/admin/reports" element={<AdminReports />} />
            <Route path="/admin/activity" element={<AdminActivity />} />
          </Route>
        </Route>

        {/* User Routes */}
        <Route element={<ProtectedRoute />}>
          <Route element={<SubscriptionCheck />}>
            <Route element={<MainLayout />}>
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
              <Route path="/dashboard" element={<UserDashboard />} />

              <Route path="/invoices" element={<Invoices />} />
              <Route path="/invoices/create" element={<InvoiceCreate />} />
              <Route path="/invoices/:id" element={<InvoiceView />} />
              <Route path="/invoices/:id/edit" element={<InvoiceCreate />} />

              <Route path="/quotations" element={<Quotations />} />
              <Route path="/quotations/create" element={<QuotationCreate />} />
              <Route path="/quotations/:id" element={<QuotationCreate />} />

              <Route path="/purchase-orders" element={<PurchaseOrders />} />
              <Route path="/purchase-orders/create" element={<PurchaseOrderCreate />} />
              <Route path="/purchase-orders/:id" element={<PurchaseOrderCreate />} />

              <Route path="/delivery-orders" element={<DeliveryOrders />} />
              <Route path="/delivery-orders/create" element={<DeliveryOrderCreate />} />
              <Route path="/delivery-orders/:id" element={<DeliveryOrderCreate />} />

              <Route path="/delivery-requests" element={<DeliveryRequests />} />
              <Route path="/delivery-requests/create" element={<DeliveryRequestCreate />} />
              <Route path="/delivery-requests/:id" element={<DeliveryRequestCreate />} />

              <Route path="/customers" element={<Customers />} />
              <Route path="/products" element={<Products />} />
              <Route path="/company-settings" element={<CompanySettings />} />
            </Route>
          </Route>
        </Route>

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </>
  );
}

export default App;
