export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'user';
  phone?: string;
  companyName?: string;
  isActive: boolean;
  permissions: string[];
}

export interface Subscription {
  _id: string;
  user: string;
  plan: 'trial' | 'monthly' | 'yearly' | 'lifetime';
  status: 'active' | 'expired' | 'cancelled' | 'pending';
  startDate: string;
  endDate?: string;
  isDemo: boolean;
  demoExpiryDate?: string;
  amount?: number;
  paymentStatus: 'paid' | 'unpaid' | 'pending';
}

export interface Customer {
  _id: string;
  user: string;
  name: string;
  email?: string;
  phone?: string;
  address?: string;
  city?: string;
  state?: string;
  gstNumber?: string;
  companyName?: string;
}

export interface Product {
  _id: string;
  user: string;
  name: string;
  description?: string;
  sku?: string;
  price: number;
  cost?: number;
  taxRate: number;
  unit: string;
  category?: string;
  stock?: number;
  isActive: boolean;
}

export interface InvoiceItem {
  _id?: string;
  product?: string;
  name: string;
  description?: string;
  quantity: number;
  unitPrice: number;
  taxRate: number;
  discount: number;
  total: number;
}

export interface Invoice {
  _id: string;
  user: string;
  invoiceNumber: string;
  customer: Customer | string;
  customerName: string;
  customerAddress?: string;
  customerGst?: string;
  items: InvoiceItem[];
  subTotal: number;
  totalTax: number;
  totalDiscount: number;
  grandTotal: number;
  status: 'draft' | 'sent' | 'paid' | 'overdue' | 'cancelled';
  dueDate?: string;
  notes?: string;
  terms?: string;
  createdAt: string;
}

export interface Quotation {
  _id: string;
  user: string;
  quotationNumber: string;
  customer: Customer | string;
  customerName: string;
  items: InvoiceItem[];
  subTotal: number;
  totalTax: number;
  totalDiscount: number;
  grandTotal: number;
  status: 'draft' | 'sent' | 'accepted' | 'rejected' | 'converted';
  validUntil: string;
  notes?: string;
  convertedToInvoice?: string;
}

export interface PurchaseOrder {
  _id: string;
  user: string;
  poNumber: string;
  supplier: string;
  supplierAddress?: string;
  supplierPhone?: string;
  supplierGst?: string;
  items: InvoiceItem[];
  subTotal: number;
  totalTax: number;
  grandTotal: number;
  status: 'draft' | 'sent' | 'received' | 'cancelled';
  orderDate: string;
  deliveryDate?: string;
  notes?: string;
}

export interface DeliveryOrder {
  _id: string;
  user: string;
  doNumber: string;
  customer: Customer | string;
  customerName: string;
  customerAddress?: string;
  items: { product?: string; name: string; quantity: number; unit: string }[];
  status: 'preparing' | 'shipped' | 'in_transit' | 'delivered' | 'returned';
  deliveryDate: string;
  trackingNumber?: string;
  carrier?: string;
  notes?: string;
}

export interface DeliveryRequest {
  _id: string;
  user: string;
  requestNumber: string;
  customer: Customer | string;
  customerName: string;
  items: { product?: string; name: string; quantity: number; unit: string }[];
  status: 'pending' | 'approved' | 'rejected' | 'processing' | 'completed';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  requestedDate: string;
  requiredDate: string;
  approvedBy?: { name: string };
  approvedAt?: string;
  rejectionReason?: string;
  notes?: string;
}

export interface Company {
  _id: string;
  user: string;
  name: string;
  address?: string;
  city?: string;
  state?: string;
  pincode?: string;
  phone?: string;
  email?: string;
  gstNumber?: string;
  panNumber?: string;
  bankName?: string;
  bankAccount?: string;
  bankIfsc?: string;
  logo?: string;
  signature?: string;
  termsAndConditions?: string;
  invoicePrefix?: string;
  quotationPrefix?: string;
  poPrefix?: string;
  doPrefix?: string;
  currency?: string;
  taxName?: string;
  taxRate?: number;
}

export interface Activity {
  _id: string;
  user: string;
  userName: string;
  action: string;
  entityType: string;
  entityId?: string;
  entityName?: string;
  details?: string;
  createdAt: string;
}

export interface DashboardStats {
  totalInvoices: number;
  totalQuotations: number;
  totalCustomers: number;
  totalProducts: number;
  monthlyRevenue: number;
  yearlyRevenue: number;
  pendingInvoices: number;
}

export interface AdminDashboardStats {
  totalUsers: number;
  activeUsers: number;
  totalSubscriptions: number;
  expiredSubscriptions: number;
  totalRevenue: number;
  monthlyRevenue: number;
  newUsersThisMonth: number;
  invoicesCount: number;
  quotationsCount: number;
  posCount: number;
  dosCount: number;
}