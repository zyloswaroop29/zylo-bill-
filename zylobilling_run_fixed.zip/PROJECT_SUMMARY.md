# ZYLO Billing Software - Complete Project Summary

## Project Overview
**ZYLO Billing Software** is a full-stack cloud billing application with complete authentication, subscription management, and business document handling.

---

## Architecture

### Frontend (React + TypeScript + Tailwind CSS)
- **Build Tool**: Vite
- **State Management**: Zustand (with localStorage persistence)
- **Routing**: React Router v6
- **HTTP Client**: Axios (with interceptors)
- **Charts**: Recharts
- **PDF Generation**: html2canvas + jsPDF
- **Notifications**: react-hot-toast
- **Icons**: Lucide React

### Backend (Node.js + Express + TypeScript)
- **Framework**: Express.js
- **Database**: MongoDB + Mongoose ODM
- **Authentication**: JWT + bcryptjs
- **Security**: Helmet, CORS, express-rate-limit
- **Validation**: express-validator
- **Cron Jobs**: node-cron (subscription expiry checker)

---

## File Structure (83 files total)

```
zylo-billing/
├── frontend/                          # React Frontend
│   ├── src/
│   │   ├── pages/
│   │   │   ├── auth/
│   │   │   │   ├── Login.tsx          # Login with admin/user toggle
│   │   │   │   └── Register.tsx       # Registration with 3-day trial
│   │   │   ├── user/
│   │   │   │   ├── Dashboard.tsx      # User dashboard with charts
│   │   │   │   ├── Invoices.tsx       # Invoice list with search/filter
│   │   │   │   ├── InvoiceCreate.tsx  # Create/edit invoice
│   │   │   │   ├── InvoiceView.tsx    # View/print/PDF/download
│   │   │   │   ├── Quotations.tsx     # Quotation list
│   │   │   │   ├── QuotationCreate.tsx
│   │   │   │   ├── PurchaseOrders.tsx
│   │   │   │   ├── PurchaseOrderCreate.tsx
│   │   │   │   ├── DeliveryOrders.tsx
│   │   │   │   ├── DeliveryOrderCreate.tsx
│   │   │   │   ├── DeliveryRequests.tsx
│   │   │   │   ├── DeliveryRequestCreate.tsx
│   │   │   │   ├── Customers.tsx      # Customer CRUD
│   │   │   │   ├── Products.tsx       # Product CRUD with stock
│   │   │   │   ├── CompanySettings.tsx
│   │   │   │   └── SubscriptionExpired.tsx
│   │   │   └── admin/
│   │   │       ├── Dashboard.tsx      # Admin analytics
│   │   │       ├── Users.tsx          # User management
│   │   │       ├── Subscriptions.tsx  # Subscription control
│   │   │       ├── Invoices.tsx       # All invoices view
│   │   │       ├── Reports.tsx        # Export reports
│   │   │       └── Activity.tsx       # Activity logs
│   │   ├── components/
│   │   │   ├── layout/
│   │   │   │   ├── AuthLayout.tsx
│   │   │   │   ├── MainLayout.tsx
│   │   │   │   ├── Sidebar.tsx        # Collapsible sidebar
│   │   │   │   └── Header.tsx         # Top navigation
│   │   │   └── auth/
│   │   │       ├── ProtectedRoute.tsx
│   │   │       ├── AdminRoute.tsx
│   │   │       └── SubscriptionCheck.tsx
│   │   ├── context/
│   │   │   └── store.ts               # Zustand store
│   │   ├── utils/
│   │   │   └── api.ts                 # API client with interceptors
│   │   ├── types/
│   │   │   └── index.ts               # TypeScript types
│   │   ├── App.tsx                    # Main app with routes
│   │   ├── main.tsx                   # Entry point
│   │   └── index.css                  # Tailwind + custom styles
│   ├── package.json
│   ├── vite.config.ts
│   ├── tailwind.config.js
│   ├── tsconfig.json
│   └── index.html
│
├── backend/                           # Node.js Backend
│   ├── src/
│   │   ├── models/
│   │   │   ├── User.ts                # User schema with bcrypt
│   │   │   ├── Subscription.ts        # Subscription schema
│   │   │   ├── Customer.ts
│   │   │   ├── Product.ts
│   │   │   ├── Invoice.ts
│   │   │   ├── Quotation.ts
│   │   │   ├── PurchaseOrder.ts
│   │   │   ├── DeliveryOrder.ts
│   │   │   ├── DeliveryRequest.ts
│   │   │   ├── Company.ts
│   │   │   └── Activity.ts
│   │   ├── routes/
│   │   │   ├── auth.ts                # Auth routes
│   │   │   ├── users.ts               # Admin user management
│   │   │   ├── invoices.ts            # Invoice CRUD
│   │   │   ├── quotations.ts
│   │   │   ├── purchaseOrders.ts
│   │   │   ├── deliveryOrders.ts
│   │   │   ├── deliveryRequests.ts
│   │   │   ├── customers.ts
│   │   │   ├── products.ts
│   │   │   ├── subscriptions.ts
│   │   │   ├── company.ts
│   │   │   ├── dashboard.ts
│   │   │   ├── reports.ts
│   │   │   └── activity.ts
│   │   ├── middleware/
│   │   │   ├── auth.ts                # JWT + subscription check
│   │   │   ├── errorHandler.ts
│   │   │   └── activityLogger.ts
│   │   ├── utils/
│   │   │   ├── subscriptionChecker.ts # Cron job
│   │   │   └── seed.ts                # Demo data
│   │   └── index.ts                   # Server entry
│   ├── package.json
│   ├── tsconfig.json
│   └── .env.example
│
├── README.md
├── .gitignore
├── vercel.json
└── render.yaml
```

---

## Features Implemented

### Authentication
- ✅ JWT login system with 7-day token expiry
- ✅ Password encryption with bcrypt (12 rounds)
- ✅ Two login types: Admin and User
- ✅ Default admin: zylo@2026 / 181629
- ✅ Role-based access control middleware
- ✅ Session timeout handling
- ✅ Protected routes with auth guards

### Subscription System
- ✅ 3-day free demo trial for new users
- ✅ Automatic expiry checking (hourly cron job)
- ✅ Subscription lock on expiry
- ✅ WhatsApp contact button (wa.me/917019071669)
- ✅ Plans: Monthly, Yearly, Lifetime
- ✅ Admin can activate/extend subscriptions
- ✅ Expired users list

### User Dashboard
- ✅ Stats cards (invoices, quotations, customers, products)
- ✅ Revenue cards (monthly, yearly, pending)
- ✅ Revenue chart (area chart)
- ✅ Recent invoices/quotations
- ✅ Low stock alerts

### Invoice Management
- ✅ Auto invoice number generation
- ✅ Add customer with GST
- ✅ Add products with auto-fill
- ✅ Quantity, tax, discount calculation
- ✅ PDF download (html2canvas + jsPDF)
- ✅ Print invoice
- ✅ Share on WhatsApp
- ✅ Status tracking (draft/sent/paid/overdue/cancelled)

### Quotation Management
- ✅ Create quotations
- ✅ Convert to invoice
- ✅ Download PDF
- ✅ Valid until date

### Purchase Orders
- ✅ Create PO with supplier details
- ✅ Supplier management
- ✅ Print and export

### Delivery Orders
- ✅ Create delivery orders
- ✅ Delivery tracking status
- ✅ PDF print
- ✅ Tracking number and carrier

### Delivery Requests
- ✅ Request creation
- ✅ Approval workflow (approve/reject)
- ✅ Priority levels (low/medium/high/urgent)
- ✅ Status tracking

### Customer Management
- ✅ CRUD operations
- ✅ GST number support
- ✅ Address with city/state

### Product Management
- ✅ CRUD operations
- ✅ SKU support
- ✅ Stock tracking with low stock alerts
- ✅ Category support
- ✅ Tax rate per product

### Company Settings
- ✅ Company profile
- ✅ Bank details
- ✅ Document prefixes
- ✅ Currency settings
- ✅ Default tax rate
- ✅ Terms & conditions

### Admin Panel
- ✅ Dashboard with platform analytics
- ✅ User management (create/edit/delete/activate)
- ✅ Subscription control (activate/extend/remove)
- ✅ View all documents across users
- ✅ Revenue tracking
- ✅ Activity logs
- ✅ Export reports (CSV)

### UI/UX
- ✅ Premium professional design
- ✅ Sidebar navigation (collapsible)
- ✅ Dashboard cards with icons
- ✅ Graph analytics (Recharts)
- ✅ Animated transitions
- ✅ Professional login page
- ✅ Dark and Light mode
- ✅ Mobile responsive
- ✅ Notification badges
- ✅ Toast notifications

### Security
- ✅ Password encryption
- ✅ JWT authentication
- ✅ Role-based access control
- ✅ Rate limiting (100 req/15min)
- ✅ Helmet security headers
- ✅ CORS configuration
- ✅ Input validation
- ✅ Secure API routes

---

## Database Schema

### Users Collection
```javascript
{
  name: String (required),
  email: String (required, unique),
  password: String (required, hashed),
  role: Enum ['admin', 'user'],
  phone: String,
  companyName: String,
  isActive: Boolean (default: true),
  permissions: [String]
}
```

### Subscriptions Collection
```javascript
{
  user: ObjectId (ref: User),
  plan: Enum ['trial', 'monthly', 'yearly', 'lifetime'],
  status: Enum ['active', 'expired', 'cancelled', 'pending'],
  startDate: Date,
  endDate: Date,
  isDemo: Boolean (default: true),
  demoExpiryDate: Date,
  amount: Number,
  paymentStatus: Enum ['paid', 'unpaid', 'pending']
}
```

### Invoices Collection
```javascript
{
  user: ObjectId (ref: User),
  invoiceNumber: String (unique),
  customer: ObjectId (ref: Customer),
  customerName: String,
  items: [{
    product: ObjectId,
    name: String,
    quantity: Number,
    unitPrice: Number,
    taxRate: Number,
    discount: Number,
    total: Number
  }],
  subTotal: Number,
  totalTax: Number,
  totalDiscount: Number,
  grandTotal: Number,
  status: Enum ['draft', 'sent', 'paid', 'overdue', 'cancelled'],
  dueDate: Date,
  notes: String,
  terms: String
}
```

---

## API Endpoints

### Auth
- `POST /api/auth/register` - Register (auto-creates subscription + company)
- `POST /api/auth/login` - Login
- `GET /api/auth/me` - Current user

### Users (Admin)
- `GET /api/users` - List users (with subscriptions)
- `GET /api/users/expired` - Expired users
- `POST /api/users` - Create user
- `PUT /api/users/:id` - Update user
- `DELETE /api/users/:id` - Delete user
- `PUT /api/users/:id/subscription` - Update subscription
- `PUT /api/users/:id/permissions` - Update permissions

### Invoices
- `GET /api/invoices` - List (with pagination, search, filter)
- `GET /api/invoices/:id` - Get single (with company)
- `POST /api/invoices` - Create (auto-calculates totals)
- `PUT /api/invoices/:id` - Update
- `DELETE /api/invoices/:id` - Delete
- `PUT /api/invoices/:id/status` - Update status

### Quotations
- `POST /api/quotations/:id/convert` - Convert to invoice

### Subscriptions
- `GET /api/subscriptions/my` - Current user's subscription
- `GET /api/subscriptions` - All subscriptions (admin)
- `GET /api/subscriptions/expired` - Expired subscriptions
- `POST /api/subscriptions/activate/:userId` - Activate subscription

### Dashboard
- `GET /api/dashboard/user` - User dashboard stats
- `GET /api/dashboard/admin` - Admin dashboard stats

---

## Deployment Instructions

### 1. MongoDB Atlas Setup
1. Create account at mongodb.com
2. Create new cluster (free tier available)
3. Add database user
4. Add IP to network access (0.0.0.0/0 for all)
5. Get connection string

### 2. Backend Deployment (Render)
1. Push code to GitHub
2. Connect Render to GitHub repo
3. Set environment variables:
   - `MONGODB_URI` = your atlas connection string
   - `JWT_SECRET` = random strong string
   - `NODE_ENV` = production
   - `FRONTEND_URL` = your vercel URL
4. Deploy

### 3. Frontend Deployment (Vercel)
1. Push code to GitHub
2. Import project in Vercel
3. Set framework preset to Vite
4. Set environment variable:
   - `VITE_API_URL` = your render backend URL + /api
5. Deploy

### 4. Local Development
```bash
# Install dependencies
npm install
cd frontend && npm install
cd ../backend && npm install

# Setup environment
cd backend
cp .env.example .env
# Edit .env with your settings

# Seed database
cd backend
npx tsx src/utils/seed.ts

# Run backend (port 5000)
cd backend
npm run dev

# Run frontend (port 5173)
cd frontend
npm run dev
```

---

## Default Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | zylo@2026 | 181629 |
| Demo User | demo@zylo.com | demo123 |

---

## WhatsApp Contact
For subscription inquiries:
**https://wa.me/917019071669**

---

## Technologies Used

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, TypeScript, Tailwind CSS, Vite |
| State | Zustand |
| Charts | Recharts |
| PDF | html2canvas, jsPDF |
| Backend | Node.js, Express, TypeScript |
| Database | MongoDB, Mongoose |
| Auth | JWT, bcryptjs |
| Security | Helmet, CORS, Rate Limit |
| Cron | node-cron |

---

**Total Files**: 83
**Frontend Pages**: 24
**Backend Routes**: 14
**Database Models**: 11
**Lines of Code**: ~15,000+

Built with ❤️ by ZYLO Technologies
