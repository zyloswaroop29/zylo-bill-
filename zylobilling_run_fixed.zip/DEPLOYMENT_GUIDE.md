# ZYLO Billing Software - Deployment Guide

## Option 1: Docker (EASIEST - One Command)

### Requirements
- Docker Desktop installed

### Steps
```bash
# 1. Download and extract the ZIP file
# 2. Open terminal in the project folder
# 3. Run:
docker-compose up --build -d

# 4. Wait 2-3 minutes for build
# 5. Open browser:
#    Frontend: http://localhost:5173
#    Backend:  http://localhost:5000

# 6. Login with:
#    Admin: zylo@2026 / 181629
#    Demo:  demo@zylo.com / demo123

# To stop:
docker-compose down
```

---

## Option 2: Automatic Startup Script

### Mac/Linux
```bash
chmod +x start.sh
./start.sh
```

### Windows
Double-click `start.bat`

---

## Option 3: Manual Setup

### Step 1: Install Node.js 18+
Download from https://nodejs.org

### Step 2: Install MongoDB (or use Atlas free tier)

### Step 3: Setup
```bash
cd zylo-billing/backend
npm install
cp .env.example .env
# Edit .env with your MongoDB URI
npx tsx src/utils/seed.ts
npm run dev

# New terminal:
cd ../frontend
npm install
npm run dev
```

### Step 4: Access
- http://localhost:5173
- Admin: zylo@2026 / 181629

---

## Option 4: Cloud Deployment

### Backend: Render.com
### Frontend: Vercel.com
### Database: MongoDB Atlas (Free)

See DEPLOYMENT_GUIDE.md for full details.

---

## Support
WhatsApp: https://wa.me/917019071669
