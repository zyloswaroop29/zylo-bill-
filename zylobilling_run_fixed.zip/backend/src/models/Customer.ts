import mongoose, { Schema, Document } from 'mongoose';

export interface ICustomer extends Document {
  user: mongoose.Types.ObjectId;
  name: string;
  email?: string;
  phone?: string;
  address?: string;
  city?: string;
  state?: string;
  gstNumber?: string;
  companyName?: string;
  createdAt: Date;
  updatedAt: Date;
}

const CustomerSchema: Schema = new Schema({
  user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  name: { type: String, required: true, trim: true },
  email: { type: String, trim: true },
  phone: { type: String, trim: true },
  address: { type: String, trim: true },
  city: { type: String, trim: true },
  state: { type: String, trim: true },
  gstNumber: { type: String, trim: true },
  companyName: { type: String, trim: true }
}, { timestamps: true });

export default mongoose.model<ICustomer>('Customer', CustomerSchema);
