import mongoose, { Schema, Document } from 'mongoose';

export interface IDeliveryRequestItem {
  product: mongoose.Types.ObjectId;
  name: string;
  quantity: number;
  unit: string;
}

export interface IDeliveryRequest extends Document {
  user: mongoose.Types.ObjectId;
  requestNumber: string;
  customer: mongoose.Types.ObjectId;
  customerName: string;
  items: IDeliveryRequestItem[];
  status: 'pending' | 'approved' | 'rejected' | 'processing' | 'completed';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  requestedDate: Date;
  requiredDate: Date;
  approvedBy?: mongoose.Types.ObjectId;
  approvedAt?: Date;
  rejectionReason?: string;
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

const DRItemSchema: Schema = new Schema({
  product: { type: Schema.Types.ObjectId, ref: 'Product' },
  name: { type: String, required: true },
  quantity: { type: Number, required: true, min: 0 },
  unit: { type: String, default: 'pcs' }
}, { _id: true });

const DeliveryRequestSchema: Schema = new Schema({
  user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  requestNumber: { type: String, required: true, unique: true },
  customer: { type: Schema.Types.ObjectId, ref: 'Customer', required: true },
  customerName: { type: String, required: true },
  items: { type: [DRItemSchema], required: true },
  status: { type: String, enum: ['pending', 'approved', 'rejected', 'processing', 'completed'], default: 'pending' },
  priority: { type: String, enum: ['low', 'medium', 'high', 'urgent'], default: 'medium' },
  requestedDate: { type: Date, default: Date.now },
  requiredDate: { type: Date, required: true },
  approvedBy: { type: Schema.Types.ObjectId, ref: 'User' },
  approvedAt: { type: Date },
  rejectionReason: { type: String },
  notes: { type: String }
}, { timestamps: true });

export default mongoose.model<IDeliveryRequest>('DeliveryRequest', DeliveryRequestSchema);
