import mongoose, { Schema, Document } from 'mongoose';

export interface IQuotationItem {
  product: mongoose.Types.ObjectId;
  name: string;
  quantity: number;
  unitPrice: number;
  taxRate: number;
  discount: number;
  total: number;
}

export interface IQuotation extends Document {
  user: mongoose.Types.ObjectId;
  quotationNumber: string;
  customer: mongoose.Types.ObjectId;
  customerName: string;
  items: IQuotationItem[];
  subTotal: number;
  totalTax: number;
  totalDiscount: number;
  grandTotal: number;
  status: 'draft' | 'sent' | 'accepted' | 'rejected' | 'converted';
  validUntil: Date;
  notes?: string;
  convertedToInvoice?: mongoose.Types.ObjectId;
  createdAt: Date;
  updatedAt: Date;
}

const QuotationItemSchema: Schema = new Schema({
  product: { type: Schema.Types.ObjectId, ref: 'Product' },
  name: { type: String, required: true },
  quantity: { type: Number, required: true, min: 0 },
  unitPrice: { type: Number, required: true, min: 0 },
  taxRate: { type: Number, default: 0 },
  discount: { type: Number, default: 0 },
  total: { type: Number, required: true }
}, { _id: true });

const QuotationSchema: Schema = new Schema({
  user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  quotationNumber: { type: String, required: true, unique: true },
  customer: { type: Schema.Types.ObjectId, ref: 'Customer', required: true },
  customerName: { type: String, required: true },
  items: { type: [QuotationItemSchema], required: true },
  subTotal: { type: Number, required: true },
  totalTax: { type: Number, default: 0 },
  totalDiscount: { type: Number, default: 0 },
  grandTotal: { type: Number, required: true },
  status: { type: String, enum: ['draft', 'sent', 'accepted', 'rejected', 'converted'], default: 'draft' },
  validUntil: { type: Date, required: true },
  notes: { type: String },
  convertedToInvoice: { type: Schema.Types.ObjectId, ref: 'Invoice' }
}, { timestamps: true });

export default mongoose.model<IQuotation>('Quotation', QuotationSchema);
