import mongoose, { Schema, Document } from 'mongoose';

export interface ICompany extends Document {
  user: mongoose.Types.ObjectId;
  name: string;
  address?: string;
  city?: string;
  state?: string;
  pincode?: string;
  phone?: string;
  email?: string;
  gstNumber?: string;
  panNumber?: string;
  bankName?: string;
  bankAccount?: string;
  bankIfsc?: string;
  logo?: string;
  signature?: string;
  termsAndConditions?: string;
  invoicePrefix?: string;
  quotationPrefix?: string;
  poPrefix?: string;
  doPrefix?: string;
  currency?: string;
  taxName?: string;
  taxRate?: number;
  createdAt: Date;
  updatedAt: Date;
}

const CompanySchema: Schema = new Schema({
  user: { type: Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
  name: { type: String, required: true, trim: true },
  address: { type: String, trim: true },
  city: { type: String, trim: true },
  state: { type: String, trim: true },
  pincode: { type: String, trim: true },
  phone: { type: String, trim: true },
  email: { type: String, trim: true },
  gstNumber: { type: String, trim: true },
  panNumber: { type: String, trim: true },
  bankName: { type: String, trim: true },
  bankAccount: { type: String, trim: true },
  bankIfsc: { type: String, trim: true },
  logo: { type: String },
  signature: { type: String },
  termsAndConditions: { type: String },
  invoicePrefix: { type: String, default: 'INV-' },
  quotationPrefix: { type: String, default: 'QTN-' },
  poPrefix: { type: String, default: 'PO-' },
  doPrefix: { type: String, default: 'DO-' },
  currency: { type: String, default: 'INR' },
  taxName: { type: String, default: 'GST' },
  taxRate: { type: Number, default: 18 }
}, { timestamps: true });

export default mongoose.model<ICompany>('Company', CompanySchema);
