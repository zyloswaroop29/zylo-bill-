import mongoose, { Schema, Document } from 'mongoose';

export interface ISubscription extends Document {
  user: mongoose.Types.ObjectId;
  plan: 'trial' | 'monthly' | 'yearly' | 'lifetime';
  status: 'active' | 'expired' | 'cancelled' | 'pending';
  startDate: Date;
  endDate: Date;
  isDemo: boolean;
  demoExpiryDate: Date;
  amount?: number;
  paymentStatus: 'paid' | 'unpaid' | 'pending';
  createdAt: Date;
  updatedAt: Date;
}

const SubscriptionSchema: Schema = new Schema({
  user: { type: Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
  plan: { type: String, enum: ['trial', 'monthly', 'yearly', 'lifetime'], default: 'trial' },
  status: { type: String, enum: ['active', 'expired', 'cancelled', 'pending'], default: 'active' },
  startDate: { type: Date, default: Date.now },
  endDate: { type: Date },
  isDemo: { type: Boolean, default: true },
  demoExpiryDate: { type: Date },
  amount: { type: Number },
  paymentStatus: { type: String, enum: ['paid', 'unpaid', 'pending'], default: 'unpaid' }
}, { timestamps: true });

export default mongoose.model<ISubscription>('Subscription', SubscriptionSchema);
