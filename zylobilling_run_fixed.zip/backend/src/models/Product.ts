import mongoose, { Schema, Document } from 'mongoose';

export interface IProduct extends Document {
  user: mongoose.Types.ObjectId;
  name: string;
  description?: string;
  sku?: string;
  price: number;
  cost?: number;
  taxRate: number;
  unit: string;
  category?: string;
  stock?: number;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const ProductSchema: Schema = new Schema({
  user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  name: { type: String, required: true, trim: true },
  description: { type: String, trim: true },
  sku: { type: String, trim: true },
  price: { type: Number, required: true, min: 0 },
  cost: { type: Number, min: 0 },
  taxRate: { type: Number, default: 18, min: 0, max: 100 },
  unit: { type: String, default: 'pcs' },
  category: { type: String, trim: true },
  stock: { type: Number, default: 0 },
  isActive: { type: Boolean, default: true }
}, { timestamps: true });

export default mongoose.model<IProduct>('Product', ProductSchema);
