import mongoose, { Schema, Document } from 'mongoose';

export interface IPurchaseOrderItem {
  product: mongoose.Types.ObjectId;
  name: string;
  quantity: number;
  unitPrice: number;
  taxRate: number;
  total: number;
}

export interface IPurchaseOrder extends Document {
  user: mongoose.Types.ObjectId;
  poNumber: string;
  supplier: string;
  supplierAddress?: string;
  supplierPhone?: string;
  supplierGst?: string;
  items: IPurchaseOrderItem[];
  subTotal: number;
  totalTax: number;
  grandTotal: number;
  status: 'draft' | 'sent' | 'received' | 'cancelled';
  orderDate: Date;
  deliveryDate?: Date;
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

const POItemSchema: Schema = new Schema({
  product: { type: Schema.Types.ObjectId, ref: 'Product' },
  name: { type: String, required: true },
  quantity: { type: Number, required: true, min: 0 },
  unitPrice: { type: Number, required: true, min: 0 },
  taxRate: { type: Number, default: 0 },
  total: { type: Number, required: true }
}, { _id: true });

const PurchaseOrderSchema: Schema = new Schema({
  user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  poNumber: { type: String, required: true, unique: true },
  supplier: { type: String, required: true },
  supplierAddress: { type: String },
  supplierPhone: { type: String },
  supplierGst: { type: String },
  items: { type: [POItemSchema], required: true },
  subTotal: { type: Number, required: true },
  totalTax: { type: Number, default: 0 },
  grandTotal: { type: Number, required: true },
  status: { type: String, enum: ['draft', 'sent', 'received', 'cancelled'], default: 'draft' },
  orderDate: { type: Date, default: Date.now },
  deliveryDate: { type: Date },
  notes: { type: String }
}, { timestamps: true });

export default mongoose.model<IPurchaseOrder>('PurchaseOrder', PurchaseOrderSchema);
