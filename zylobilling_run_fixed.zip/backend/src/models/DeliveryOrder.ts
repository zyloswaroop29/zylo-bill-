import mongoose, { Schema, Document } from 'mongoose';

export interface IDeliveryOrderItem {
  product: mongoose.Types.ObjectId;
  name: string;
  quantity: number;
  unit: string;
}

export interface IDeliveryOrder extends Document {
  user: mongoose.Types.ObjectId;
  doNumber: string;
  customer: mongoose.Types.ObjectId;
  customerName: string;
  customerAddress?: string;
  items: IDeliveryOrderItem[];
  status: 'preparing' | 'shipped' | 'in_transit' | 'delivered' | 'returned';
  deliveryDate: Date;
  trackingNumber?: string;
  carrier?: string;
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

const DOItemSchema: Schema = new Schema({
  product: { type: Schema.Types.ObjectId, ref: 'Product' },
  name: { type: String, required: true },
  quantity: { type: Number, required: true, min: 0 },
  unit: { type: String, default: 'pcs' }
}, { _id: true });

const DeliveryOrderSchema: Schema = new Schema({
  user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  doNumber: { type: String, required: true, unique: true },
  customer: { type: Schema.Types.ObjectId, ref: 'Customer', required: true },
  customerName: { type: String, required: true },
  customerAddress: { type: String },
  items: { type: [DOItemSchema], required: true },
  status: { type: String, enum: ['preparing', 'shipped', 'in_transit', 'delivered', 'returned'], default: 'preparing' },
  deliveryDate: { type: Date, required: true },
  trackingNumber: { type: String },
  carrier: { type: String },
  notes: { type: String }
}, { timestamps: true });

export default mongoose.model<IDeliveryOrder>('DeliveryOrder', DeliveryOrderSchema);
