import express from 'express';
import Customer from '../models/Customer';
import { authenticate, checkSubscription } from '../middleware/auth';

const router = express.Router();
router.use(authenticate, checkSubscription);

router.get('/', async (req: any, res) => {
  try {
    const { search, page = 1, limit = 50 } = req.query;
    const query: any = { user: req.user._id };
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { phone: { $regex: search, $options: 'i' } },
        { companyName: { $regex: search, $options: 'i' } }
      ];
    }
    const skip = (Number(page) - 1) * Number(limit);
    const [customers, total] = await Promise.all([
      Customer.find(query).sort({ name: 1 }).skip(skip).limit(Number(limit)),
      Customer.countDocuments(query)
    ]);
    res.json({ customers, pagination: { page: Number(page), limit: Number(limit), total, pages: Math.ceil(total / Number(limit)) } });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.get('/:id', async (req: any, res) => {
  try {
    const customer = await Customer.findOne({ _id: req.params.id, user: req.user._id });
    if (!customer) return res.status(404).json({ message: 'Customer not found' });
    res.json({ customer });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.post('/', async (req: any, res) => {
  try {
    const customer = new Customer({ user: req.user._id, ...req.body });
    await customer.save();
    res.status(201).json({ message: 'Customer created', customer });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.put('/:id', async (req: any, res) => {
  try {
    const customer = await Customer.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id },
      { $set: req.body }, { new: true }
    );
    if (!customer) return res.status(404).json({ message: 'Customer not found' });
    res.json({ message: 'Customer updated', customer });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.delete('/:id', async (req: any, res) => {
  try {
    const customer = await Customer.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!customer) return res.status(404).json({ message: 'Customer not found' });
    res.json({ message: 'Customer deleted' });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

export default router;
