import express from 'express';
import Product from '../models/Product';
import { authenticate, checkSubscription } from '../middleware/auth';

const router = express.Router();
router.use(authenticate, checkSubscription);

router.get('/', async (req: any, res) => {
  try {
    const { search, category, page = 1, limit = 50 } = req.query;
    const query: any = { user: req.user._id };
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { sku: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } }
      ];
    }
    if (category) query.category = category;

    const skip = (Number(page) - 1) * Number(limit);
    const [products, total] = await Promise.all([
      Product.find(query).sort({ name: 1 }).skip(skip).limit(Number(limit)),
      Product.countDocuments(query)
    ]);
    res.json({ products, pagination: { page: Number(page), limit: Number(limit), total, pages: Math.ceil(total / Number(limit)) } });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.get('/categories', async (req: any, res) => {
  try {
    const categories = await Product.distinct('category', { user: req.user._id });
    res.json({ categories: categories.filter(c => c) });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.get('/:id', async (req: any, res) => {
  try {
    const product = await Product.findOne({ _id: req.params.id, user: req.user._id });
    if (!product) return res.status(404).json({ message: 'Product not found' });
    res.json({ product });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.post('/', async (req: any, res) => {
  try {
    const product = new Product({ user: req.user._id, ...req.body });
    await product.save();
    res.status(201).json({ message: 'Product created', product });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.put('/:id', async (req: any, res) => {
  try {
    const product = await Product.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id },
      { $set: req.body }, { new: true }
    );
    if (!product) return res.status(404).json({ message: 'Product not found' });
    res.json({ message: 'Product updated', product });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.delete('/:id', async (req: any, res) => {
  try {
    const product = await Product.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!product) return res.status(404).json({ message: 'Product not found' });
    res.json({ message: 'Product deleted' });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

export default router;
