import express from 'express';
import jwt from 'jsonwebtoken';
import { body, validationResult } from 'express-validator';
import User from '../models/User';
import Subscription from '../models/Subscription';
import Company from '../models/Company';

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'zylo_secret_2026';

// Generate JWT token
const generateToken = (userId: string) => {
  return jwt.sign({ userId }, JWT_SECRET, { expiresIn: '7d' });
};

// @route   POST /api/auth/register
// @desc    Register new user
router.post('/register', [
  body('name').trim().isLength({ min: 2 }).withMessage('Name must be at least 2 characters'),
  body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
  body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ message: 'Validation failed', errors: errors.array() });
    }

    const { name, email, password, phone, companyName } = req.body;

    // Check if user exists
    let user = await User.findOne({ email });
    if (user) {
      return res.status(400).json({ message: 'User already exists with this email' });
    }

    // Create user
    user = new User({
      name,
      email,
      password,
      phone,
      companyName,
      role: 'user'
    });
    await user.save();

    // Create 3-day demo subscription
    const demoExpiryDate = new Date();
    demoExpiryDate.setDate(demoExpiryDate.getDate() + 3);

    const subscription = new Subscription({
      user: user._id,
      plan: 'trial',
      status: 'active',
      isDemo: true,
      demoExpiryDate,
      startDate: new Date(),
      endDate: demoExpiryDate
    });
    await subscription.save();

    // Create default company profile
    const company = new Company({
      user: user._id,
      name: companyName || name,
      currency: 'INR',
      taxName: 'GST',
      taxRate: 18
    });
    await company.save();

    const token = generateToken(user._id.toString());

    res.status(201).json({
      message: 'User registered successfully',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        phone: user.phone,
        companyName: user.companyName
      },
      subscription: {
        plan: subscription.plan,
        status: subscription.status,
        isDemo: subscription.isDemo,
        demoExpiryDate: subscription.demoExpiryDate,
        endDate: subscription.endDate
      }
    });
  } catch (error: any) {
    console.error('Register error:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// @route   POST /api/auth/login
// @desc    Login user
router.post('/login', [
  body('email').isEmail().normalizeEmail(),
  body('password').exists()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ message: 'Validation failed', errors: errors.array() });
    }

    const { email, password } = req.body;

    // Find user
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    // Check password
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    // Check if active
    if (!user.isActive) {
      return res.status(403).json({ message: 'Account deactivated. Contact admin.' });
    }

    // Get subscription
    const subscription = await Subscription.findOne({ user: user._id });

    const token = generateToken(user._id.toString());

    res.json({
      message: 'Login successful',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        phone: user.phone,
        companyName: user.companyName
      },
      subscription: subscription ? {
        plan: subscription.plan,
        status: subscription.status,
        isDemo: subscription.isDemo,
        demoExpiryDate: subscription.demoExpiryDate,
        endDate: subscription.endDate
      } : null
    });
  } catch (error: any) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// @route   GET /api/auth/me
// @desc    Get current user
router.get('/me', async (req, res) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) {
      return res.status(401).json({ message: 'No token' });
    }

    const decoded = jwt.verify(token, JWT_SECRET) as any;
    const user = await User.findById(decoded.userId).select('-password');

    if (!user) {
      return res.status(401).json({ message: 'User not found' });
    }

    const subscription = await Subscription.findOne({ user: user._id });

    res.json({
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        phone: user.phone,
        companyName: user.companyName,
        isActive: user.isActive,
        permissions: user.permissions
      },
      subscription: subscription ? {
        plan: subscription.plan,
        status: subscription.status,
        isDemo: subscription.isDemo,
        demoExpiryDate: subscription.demoExpiryDate,
        endDate: subscription.endDate
      } : null
    });
  } catch (error) {
    res.status(401).json({ message: 'Invalid token' });
  }
});

export default router;
