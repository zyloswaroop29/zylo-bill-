import express from 'express';
import { body, param, validationResult } from 'express-validator';
import User from '../models/User';
import Subscription from '../models/Subscription';
import { authenticate, requireAdmin } from '../middleware/auth';

const router = express.Router();

// All routes require admin
router.use(authenticate, requireAdmin);

// @route   GET /api/users
// @desc    Get all users
router.get('/', async (req, res) => {
  try {
    const { search, status, role, page = 1, limit = 20 } = req.query;

    const query: any = {};
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { companyName: { $regex: search, $options: 'i' } }
      ];
    }
    if (status !== undefined) query.isActive = status === 'active';
    if (role) query.role = role;

    const skip = (Number(page) - 1) * Number(limit);

    const [users, total] = await Promise.all([
      User.find(query).select('-password').sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
      User.countDocuments(query)
    ]);

    // Get subscriptions for each user
    const userIds = users.map(u => u._id);
    const subscriptions = await Subscription.find({ user: { $in: userIds } });

    const usersWithSubs = users.map(user => {
      const sub = subscriptions.find(s => s.user.toString() === user._id.toString());
      return {
        ...user.toObject(),
        subscription: sub || null
      };
    });

    res.json({
      users: usersWithSubs,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / Number(limit))
      }
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// @route   GET /api/users/expired
// @desc    Get expired users
router.get('/expired', async (req, res) => {
  try {
    const expiredSubs = await Subscription.find({ 
      status: 'expired',
      user: { $ne: null }
    }).populate('user', '-password');

    res.json({ users: expiredSubs });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// @route   POST /api/users
// @desc    Create user (admin)
router.post('/', [
  body('name').trim().isLength({ min: 2 }),
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 6 }),
  body('role').optional().isIn(['admin', 'user'])
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { name, email, password, role, phone, companyName, isActive } = req.body;

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'User already exists' });
    }

    const user = new User({
      name,
      email,
      password,
      role: role || 'user',
      phone,
      companyName,
      isActive: isActive !== undefined ? isActive : true
    });
    await user.save();

    // Create subscription
    const demoExpiryDate = new Date();
    demoExpiryDate.setDate(demoExpiryDate.getDate() + 3);

    const subscription = new Subscription({
      user: user._id,
      plan: 'trial',
      status: 'active',
      isDemo: true,
      demoExpiryDate,
      startDate: new Date(),
      endDate: demoExpiryDate
    });
    await subscription.save();

    res.status(201).json({
      message: 'User created successfully',
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        isActive: user.isActive
      }
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// @route   PUT /api/users/:id
// @desc    Update user
router.put('/:id', [
  param('id').isMongoId()
], async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;

    delete updates.password; // Don't update password here

    const user = await User.findByIdAndUpdate(
      id,
      { $set: updates },
      { new: true }
    ).select('-password');

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({ message: 'User updated', user });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// @route   DELETE /api/users/:id
// @desc    Delete user
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const user = await User.findByIdAndDelete(id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Delete related data
    await Subscription.deleteOne({ user: id });

    res.json({ message: 'User deleted successfully' });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// @route   PUT /api/users/:id/subscription
// @desc    Update user subscription
router.put('/:id/subscription', async (req, res) => {
  try {
    const { id } = req.params;
    const { plan, status, endDate, isDemo } = req.body;

    let subscription = await Subscription.findOne({ user: id });

    if (!subscription) {
      subscription = new Subscription({ user: id });
    }

    if (plan) subscription.plan = plan;
    if (status) subscription.status = status;
    if (endDate) subscription.endDate = new Date(endDate);
    if (isDemo !== undefined) subscription.isDemo = isDemo;

    await subscription.save();

    res.json({ 
      message: 'Subscription updated', 
      subscription 
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// @route   PUT /api/users/:id/permissions
// @desc    Update user permissions
router.put('/:id/permissions', async (req, res) => {
  try {
    const { id } = req.params;
    const { permissions } = req.body;

    const user = await User.findByIdAndUpdate(
      id,
      { $set: { permissions } },
      { new: true }
    ).select('-password');

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({ message: 'Permissions updated', user });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

export default router;
