import express from 'express';
import Invoice from '../models/Invoice';
import Quotation from '../models/Quotation';
import PurchaseOrder from '../models/PurchaseOrder';
import DeliveryOrder from '../models/DeliveryOrder';
import Customer from '../models/Customer';
import Product from '../models/Product';
import User from '../models/User';
import Subscription from '../models/Subscription';
import { authenticate, requireAdmin } from '../middleware/auth';

const router = express.Router();

// User Dashboard
router.get('/user', authenticate, async (req: any, res) => {
  try {
    const userId = req.user._id;
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfYear = new Date(now.getFullYear(), 0, 1);

    const [
      totalInvoices, totalQuotations, totalCustomers, totalProducts,
      monthlyRevenue, yearlyRevenue, pendingInvoices, recentInvoices,
      recentQuotations, lowStockProducts
    ] = await Promise.all([
      Invoice.countDocuments({ user: userId }),
      Quotation.countDocuments({ user: userId }),
      Customer.countDocuments({ user: userId }),
      Product.countDocuments({ user: userId }),
      Invoice.aggregate([
        { $match: { user: userId, status: 'paid', createdAt: { $gte: startOfMonth } } },
        { $group: { _id: null, total: { $sum: '$grandTotal' } } }
      ]),
      Invoice.aggregate([
        { $match: { user: userId, status: 'paid', createdAt: { $gte: startOfYear } } },
        { $group: { _id: null, total: { $sum: '$grandTotal' } } }
      ]),
      Invoice.countDocuments({ user: userId, status: { $in: ['draft', 'sent'] } }),
      Invoice.find({ user: userId }).sort({ createdAt: -1 }).limit(5).populate('customer', 'name'),
      Quotation.find({ user: userId }).sort({ createdAt: -1 }).limit(5).populate('customer', 'name'),
      Product.find({ user: userId, stock: { $lt: 10 } }).sort({ stock: 1 }).limit(5)
    ]);

    // Monthly chart data
    const monthlyData = await Invoice.aggregate([
      { $match: { user: userId, createdAt: { $gte: startOfYear } } },
      {
        $group: {
          _id: { month: { $month: '$createdAt' } },
          revenue: { $sum: '$grandTotal' },
          count: { $sum: 1 }
        }
      },
      { $sort: { '_id.month': 1 } }
    ]);

    res.json({
      stats: {
        totalInvoices, totalQuotations, totalCustomers, totalProducts,
        monthlyRevenue: monthlyRevenue[0]?.total || 0,
        yearlyRevenue: yearlyRevenue[0]?.total || 0,
        pendingInvoices
      },
      recentInvoices, recentQuotations, lowStockProducts,
      monthlyChart: monthlyData
    });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

// Admin Dashboard
router.get('/admin', authenticate, requireAdmin, async (req, res) => {
  try {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    const [
      totalUsers, activeUsers, totalSubscriptions, expiredSubscriptions,
      totalRevenue, monthlyRevenue, newUsersThisMonth,
      invoicesCount, quotationsCount, posCount, dosCount
    ] = await Promise.all([
      User.countDocuments(),
      User.countDocuments({ isActive: true }),
      Subscription.countDocuments(),
      Subscription.countDocuments({ status: 'expired' }),
      Invoice.aggregate([{ $match: { status: 'paid' } }, { $group: { _id: null, total: { $sum: '$grandTotal' } } }]),
      Invoice.aggregate([{ $match: { status: 'paid', createdAt: { $gte: startOfMonth } } }, { $group: { _id: null, total: { $sum: '$grandTotal' } } }]),
      User.countDocuments({ createdAt: { $gte: startOfMonth } }),
      Invoice.countDocuments(),
      Quotation.countDocuments(),
      PurchaseOrder.countDocuments(),
      DeliveryOrder.countDocuments()
    ]);

    // Recent users
    const recentUsers = await User.find().select('-password').sort({ createdAt: -1 }).limit(10);

    // Subscription distribution
    const planDistribution = await Subscription.aggregate([
      { $group: { _id: '$plan', count: { $sum: 1 } } }
    ]);

    res.json({
      stats: {
        totalUsers, activeUsers, totalSubscriptions, expiredSubscriptions,
        totalRevenue: totalRevenue[0]?.total || 0,
        monthlyRevenue: monthlyRevenue[0]?.total || 0,
        newUsersThisMonth,
        invoicesCount, quotationsCount, posCount, dosCount
      },
      recentUsers,
      planDistribution
    });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

export default router;
