import express from 'express';
import Activity from '../models/Activity';
import { authenticate, requireAdmin } from '../middleware/auth';

const router = express.Router();

router.get('/my', authenticate, async (req: any, res) => {
  try {
    const { page = 1, limit = 50 } = req.query;
    const skip = (Number(page) - 1) * Number(limit);
    const [activities, total] = await Promise.all([
      Activity.find({ user: req.user._id }).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
      Activity.countDocuments({ user: req.user._id })
    ]);
    res.json({ activities, pagination: { page: Number(page), limit: Number(limit), total, pages: Math.ceil(total / Number(limit)) } });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.get('/all', authenticate, requireAdmin, async (req, res) => {
  try {
    const { user, action, page = 1, limit = 50 } = req.query;
    const query: any = {};
    if (user) query.user = user;
    if (action) query.action = action;

    const skip = (Number(page) - 1) * Number(limit);
    const [activities, total] = await Promise.all([
      Activity.find(query).populate('user', 'name email').sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
      Activity.countDocuments(query)
    ]);
    res.json({ activities, pagination: { page: Number(page), limit: Number(limit), total, pages: Math.ceil(total / Number(limit)) } });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

export default router;
