import express from 'express';
import Company from '../models/Company';
import { authenticate } from '../middleware/auth';

const router = express.Router();
router.use(authenticate);

router.get('/', async (req: any, res) => {
  try {
    let company = await Company.findOne({ user: req.user._id });
    if (!company) {
      company = new Company({ user: req.user._id, name: req.user.companyName || req.user.name });
      await company.save();
    }
    res.json({ company });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.put('/', async (req: any, res) => {
  try {
    const company = await Company.findOneAndUpdate(
      { user: req.user._id },
      { $set: req.body },
      { new: true, upsert: true }
    );
    res.json({ message: 'Company settings updated', company });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

export default router;
