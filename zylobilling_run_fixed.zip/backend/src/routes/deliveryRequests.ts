import express from 'express';
import DeliveryRequest from '../models/DeliveryRequest';
import { authenticate, checkSubscription } from '../middleware/auth';

const router = express.Router();
router.use(authenticate, checkSubscription);

const generateDRNumber = async (userId: string) => {
  const count = await DeliveryRequest.countDocuments({ user: userId });
  const date = new Date();
  return `DR-${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, '0')}-${String(count + 1).padStart(4, '0')}`;
};

router.get('/', async (req: any, res) => {
  try {
    const { status, priority, page = 1, limit = 20 } = req.query;
    const query: any = { user: req.user._id };
    if (status) query.status = status;
    if (priority) query.priority = priority;

    const skip = (Number(page) - 1) * Number(limit);
    const [requests, total] = await Promise.all([
      DeliveryRequest.find(query).populate('customer').populate('items.product').populate('approvedBy', 'name')
        .sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
      DeliveryRequest.countDocuments(query)
    ]);
    res.json({ deliveryRequests: requests, pagination: { page: Number(page), limit: Number(limit), total, pages: Math.ceil(total / Number(limit)) } });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.get('/:id', async (req: any, res) => {
  try {
    const request = await DeliveryRequest.findOne({ _id: req.params.id, user: req.user._id })
      .populate('customer').populate('items.product').populate('approvedBy', 'name');
    if (!request) return res.status(404).json({ message: 'Delivery Request not found' });
    res.json({ deliveryRequest: request });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.post('/', async (req: any, res) => {
  try {
    const { customer, items, requiredDate, priority, notes } = req.body;
    const requestNumber = await generateDRNumber(req.user._id.toString());

    const deliveryRequest = new DeliveryRequest({
      user: req.user._id, requestNumber, customer,
      customerName: req.body.customerName,
      items, requiredDate: new Date(requiredDate), priority: priority || 'medium', notes
    });
    await deliveryRequest.save();
    res.status(201).json({ message: 'Delivery Request created', deliveryRequest });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.put('/:id', async (req: any, res) => {
  try {
    const deliveryRequest = await DeliveryRequest.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id },
      { $set: req.body }, { new: true }
    );
    if (!deliveryRequest) return res.status(404).json({ message: 'Delivery Request not found' });
    res.json({ message: 'Delivery Request updated', deliveryRequest });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

// Approve/Reject delivery request
router.put('/:id/approve', async (req: any, res) => {
  try {
    const { status, rejectionReason } = req.body;
    const update: any = { status, approvedBy: req.user._id, approvedAt: new Date() };
    if (rejectionReason) update.rejectionReason = rejectionReason;

    const deliveryRequest = await DeliveryRequest.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id },
      { $set: update }, { new: true }
    ).populate('approvedBy', 'name');
    if (!deliveryRequest) return res.status(404).json({ message: 'Delivery Request not found' });
    res.json({ message: `Request ${status}`, deliveryRequest });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.delete('/:id', async (req: any, res) => {
  try {
    const deliveryRequest = await DeliveryRequest.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!deliveryRequest) return res.status(404).json({ message: 'Delivery Request not found' });
    res.json({ message: 'Delivery Request deleted' });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

export default router;
