import express from 'express';
import PurchaseOrder from '../models/PurchaseOrder';
import Company from '../models/Company';
import { authenticate, checkSubscription } from '../middleware/auth';

const router = express.Router();
router.use(authenticate, checkSubscription);

const generatePONumber = async (userId: string, prefix: string = 'PO-') => {
  const count = await PurchaseOrder.countDocuments({ user: userId });
  const date = new Date();
  return `${prefix}${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, '0')}-${String(count + 1).padStart(4, '0')}`;
};

router.get('/', async (req: any, res) => {
  try {
    const { status, search, page = 1, limit = 20 } = req.query;
    const query: any = { user: req.user._id };
    if (status) query.status = status;
    if (search) query.$or = [{ poNumber: { $regex: search, $options: 'i' } }, { supplier: { $regex: search, $options: 'i' } }];

    const skip = (Number(page) - 1) * Number(limit);
    const [pos, total] = await Promise.all([
      PurchaseOrder.find(query).populate('items.product').sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
      PurchaseOrder.countDocuments(query)
    ]);
    res.json({ purchaseOrders: pos, pagination: { page: Number(page), limit: Number(limit), total, pages: Math.ceil(total / Number(limit)) } });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.get('/:id', async (req: any, res) => {
  try {
    const po = await PurchaseOrder.findOne({ _id: req.params.id, user: req.user._id }).populate('items.product');
    if (!po) return res.status(404).json({ message: 'Purchase Order not found' });
    const company = await Company.findOne({ user: req.user._id });
    res.json({ purchaseOrder: po, company });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.post('/', async (req: any, res) => {
  try {
    const { supplier, supplierAddress, supplierPhone, supplierGst, items, deliveryDate, notes } = req.body;
    const company = await Company.findOne({ user: req.user._id });
    const prefix = company?.poPrefix || 'PO-';
    const poNumber = await generatePONumber(req.user._id.toString(), prefix);

    let subTotal = 0, totalTax = 0;
    const poItems = items.map((item: any) => {
      const itemTotal = item.quantity * item.unitPrice;
      const itemTax = (itemTotal * (item.taxRate || 0)) / 100;
      subTotal += itemTotal; totalTax += itemTax;
      return { ...item, total: itemTotal + itemTax };
    });

    const po = new PurchaseOrder({
      user: req.user._id, poNumber, supplier, supplierAddress, supplierPhone, supplierGst,
      items: poItems, subTotal, totalTax, grandTotal: subTotal + totalTax,
      deliveryDate: deliveryDate ? new Date(deliveryDate) : undefined, notes
    });
    await po.save();
    res.status(201).json({ message: 'Purchase Order created', purchaseOrder: po });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.put('/:id', async (req: any, res) => {
  try {
    const updates = req.body;
    if (updates.items) {
      let subTotal = 0, totalTax = 0;
      updates.items = updates.items.map((item: any) => {
        const itemTotal = item.quantity * item.unitPrice;
        const itemTax = (itemTotal * (item.taxRate || 0)) / 100;
        subTotal += itemTotal; totalTax += itemTax;
        return { ...item, total: itemTotal + itemTax };
      });
      updates.subTotal = subTotal; updates.totalTax = totalTax;
      updates.grandTotal = subTotal + totalTax;
    }
    const po = await PurchaseOrder.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id },
      { $set: updates }, { new: true }
    );
    if (!po) return res.status(404).json({ message: 'Purchase Order not found' });
    res.json({ message: 'Purchase Order updated', purchaseOrder: po });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.delete('/:id', async (req: any, res) => {
  try {
    const po = await PurchaseOrder.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!po) return res.status(404).json({ message: 'Purchase Order not found' });
    res.json({ message: 'Purchase Order deleted' });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

export default router;
