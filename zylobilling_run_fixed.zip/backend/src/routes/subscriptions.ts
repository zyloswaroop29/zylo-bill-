import express from 'express';
import Subscription from '../models/Subscription';
import User from '../models/User';
import { authenticate, requireAdmin } from '../middleware/auth';

const router = express.Router();

// Get current user's subscription
router.get('/my', authenticate, async (req: any, res) => {
  try {
    const subscription = await Subscription.findOne({ user: req.user._id });
    if (!subscription) return res.status(404).json({ message: 'No subscription found' });
    res.json({ subscription });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

// Admin routes
router.use(requireAdmin);

router.get('/', async (req, res) => {
  try {
    const { status, plan, page = 1, limit = 50 } = req.query;
    const query: any = {};
    if (status) query.status = status;
    if (plan) query.plan = plan;

    const skip = (Number(page) - 1) * Number(limit);
    const [subscriptions, total] = await Promise.all([
      Subscription.find(query).populate('user', 'name email companyName').sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
      Subscription.countDocuments(query)
    ]);
    res.json({ subscriptions, pagination: { page: Number(page), limit: Number(limit), total, pages: Math.ceil(total / Number(limit)) } });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.get('/expired', async (req, res) => {
  try {
    const now = new Date();
    const subscriptions = await Subscription.find({
      $or: [
        { status: 'expired' },
        { isDemo: true, demoExpiryDate: { $lt: now } },
        { plan: { $ne: 'lifetime' }, endDate: { $lt: now } }
      ]
    }).populate('user', 'name email companyName phone');
    res.json({ subscriptions });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.put('/:id', async (req, res) => {
  try {
    const { plan, status, endDate, isDemo, amount, paymentStatus } = req.body;
    const update: any = {};
    if (plan) update.plan = plan;
    if (status) update.status = status;
    if (endDate) update.endDate = new Date(endDate);
    if (isDemo !== undefined) update.isDemo = isDemo;
    if (amount) update.amount = amount;
    if (paymentStatus) update.paymentStatus = paymentStatus;

    const subscription = await Subscription.findByIdAndUpdate(req.params.id, { $set: update }, { new: true })
      .populate('user', 'name email');
    if (!subscription) return res.status(404).json({ message: 'Subscription not found' });
    res.json({ message: 'Subscription updated', subscription });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

// Activate subscription for user
router.post('/activate/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const { plan, endDate, amount } = req.body;

    let subscription = await Subscription.findOne({ user: userId });
    const now = new Date();

    if (!subscription) {
      subscription = new Subscription({
        user: userId, plan: plan || 'monthly', status: 'active',
        isDemo: false, startDate: now, endDate: endDate ? new Date(endDate) : undefined,
        amount, paymentStatus: 'paid'
      });
    } else {
      subscription.plan = plan || 'monthly';
      subscription.status = 'active';
      subscription.isDemo = false;
      subscription.startDate = now;
      subscription.endDate = endDate ? new Date(endDate) : undefined;
      subscription.amount = amount;
      subscription.paymentStatus = 'paid';
    }

    await subscription.save();
    res.json({ message: 'Subscription activated', subscription });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

export default router;
