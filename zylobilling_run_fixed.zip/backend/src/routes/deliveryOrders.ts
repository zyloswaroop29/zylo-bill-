import express from 'express';
import DeliveryOrder from '../models/DeliveryOrder';
import Company from '../models/Company';
import { authenticate, checkSubscription } from '../middleware/auth';

const router = express.Router();
router.use(authenticate, checkSubscription);

const generateDONumber = async (userId: string, prefix: string = 'DO-') => {
  const count = await DeliveryOrder.countDocuments({ user: userId });
  const date = new Date();
  return `${prefix}${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, '0')}-${String(count + 1).padStart(4, '0')}`;
};

router.get('/', async (req: any, res) => {
  try {
    const { status, search, page = 1, limit = 20 } = req.query;
    const query: any = { user: req.user._id };
    if (status) query.status = status;
    if (search) query.$or = [{ doNumber: { $regex: search, $options: 'i' } }, { customerName: { $regex: search, $options: 'i' } }];

    const skip = (Number(page) - 1) * Number(limit);
    const [dos, total] = await Promise.all([
      DeliveryOrder.find(query).populate('customer').populate('items.product').sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
      DeliveryOrder.countDocuments(query)
    ]);
    res.json({ deliveryOrders: dos, pagination: { page: Number(page), limit: Number(limit), total, pages: Math.ceil(total / Number(limit)) } });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.get('/:id', async (req: any, res) => {
  try {
    const deliveryOrder = await DeliveryOrder.findOne({ _id: req.params.id, user: req.user._id })
      .populate('customer').populate('items.product');
    if (!deliveryOrder) return res.status(404).json({ message: 'Delivery Order not found' });
    const company = await Company.findOne({ user: req.user._id });
    res.json({ deliveryOrder, company });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.post('/', async (req: any, res) => {
  try {
    const { customer, items, deliveryDate, trackingNumber, carrier, notes } = req.body;
    const company = await Company.findOne({ user: req.user._id });
    const prefix = company?.doPrefix || 'DO-';
    const doNumber = await generateDONumber(req.user._id.toString(), prefix);

    const deliveryOrder = new DeliveryOrder({
      user: req.user._id, doNumber, customer,
      customerName: req.body.customerName, customerAddress: req.body.customerAddress,
      items, deliveryDate: new Date(deliveryDate), trackingNumber, carrier, notes
    });
    await deliveryOrder.save();
    res.status(201).json({ message: 'Delivery Order created', deliveryOrder });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.put('/:id', async (req: any, res) => {
  try {
    const deliveryOrder = await DeliveryOrder.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id },
      { $set: req.body }, { new: true }
    );
    if (!deliveryOrder) return res.status(404).json({ message: 'Delivery Order not found' });
    res.json({ message: 'Delivery Order updated', deliveryOrder });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.delete('/:id', async (req: any, res) => {
  try {
    const deliveryOrder = await DeliveryOrder.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!deliveryOrder) return res.status(404).json({ message: 'Delivery Order not found' });
    res.json({ message: 'Delivery Order deleted' });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

export default router;
