import express from 'express';
import Quotation from '../models/Quotation';
import Invoice from '../models/Invoice';
import Company from '../models/Company';
import { authenticate, checkSubscription } from '../middleware/auth';

const router = express.Router();
router.use(authenticate, checkSubscription);

const generateQuotationNumber = async (userId: string, prefix: string = 'QTN-') => {
  const count = await Quotation.countDocuments({ user: userId });
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  return `${prefix}${year}${month}-${String(count + 1).padStart(4, '0')}`;
};

// GET all quotations
router.get('/', async (req: any, res) => {
  try {
    const { status, search, page = 1, limit = 20 } = req.query;
    const query: any = { user: req.user._id };
    if (status) query.status = status;
    if (search) {
      query.$or = [
        { quotationNumber: { $regex: search, $options: 'i' } },
        { customerName: { $regex: search, $options: 'i' } }
      ];
    }

    const skip = (Number(page) - 1) * Number(limit);
    const [quotations, total] = await Promise.all([
      Quotation.find(query).populate('customer').populate('items.product').sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
      Quotation.countDocuments(query)
    ]);

    res.json({ quotations, pagination: { page: Number(page), limit: Number(limit), total, pages: Math.ceil(total / Number(limit)) } });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// GET single quotation
router.get('/:id', async (req: any, res) => {
  try {
    const quotation = await Quotation.findOne({ _id: req.params.id, user: req.user._id })
      .populate('customer').populate('items.product').populate('convertedToInvoice');
    if (!quotation) return res.status(404).json({ message: 'Quotation not found' });
    const company = await Company.findOne({ user: req.user._id });
    res.json({ quotation, company });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// POST create quotation
router.post('/', async (req: any, res) => {
  try {
    const { customer, items, validUntil, notes } = req.body;
    const company = await Company.findOne({ user: req.user._id });
    const prefix = company?.quotationPrefix || 'QTN-';
    const quotationNumber = await generateQuotationNumber(req.user._id.toString(), prefix);

    let subTotal = 0, totalTax = 0, totalDiscount = 0;
    const quotationItems = items.map((item: any) => {
      const itemTotal = item.quantity * item.unitPrice;
      const itemDiscount = (itemTotal * (item.discount || 0)) / 100;
      const taxableAmount = itemTotal - itemDiscount;
      const itemTax = (taxableAmount * (item.taxRate || 0)) / 100;
      subTotal += itemTotal; totalDiscount += itemDiscount; totalTax += itemTax;
      return { ...item, total: taxableAmount + itemTax };
    });

    const quotation = new Quotation({
      user: req.user._id, quotationNumber, customer,
      customerName: req.body.customerName,
      items: quotationItems, subTotal, totalTax, totalDiscount,
      grandTotal: subTotal - totalDiscount + totalTax,
      validUntil: new Date(validUntil), notes
    });
    await quotation.save();
    res.status(201).json({ message: 'Quotation created', quotation });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// PUT update quotation
router.put('/:id', async (req: any, res) => {
  try {
    const updates = req.body;
    if (updates.items) {
      let subTotal = 0, totalTax = 0, totalDiscount = 0;
      updates.items = updates.items.map((item: any) => {
        const itemTotal = item.quantity * item.unitPrice;
        const itemDiscount = (itemTotal * (item.discount || 0)) / 100;
        const taxableAmount = itemTotal - itemDiscount;
        const itemTax = (taxableAmount * (item.taxRate || 0)) / 100;
        subTotal += itemTotal; totalDiscount += itemDiscount; totalTax += itemTax;
        return { ...item, total: taxableAmount + itemTax };
      });
      updates.subTotal = subTotal; updates.totalTax = totalTax;
      updates.totalDiscount = totalDiscount;
      updates.grandTotal = subTotal - totalDiscount + totalTax;
    }
    const quotation = await Quotation.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id },
      { $set: updates }, { new: true }
    ).populate('customer');
    if (!quotation) return res.status(404).json({ message: 'Quotation not found' });
    res.json({ message: 'Quotation updated', quotation });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// DELETE quotation
router.delete('/:id', async (req: any, res) => {
  try {
    const quotation = await Quotation.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!quotation) return res.status(404).json({ message: 'Quotation not found' });
    res.json({ message: 'Quotation deleted' });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// POST convert quotation to invoice
router.post('/:id/convert', async (req: any, res) => {
  try {
    const quotation = await Quotation.findOne({ _id: req.params.id, user: req.user._id });
    if (!quotation) return res.status(404).json({ message: 'Quotation not found' });
    if (quotation.status === 'converted') return res.status(400).json({ message: 'Already converted' });

    const company = await Company.findOne({ user: req.user._id });
    const prefix = company?.invoicePrefix || 'INV-';
    const invoiceCount = await Invoice.countDocuments({ user: req.user._id });
    const date = new Date();
    const invoiceNumber = `${prefix}${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, '0')}-${String(invoiceCount + 1).padStart(4, '0')}`;

    const invoice = new Invoice({
      user: req.user._id, invoiceNumber,
      customer: quotation.customer, customerName: quotation.customerName,
      items: quotation.items.map((item: any) => ({
        product: item.product, name: item.name, description: item.description,
        quantity: item.quantity, unitPrice: item.unitPrice, taxRate: item.taxRate,
        discount: item.discount, total: item.total
      })),
      subTotal: quotation.subTotal, totalTax: quotation.totalTax,
      totalDiscount: quotation.totalDiscount, grandTotal: quotation.grandTotal,
      status: 'draft', notes: `Converted from quotation ${quotation.quotationNumber}`
    });
    await invoice.save();

    quotation.status = 'converted';
    quotation.convertedToInvoice = invoice._id;
    await quotation.save();

    res.json({ message: 'Converted to invoice', invoice });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

export default router;
