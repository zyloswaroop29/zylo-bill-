import express from 'express';
import Invoice from '../models/Invoice';
import Quotation from '../models/Quotation';
import PurchaseOrder from '../models/PurchaseOrder';
import DeliveryOrder from '../models/DeliveryOrder';
import Customer from '../models/Customer';
import Product from '../models/Product';
import { authenticate, requireAdmin } from '../middleware/auth';

const router = express.Router();

// User reports
router.get('/invoices', authenticate, async (req: any, res) => {
  try {
    const { startDate, endDate, status } = req.query;
    const query: any = { user: req.user._id };
    if (startDate && endDate) {
      query.createdAt = { $gte: new Date(startDate), $lte: new Date(endDate) };
    }
    if (status) query.status = status;

    const invoices = await Invoice.find(query).populate('customer', 'name').sort({ createdAt: -1 });
    const summary = {
      total: invoices.length,
      grandTotal: invoices.reduce((sum, inv) => sum + inv.grandTotal, 0),
      paid: invoices.filter(i => i.status === 'paid').reduce((sum, inv) => sum + inv.grandTotal, 0),
      unpaid: invoices.filter(i => i.status !== 'paid').reduce((sum, inv) => sum + inv.grandTotal, 0)
    };
    res.json({ invoices, summary });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

router.get('/revenue', authenticate, async (req: any, res) => {
  try {
    const { year = new Date().getFullYear() } = req.query;
    const startOfYear = new Date(Number(year), 0, 1);
    const endOfYear = new Date(Number(year) + 1, 0, 1);

    const monthlyRevenue = await Invoice.aggregate([
      { $match: { user: req.user._id, status: 'paid', createdAt: { $gte: startOfYear, $lt: endOfYear } } },
      {
        $group: {
          _id: { month: { $month: '$createdAt' } },
          revenue: { $sum: '$grandTotal' },
          count: { $sum: 1 }
        }
      },
      { $sort: { '_id.month': 1 } }
    ]);

    res.json({ year: Number(year), monthlyRevenue });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

// Admin reports
router.get('/admin/all', authenticate, requireAdmin, async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    const dateQuery: any = {};
    if (startDate && endDate) {
      dateQuery.createdAt = { $gte: new Date(startDate), $lte: new Date(endDate) };
    }

    const [invoices, quotations, pos, customers, products] = await Promise.all([
      Invoice.find(dateQuery).populate('user', 'name email').populate('customer', 'name').sort({ createdAt: -1 }),
      Quotation.find(dateQuery).populate('user', 'name email').populate('customer', 'name').sort({ createdAt: -1 }),
      PurchaseOrder.find(dateQuery).populate('user', 'name email').sort({ createdAt: -1 }),
      Customer.find(dateQuery).populate('user', 'name email').sort({ createdAt: -1 }),
      Product.find(dateQuery).populate('user', 'name email').sort({ createdAt: -1 })
    ]);

    res.json({ invoices, quotations, purchaseOrders: pos, customers, products });
  } catch (error: any) { res.status(500).json({ message: error.message }); }
});

export default router;
