import express from 'express';
import Invoice from '../models/Invoice';
import Company from '../models/Company';
import { authenticate, checkSubscription } from '../middleware/auth';

const router = express.Router();
router.use(authenticate, checkSubscription);

// Generate invoice number
const generateInvoiceNumber = async (userId: string, prefix: string = 'INV-') => {
  const count = await Invoice.countDocuments({ user: userId });
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  return `${prefix}${year}${month}-${String(count + 1).padStart(4, '0')}`;
};

// @route   GET /api/invoices
router.get('/', async (req: any, res) => {
  try {
    const { status, customer, search, page = 1, limit = 20 } = req.query;
    const query: any = { user: req.user._id };

    if (status) query.status = status;
    if (customer) query.customer = customer;
    if (search) {
      query.$or = [
        { invoiceNumber: { $regex: search, $options: 'i' } },
        { customerName: { $regex: search, $options: 'i' } }
      ];
    }

    const skip = (Number(page) - 1) * Number(limit);

    const [invoices, total] = await Promise.all([
      Invoice.find(query)
        .populate('customer', 'name email phone address')
        .populate('items.product', 'name sku')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(Number(limit)),
      Invoice.countDocuments(query)
    ]);

    res.json({
      invoices,
      pagination: { page: Number(page), limit: Number(limit), total, pages: Math.ceil(total / Number(limit)) }
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// @route   GET /api/invoices/:id
router.get('/:id', async (req: any, res) => {
  try {
    const invoice = await Invoice.findOne({ _id: req.params.id, user: req.user._id })
      .populate('customer')
      .populate('items.product');

    if (!invoice) return res.status(404).json({ message: 'Invoice not found' });

    const company = await Company.findOne({ user: req.user._id });

    res.json({ invoice, company });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// @route   POST /api/invoices
router.post('/', async (req: any, res) => {
  try {
    const { customer, items, dueDate, notes, terms, status } = req.body;

    const company = await Company.findOne({ user: req.user._id });
    const prefix = company?.invoicePrefix || 'INV-';

    const invoiceNumber = await generateInvoiceNumber(req.user._id.toString(), prefix);

    // Calculate totals
    let subTotal = 0;
    let totalTax = 0;
    let totalDiscount = 0;

    const invoiceItems = items.map((item: any) => {
      const itemTotal = item.quantity * item.unitPrice;
      const itemDiscount = (itemTotal * (item.discount || 0)) / 100;
      const taxableAmount = itemTotal - itemDiscount;
      const itemTax = (taxableAmount * (item.taxRate || 0)) / 100;
      const itemGrandTotal = taxableAmount + itemTax;

      subTotal += itemTotal;
      totalDiscount += itemDiscount;
      totalTax += itemTax;

      return {
        product: item.product,
        name: item.name,
        description: item.description,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        taxRate: item.taxRate || 0,
        discount: item.discount || 0,
        total: itemGrandTotal
      };
    });

    const grandTotal = subTotal - totalDiscount + totalTax;

    const invoice = new Invoice({
      user: req.user._id,
      invoiceNumber,
      customer,
      customerName: req.body.customerName,
      customerAddress: req.body.customerAddress,
      customerGst: req.body.customerGst,
      items: invoiceItems,
      subTotal,
      totalTax,
      totalDiscount,
      grandTotal,
      status: status || 'draft',
      dueDate: dueDate ? new Date(dueDate) : undefined,
      notes,
      terms
    });

    await invoice.save();
    await invoice.populate('customer');
    await invoice.populate('items.product');

    res.status(201).json({ message: 'Invoice created', invoice });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// @route   PUT /api/invoices/:id
router.put('/:id', async (req: any, res) => {
  try {
    const updates = req.body;
    delete updates.invoiceNumber; // Don't change invoice number

    // Recalculate if items changed
    if (updates.items) {
      let subTotal = 0;
      let totalTax = 0;
      let totalDiscount = 0;

      updates.items = updates.items.map((item: any) => {
        const itemTotal = item.quantity * item.unitPrice;
        const itemDiscount = (itemTotal * (item.discount || 0)) / 100;
        const taxableAmount = itemTotal - itemDiscount;
        const itemTax = (taxableAmount * (item.taxRate || 0)) / 100;
        const itemGrandTotal = taxableAmount + itemTax;

        subTotal += itemTotal;
        totalDiscount += itemDiscount;
        totalTax += itemTax;

        return { ...item, total: itemGrandTotal };
      });

      updates.subTotal = subTotal;
      updates.totalTax = totalTax;
      updates.totalDiscount = totalDiscount;
      updates.grandTotal = subTotal - totalDiscount + totalTax;
    }

    const invoice = await Invoice.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id },
      { $set: updates },
      { new: true }
    ).populate('customer').populate('items.product');

    if (!invoice) return res.status(404).json({ message: 'Invoice not found' });

    res.json({ message: 'Invoice updated', invoice });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// @route   DELETE /api/invoices/:id
router.delete('/:id', async (req: any, res) => {
  try {
    const invoice = await Invoice.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!invoice) return res.status(404).json({ message: 'Invoice not found' });
    res.json({ message: 'Invoice deleted' });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// @route   PUT /api/invoices/:id/status
router.put('/:id/status', async (req: any, res) => {
  try {
    const { status } = req.body;
    const invoice = await Invoice.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id },
      { $set: { status } },
      { new: true }
    );
    if (!invoice) return res.status(404).json({ message: 'Invoice not found' });
    res.json({ message: 'Status updated', invoice });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

export default router;
