import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import dotenv from 'dotenv';
import rateLimit from 'express-rate-limit';
import cron from 'node-cron';

import authRoutes from './routes/auth';
import userRoutes from './routes/users';
import invoiceRoutes from './routes/invoices';
import quotationRoutes from './routes/quotations';
import purchaseOrderRoutes from './routes/purchaseOrders';
import deliveryOrderRoutes from './routes/deliveryOrders';
import deliveryRequestRoutes from './routes/deliveryRequests';
import customerRoutes from './routes/customers';
import productRoutes from './routes/products';
import subscriptionRoutes from './routes/subscriptions';
import companyRoutes from './routes/company';
import dashboardRoutes from './routes/dashboard';
import reportRoutes from './routes/reports';
import activityRoutes from './routes/activity';
import { checkExpiredSubscriptions } from './utils/subscriptionChecker';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Security middleware
app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  credentials: true
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: 'Too many requests, please try again later.'
});
app.use('/api/', limiter);

app.use(express.json({ limit: '10mb' }));
app.use(morgan('dev'));

// Database connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/zylo_billing')
  .then(() => console.log('✅ MongoDB Connected'))
  .catch((err) => console.error('❌ MongoDB Connection Error:', err));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/invoices', invoiceRoutes);
app.use('/api/quotations', quotationRoutes);
app.use('/api/purchase-orders', purchaseOrderRoutes);
app.use('/api/delivery-orders', deliveryOrderRoutes);
app.use('/api/delivery-requests', deliveryRequestRoutes);
app.use('/api/customers', customerRoutes);
app.use('/api/products', productRoutes);
app.use('/api/subscriptions', subscriptionRoutes);
app.use('/api/company', companyRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/activity', activityRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Subscription expiry checker - runs every hour
cron.schedule('0 * * * *', () => {
  console.log('🔍 Checking expired subscriptions...');
  checkExpiredSubscriptions();
});

// Error handling
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Internal Server Error', error: process.env.NODE_ENV === 'development' ? err.message : undefined });
});

app.listen(PORT, () => {
  console.log(`🚀 ZYLO Backend running on port ${PORT}`);
});

export default app;
