import { Request, Response, NextFunction } from 'express';
import Activity from '../models/Activity';

interface AuthRequest extends Request {
  user?: any;
}

export const logActivity = (action: string, entityType: string) => {
  return async (req: AuthRequest, res: Response, next: NextFunction) => {
    // Store original json method
    const originalJson = res.json.bind(res);

    res.json = function(body: any) {
      // Log activity after response
      if (req.user && res.statusCode < 400) {
        Activity.create({
          user: req.user._id,
          userName: req.user.name,
          action,
          entityType,
          entityId: body?.data?._id || req.params.id,
          entityName: body?.data?.name || body?.data?.invoiceNumber || body?.data?.quotationNumber,
          details: `${action} ${entityType}`,
          ipAddress: req.ip
        }).catch(console.error);
      }
      return originalJson(body);
    };

    next();
  };
};
