import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import User from '../models/User';

interface AuthRequest extends Request {
  user?: any;
}

export const authenticate = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');

    if (!token) {
      return res.status(401).json({ message: 'Access denied. No token provided.' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'zylo_secret_2026') as any;
    const user = await User.findById(decoded.userId).select('-password');

    if (!user) {
      return res.status(401).json({ message: 'User not found.' });
    }

    if (!user.isActive) {
      return res.status(403).json({ message: 'Account deactivated. Contact admin.' });
    }

    req.user = user;
    next();
  } catch (error) {
    res.status(401).json({ message: 'Invalid token.' });
  }
};

export const requireAdmin = (req: AuthRequest, res: Response, next: NextFunction) => {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ message: 'Admin access required.' });
  }
  next();
};

export const checkSubscription = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    // Skip for admin users
    if (req.user?.role === 'admin') {
      return next();
    }

    const Subscription = require('../models/Subscription').default;
    const subscription = await Subscription.findOne({ user: req.user._id });

    if (!subscription) {
      return res.status(403).json({ 
        message: 'No subscription found.',
        subscriptionExpired: true 
      });
    }

    const now = new Date();

    // Check if demo expired
    if (subscription.isDemo && subscription.demoExpiryDate && now > subscription.demoExpiryDate) {
      return res.status(403).json({ 
        message: 'Your 3-day demo has expired. Please subscribe to continue.',
        subscriptionExpired: true,
        demoExpired: true
      });
    }

    // Check if subscription expired
    if (subscription.status === 'expired') {
      return res.status(403).json({ 
        message: 'Your subscription has expired. Please renew to continue.',
        subscriptionExpired: true 
      });
    }

    // Check end date for non-lifetime plans
    if (subscription.plan !== 'lifetime' && subscription.endDate && now > subscription.endDate) {
      subscription.status = 'expired';
      await subscription.save();
      return res.status(403).json({ 
        message: 'Your subscription has expired. Please renew to continue.',
        subscriptionExpired: true 
      });
    }

    next();
  } catch (error) {
    console.error('Subscription check error:', error);
    next();
  }
};
