import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import User from '../models/User';
import Subscription from '../models/Subscription';
import Company from '../models/Company';
import Customer from '../models/Customer';
import Product from '../models/Product';
import Invoice from '../models/Invoice';
import dotenv from 'dotenv';

dotenv.config();

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/zylo_billing';

const seedData = async () => {
  try {
    await mongoose.connect(MONGODB_URI);
    console.log('Connected to MongoDB');

    // Clear existing data
    await Promise.all([
      User.deleteMany({}),
      Subscription.deleteMany({}),
      Company.deleteMany({}),
      Customer.deleteMany({}),
      Product.deleteMany({}),
      Invoice.deleteMany({})
    ]);
    console.log('Cleared existing data');

    // Create admin user
    const adminPassword = await bcrypt.hash('181629', 12);
    const admin = new User({
      name: 'ZYLO Admin',
      email: 'zylo@2026',
      password: adminPassword,
      role: 'admin',
      phone: '+91-7019071669',
      companyName: 'ZYLO Technologies',
      isActive: true
    });
    await admin.save();

    // Create admin subscription (lifetime)
    const adminSub = new Subscription({
      user: admin._id,
      plan: 'lifetime',
      status: 'active',
      isDemo: false,
      startDate: new Date(),
      paymentStatus: 'paid'
    });
    await adminSub.save();

    // Create admin company
    const adminCompany = new Company({
      user: admin._id,
      name: 'ZYLO Technologies',
      address: '123 Business Park, Tech City',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400001',
      phone: '+91-7019071669',
      email: 'admin@zylo.com',
      gstNumber: '27AABCU9603R1ZX',
      panNumber: 'AABCU9603R',
      bankName: 'HDFC Bank',
      bankAccount: '50100345678901',
      bankIfsc: 'HDFC0001234',
      currency: 'INR',
      taxName: 'GST',
      taxRate: 18,
      invoicePrefix: 'INV-',
      quotationPrefix: 'QTN-',
      poPrefix: 'PO-',
      doPrefix: 'DO-'
    });
    await adminCompany.save();

    // Create demo user
    const demoPassword = await bcrypt.hash('demo123', 12);
    const demoUser = new User({
      name: 'Demo User',
      email: 'demo@zylo.com',
      password: demoPassword,
      role: 'user',
      phone: '+91-9876543210',
      companyName: 'Demo Enterprise',
      isActive: true
    });
    await demoUser.save();

    // Create demo subscription (3-day trial)
    const demoExpiry = new Date();
    demoExpiry.setDate(demoExpiry.getDate() + 3);
    const demoSub = new Subscription({
      user: demoUser._id,
      plan: 'trial',
      status: 'active',
      isDemo: true,
      demoExpiryDate: demoExpiry,
      startDate: new Date(),
      endDate: demoExpiry,
      paymentStatus: 'unpaid'
    });
    await demoSub.save();

    // Create demo company
    const demoCompany = new Company({
      user: demoUser._id,
      name: 'Demo Enterprise',
      address: '456 Industrial Area',
      city: 'Delhi',
      state: 'Delhi',
      pincode: '110001',
      phone: '+91-9876543210',
      email: 'demo@zylo.com',
      gstNumber: '07AABCU9603R1ZP',
      currency: 'INR',
      taxName: 'GST',
      taxRate: 18
    });
    await demoCompany.save();

    // Create demo customers
    const customers = [
      { user: demoUser._id, name: 'ABC Traders', email: 'abc@traders.com', phone: '+91-9998887770', address: 'Mumbai', city: 'Mumbai', state: 'Maharashtra', gstNumber: '27AADCB2230M1ZT', companyName: 'ABC Traders Pvt Ltd' },
      { user: demoUser._id, name: 'XYZ Enterprises', email: 'xyz@enterprises.com', phone: '+91-9998887771', address: 'Delhi', city: 'Delhi', state: 'Delhi', gstNumber: '07AADCB2230M1ZU', companyName: 'XYZ Enterprises Ltd' },
      { user: demoUser._id, name: 'Global Suppliers', email: 'global@suppliers.com', phone: '+91-9998887772', address: 'Bangalore', city: 'Bangalore', state: 'Karnataka', gstNumber: '29AADCB2230M1ZV', companyName: 'Global Suppliers Inc' }
    ];
    await Customer.insertMany(customers);

    // Create demo products
    const products = [
      { user: demoUser._id, name: 'Laptop Dell XPS 15', description: 'High performance laptop', sku: 'LAP-DEL-001', price: 85000, cost: 72000, taxRate: 18, unit: 'pcs', category: 'Electronics', stock: 25 },
      { user: demoUser._id, name: 'Wireless Mouse', description: 'Ergonomic wireless mouse', sku: 'MOU-WIR-002', price: 1200, cost: 800, taxRate: 18, unit: 'pcs', category: 'Accessories', stock: 100 },
      { user: demoUser._id, name: 'USB-C Hub', description: '7-in-1 USB-C hub', sku: 'USB-HUB-003', price: 2500, cost: 1500, taxRate: 18, unit: 'pcs', category: 'Accessories', stock: 50 },
      { user: demoUser._id, name: 'Monitor 27" 4K', description: '4K UHD Monitor', sku: 'MON-27K-004', price: 35000, cost: 28000, taxRate: 18, unit: 'pcs', category: 'Electronics', stock: 15 },
      { user: demoUser._id, name: 'Keyboard Mechanical', description: 'RGB Mechanical Keyboard', sku: 'KEY-MEC-005', price: 4500, cost: 3000, taxRate: 18, unit: 'pcs', category: 'Accessories', stock: 40 }
    ];
    await Product.insertMany(products);

    // Create demo invoice
    const demoInvoice = new Invoice({
      user: demoUser._id,
      invoiceNumber: 'INV-202601-0001',
      customer: (await Customer.findOne({ user: demoUser._id }))?._id,
      customerName: 'ABC Traders',
      customerAddress: 'Mumbai',
      customerGst: '27AADCB2230M1ZT',
      items: [
        { name: 'Laptop Dell XPS 15', quantity: 2, unitPrice: 85000, taxRate: 18, discount: 5, total: 180190 },
        { name: 'Wireless Mouse', quantity: 5, unitPrice: 1200, taxRate: 18, discount: 0, total: 7080 }
      ],
      subTotal: 176000,
      totalTax: 11270,
      totalDiscount: 8800,
      grandTotal: 178270,
      status: 'paid',
      dueDate: new Date('2026-02-15'),
      notes: 'Payment received via bank transfer'
    });
    await demoInvoice.save();

    console.log('✅ Seed data created successfully!');
    console.log('Admin: zylo@2026 / 181629');
    console.log('Demo: demo@zylo.com / demo123');

    process.exit(0);
  } catch (error) {
    console.error('❌ Seed error:', error);
    process.exit(1);
  }
};

seedData();
