import Subscription from '../models/Subscription';
import User from '../models/User';

export const checkExpiredSubscriptions = async () => {
  try {
    const now = new Date();

    // Find subscriptions that should be expired
    const subscriptions = await Subscription.find({
      status: { $in: ['active', 'pending'] }
    });

    for (const sub of subscriptions) {
      let shouldExpire = false;

      // Check demo expiry
      if (sub.isDemo && sub.demoExpiryDate && now > sub.demoExpiryDate) {
        shouldExpire = true;
      }

      // Check regular subscription expiry (not lifetime)
      if (sub.plan !== 'lifetime' && sub.endDate && now > sub.endDate) {
        shouldExpire = true;
      }

      if (shouldExpire) {
        sub.status = 'expired';
        await sub.save();
        console.log(`🔒 Subscription expired for user: ${sub.user}`);
      }
    }

    console.log('✅ Subscription check completed');
  } catch (error) {
    console.error('❌ Subscription check error:', error);
  }
};
